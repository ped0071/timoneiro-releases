"use strict";

// Timoneiro — service worker: leitura em segundo plano + notificações. Um único worker atende todas as abas.
// No Firefox o fundo é uma "event page" que já carrega estes arquivos pelo manifest (sem importScripts).
if (typeof importScripts === "function" && !globalThis.TimoneiroSync) importScripts("core/update.js", "core/keys.js", "core/status.js", "core/boats.js", "core/events.js", "core/history.js", "core/forecast.js", "background-sync.js", "settings-sync.js");

// Regras anti-repetição:
//  - Pesca: um alarme marcado para a hora em que o cooldown acaba (readyAt) notifica uma vez por
//    cooldown. A passagem cooldown → liberado também notifica (cooldowns curtos), com a mesma chave.
//  - Evento (v1.9.0): lido da lista por tipo (pescaskills.events.v2). Avisa no início, quando o
//    conteúdo muda de verdade (assinatura sem contagem regressiva) e, se você ligar, quando termina.
//    Filtro por relevância (Alta/Média/Baixa) em Ajustes.
//  - Torneio e expedição: uma vez por torneio/sala/frota (lidos pelo Guia).
const FISHING_KEY = "timoneiro.fishingStatus.v1";
const EVENTS_KEY = "timoneiro.events.v2";
const GUIDE_KEY = "timoneiro.guideData.v1";
const MARKET_HITS_KEY = "timoneiro.marketHits.v1";
const MEMO_KEY = "timoneiro.notified.v2";
const PREFS_KEY = "timoneiro.notifications.v1";
const DISCORD_KEY = "timoneiro.discord.v1";
const BOAT_KEY = "timoneiro.boat.v2";
const FISH_ALARM = "timoneiro-fishing-ready";
const FISH_NOTICE = ["timoneiro-fishing", "Pesca disponível!", "Seu cooldown no Twish acabou. Clique para abrir o chat com $pescar."];
const fishKey = (boat, readyAt) => `fish|${boat || ""}|${Math.round(readyAt / 10000)}`;
const WEBHOOK_RE = /^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+$/;
var noticeChain = Promise.resolve();
var lastForcedSync = 0;
// Notificações vêm ligadas por padrão (v1.11.0): só ficam desligadas se você desligou em Ajustes.
const isOn = (v) => v !== false;
const SOUND_LOCK = "timoneiro.soundLock.v1";
const SOUND_KEY = "timoneiro.sounds.v1";

async function memo() {
  const r = await chrome.storage.local.get(MEMO_KEY);
  const m = r[MEMO_KEY] || { keys: {}, fishing: null };
  m.events = m.events || {};
  const cutoff = Date.now() - 3 * 3600e3;
  for (const [k, t] of Object.entries(m.keys)) if (t < cutoff) delete m.keys[k];
  for (const [k, e] of Object.entries(m.events)) if ((e.at || 0) < cutoff) delete m.events[k];
  return m;
}

// Categoria de cada aviso: decide o que vai para o computador e o que vai para o Discord.
const CATEGORY = { "timoneiro-market": "alerts", "timoneiro-fishing": "fishing", "timoneiro-event": "event", "timoneiro-event-end": "event", "timoneiro-tournament": "alerts", "timoneiro-fleet": "alerts", "timoneiro-room": "alerts" };
// O que o clique na notificação preenche no chat (você confere e aperta Enter).
const CLICK_FILL = { "timoneiro-fishing": "$pescar", "timoneiro-tournament": "$entrar", "timoneiro-fleet": "$embarcar" };

// ---------- som com a Twitch em outra aba (v1.11.0) ----------
// A aba da Twitch toca o som quando está visível e marca a trava. Se em 1,2 s ninguém tocou
// (Twitch em segundo plano, minimizada ou fechada), o próprio Timoneiro toca: num documento
// invisível no Chrome/Edge, ou direto na página de fundo no Firefox.
async function playSound(kind, key) {
  await new Promise((ok) => setTimeout(ok, 1200));
  const r = await chrome.storage.local.get([SOUND_LOCK, SOUND_KEY]);
  const lock = r[SOUND_LOCK] || {};
  if (lock[kind] === key || Date.now() - (lock[`${kind}At`] || 0) < (kind === "fishing" ? 60000 : 12 * 60000)) return false;
  const pref = (r[SOUND_KEY] || {})[kind === "fishing" ? "fishingAlert" : "eventAlert"] || { enabled: true, volume: 7 };
  if (pref.enabled === false || !pref.volume) return false;
  await chrome.storage.local.set({ [SOUND_LOCK]: { ...lock, [kind]: key, [`${kind}At`]: Date.now() } });
  const asset = kind === "fishing" ? "sounds/pesca.wav" : "sounds/evento.wav";
  return playAsset(asset, pref.volume / 10);
}
async function playAsset(asset, volume) {
  try {
    if (typeof Audio === "function") { const a = new Audio(chrome.runtime.getURL(`assets/${asset}`)); a.volume = volume; await a.play(); return true; }
    if (!chrome.offscreen) return false;
    const has = chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : false;
    if (!has) await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["AUDIO_PLAYBACK"], justification: "Tocar o aviso de pesca e de evento quando a Twitch não está visível." }).catch(() => {});
    return !!(await chrome.runtime.sendMessage({ type: "timoneiro-play", asset, volume }).catch(() => false));
  } catch (_) { return false; }
}

async function notify(id, title, message, { desktop = true, sound = null } = {}) {
  if (sound) playSound(...sound).catch(() => {});
  if (desktop) {
    try {
      await chrome.notifications.create(`${id}-${Date.now()}`, { type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), title, message, silent: true });
    } catch (error) { console.warn("Timoneiro: não foi possível mostrar a notificação.", error); }
  }
  await postDiscord(id, title, message);
}

// ---------- Discord (opcional) ----------
async function postDiscord(id, title, message, { test = false } = {}) {
  const cfg = (await chrome.storage.local.get(DISCORD_KEY))[DISCORD_KEY];
  const url = String(cfg?.url || "").trim();
  if (!WEBHOOK_RE.test(url)) return test ? { ok: false, error: "URL de webhook inválida." } : null;
  // Desde a 2.0 o Discord é permissão opcional: sem ela, não envia (quem vem da 1.x precisa permitir em Opções).
  const allowed = await chrome.permissions.contains({ origins: ["https://discord.com/api/webhooks/*", "https://discordapp.com/api/webhooks/*"] }).catch(() => false);
  if (!allowed) return test ? { ok: false, error: "Falta permitir o Discord: abra Opções do Timoneiro e clique em Salvar." } : null;
  const cat = CATEGORY[id] || "alerts";
  if (!test && cfg[cat] !== true) return null;
  const body = JSON.stringify({ username: "Timoneiro", content: `**${title}**\n${message}`.slice(0, 1900), allowed_mentions: { parse: [] } });
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body, signal: AbortSignal.timeout(10000) });
      if (r.ok) return { ok: true };
      if (r.status === 429 && attempt === 0) { await new Promise((ok) => setTimeout(ok, Math.min(15, Number(r.headers.get("Retry-After")) || 3) * 1000)); continue; }
      return { ok: false, error: r.status === 404 || r.status === 401 ? "O Discord não reconheceu esse webhook (apagado ou copiado pela metade)." : `O Discord respondeu ${r.status}.` };
    } catch (_) { return { ok: false, error: "Sem resposta do Discord." }; }
  }
  return { ok: false, error: "O Discord pediu para esperar. Tente de novo." };
}

// ---------- eventos ----------
function eventNotices(list, boat, m, prefs, now) {
  const out = [];
  const E = globalThis.TimoneiroEvents;
  const minRank = E.LEVEL_RANK[prefs.eventLevel === "alta" ? "alta" : prefs.eventLevel === "media" ? "media" : "desconhecida"];
  const seen = new Set();
  for (const e of list) {
    if (Number.isFinite(e.endsAt) && e.endsAt <= now) continue;
    const key = `${boat}|${e.slot === "grand" ? "grand" : "regular"}|${e.name}`;
    seen.add(key);
    const prev = m.events[key];
    const isNew = !prev || (Number.isFinite(prev.endsAt) && now > prev.endsAt + 60000);
    const passes = E.LEVEL_RANK[e.relevance] >= minRank;
    const head = `${e.emoji ? `${e.emoji} ` : ""}${e.name}`;
    const detail = `${e.message || e.relevanceWhy}${Number.isFinite(e.endsAt) ? ` (termina ${new Date(e.endsAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })})` : ""}\nRelevância: ${E.LEVEL_LABEL[e.relevance]}.`;
    if (isNew) {
      if (passes) out.push(["timoneiro-event", `Evento: ${head}`, detail, { desktop: isOn(prefs.event), sound: ["event", `${boat}|${e.name}|${Number.isFinite(e.endsAt) ? Math.round(e.endsAt / 60000) : "x"}`] }]);
      m.events[key] = { fp: e.fingerprint, endsAt: e.endsAt, at: now, notified: passes, misses: 0 };
    } else {
      if (prev.fp !== e.fingerprint && prev.notified && e.relevance === "alta") out.push(["timoneiro-event", `Evento mudou: ${head}`, detail, { desktop: isOn(prefs.event) }]);
      Object.assign(prev, { fp: e.fingerprint, endsAt: e.endsAt ?? prev.endsAt, at: now, misses: 0 });
    }
  }
  // Fim: o evento sumiu em duas leituras seguidas (a API às vezes "pisca").
  for (const [key, prev] of Object.entries(m.events)) {
    if (!key.startsWith(`${boat}|`) || seen.has(key)) continue;
    prev.misses = (prev.misses || 0) + 1;
    if (prev.misses < 2 && !(Number.isFinite(prev.endsAt) && now >= prev.endsAt)) continue;
    if (prev.notified && prefs.eventEnd === true) out.push(["timoneiro-event-end", `Evento terminou: ${key.split("|")[2]}`, "Volte ao ritmo normal do Guia.", { desktop: isOn(prefs.event) }]);
    delete m.events[key];
  }
  return out;
}

async function onStoredChange(changes, area) {
  if (area !== "local") return;
  if (!changes[FISHING_KEY] && !changes[EVENTS_KEY] && !changes[GUIDE_KEY] && !changes[MARKET_HITS_KEY]) return;
  const prefs = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  const discord = (await chrome.storage.local.get(DISCORD_KEY))[DISCORD_KEY] || {};
  const m = await memo();
  const now = Date.now();
  const notices = [];

  const fishing = changes[FISHING_KEY]?.newValue;
  if (fishing && Number.isFinite(fishing.updatedAt) && now - fishing.updatedAt < 30000) {
    const prev = m.fishing;
    if (fishing.status === "cooldown" && Number.isFinite(fishing.readyAt) && fishing.readyAt > now) {
      if (prev?.readyAt !== fishing.readyAt) { try { await chrome.alarms.create(FISH_ALARM, { when: fishing.readyAt + 500 }); } catch (_) {} }
      m.fishing = { status: "cooldown", boat: fishing.boat, readyAt: fishing.readyAt, at: now };
    } else if (fishing.status === "available") {
      if (prev?.status === "cooldown" && prev.boat === fishing.boat && now - prev.at < 15 * 60000 && prev.readyAt && now >= prev.readyAt - 3000 && now - prev.readyAt < 120000) {
        const key = fishKey(prev.boat, prev.readyAt);
        if (!m.keys[key]) notices.push([...FISH_NOTICE, { desktop: isOn(prefs.fishing), sound: ["fishing", `${prev.boat}|${Math.round(prev.readyAt / 10000)}`] }]);
        m.keys[key] = m.keys[key] || now;
      }
      m.fishing = { status: "available", boat: fishing.boat, at: now };
    }
  }

  const events = changes[EVENTS_KEY]?.newValue;
  if (events && Array.isArray(events.list) && Number.isFinite(events.at) && now - events.at < 60000) notices.push(...eventNotices(events.list, events.boat, m, prefs, now));

  const guide = changes[GUIDE_KEY]?.newValue;
  if (guide?.alerts) {
    for (const a of guide.alerts) {
      const key = `al|${a.key}`;
      if (m.keys[key]) continue;
      m.keys[key] = now;
      notices.push([`timoneiro-${a.type}`, a.title, a.message, { desktop: isOn(prefs.event), sound: a.type === "tournament" || a.type === "fleet" ? ["event", a.key] : null }]);
    }
  }

  const market = changes[MARKET_HITS_KEY]?.newValue;
  if (market?.hits) {
    for (const h of market.hits) {
      const key = `mk|${h.key}`;
      if (m.keys[key]) continue;
      m.keys[key] = now;
      notices.push(["timoneiro-market", `Mercado: ${h.name} por ${h.price}`, `${h.seller ? `Anunciado por ${h.seller}. ` : ""}Abaixo do seu limite. Clique para abrir o Mercado.`, { desktop: isOn(prefs.market) }]);
    }
  }

  await chrome.storage.local.set({ [MEMO_KEY]: m });
  for (const [id, title, message, opts] of notices) await notify(id, title, message, opts);
}

// Alarme na hora em que o cooldown acaba.
async function onFishAlarm() {
  const r = await chrome.storage.local.get([FISHING_KEY, PREFS_KEY, DISCORD_KEY]);
  const prefs = r[PREFS_KEY] || {};
  const st = r[FISHING_KEY];
  const m = await memo();
  const ready = m.fishing?.status === "cooldown" ? m.fishing.readyAt : null;
  // o cooldown ainda é o mesmo que armou o alarme e já venceu?
  if (!ready || Date.now() < ready - 1000 || (st?.status === "cooldown" && Number.isFinite(st.readyAt) && Math.abs(st.readyAt - ready) > 3000)) return;
  const key = fishKey(m.fishing.boat, ready);
  const send = !m.keys[key];
  m.keys[key] = m.keys[key] || Date.now();
  await chrome.storage.local.set({ [MEMO_KEY]: m });
  if (send) await notify(...FISH_NOTICE, { desktop: isOn(prefs.fishing), sound: ["fishing", `${m.fishing.boat}|${Math.round(ready / 10000)}`] });
}
chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name !== FISH_ALARM) return;
  noticeChain = noticeChain.then(onFishAlarm).catch((e) => console.warn("Timoneiro: alarme de pesca.", e));
});

chrome.storage.onChanged.addListener((changes, area) => {
  noticeChain = noticeChain.then(() => onStoredChange(changes, area)).catch(error => {
    console.warn("Timoneiro: falha ao acompanhar notificações.", error);
  });
});

// ---------- clique na notificação: abre o chat e preenche o comando ----------
async function openChat(fill) {
  const r = await chrome.storage.local.get(BOAT_KEY);
  const channel = r[BOAT_KEY]?.boat || null;
  // Ainda sem barco (pessoa nova): abre o Twish para escolher um.
  if (!channel) { await chrome.tabs.create({ url: "https://twish.com.br/" }); return null; }
  const tabs = await chrome.tabs.query({ url: ["https://www.twitch.tv/*"] });
  const re = new RegExp(`^https://www\\.twitch\\.tv/(?:popout/|moderator/)?${channel.replace(/[^a-z0-9_]/gi, "")}(?:[/?#]|$)`, "i");
  let tab = tabs.find((t) => re.test(t.url || ""));
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    tab = await chrome.tabs.create({ url: `https://www.twitch.tv/${channel}` });
  }
  if (!fill) return tab;
  // A página nova leva alguns segundos para montar o chat; tenta algumas vezes.
  for (let i = 0; i < 8; i++) {
    try { const ok = await chrome.tabs.sendMessage(tab.id, { type: "timoneiro-fill", command: fill }); if (ok) return tab; } catch (_) {}
    await new Promise((ok) => setTimeout(ok, 1500));
  }
}
// ---------- versão nova: notificação só para as marcadas como importantes, uma vez por versão ----------
chrome.storage.onChanged.addListener((changes, area) => {
  const u = area === "local" && changes["timoneiro.update.v1"]?.newValue;
  if (!u || !u.available || !u.latest?.important) return;
  chrome.storage.local.get("timoneiro.updateNotified.v1").then((r) => {
    if (r["timoneiro.updateNotified.v1"] === u.latest.version) return;
    chrome.storage.local.set({ "timoneiro.updateNotified.v1": u.latest.version });
    chrome.notifications.create(`timoneiro-update-${u.latest.version}`, { type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), title: `Timoneiro ${u.latest.version} disponível`, message: "Uma atualização importante saiu. Clique para ver como atualizar." }).catch(() => {});
  });
});
chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith("timoneiro-update-")) { chrome.notifications.clear(notificationId); chrome.tabs.create({ url: chrome.runtime.getURL("pages/update.html") }); return; }
  const id = Object.keys(CATEGORY).find((k) => notificationId.startsWith(`${k}-`));
  if (!id) return;
  chrome.notifications.clear(notificationId);
  if (id === "timoneiro-market") { chrome.storage.local.get(BOAT_KEY).then((r) => chrome.tabs.create({ url: r[BOAT_KEY]?.boat ? `https://twish.com.br/c/${encodeURIComponent(r[BOAT_KEY].boat)}/market` : "https://twish.com.br/" })); return; }
  openChat(CLICK_FILL[id]).catch((e) => console.warn("Timoneiro: não foi possível abrir o chat.", e));
});

// ---------- mensagens das abas ----------
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  // Só mensagens do próprio Timoneiro (abas com os content scripts e páginas da extensão).
  if (_sender?.id !== chrome.runtime.id) return false;
  if (msg?.type === "timoneiro-cast") { TimoneiroSync.afterCast(); return false; }
  if (msg?.type === "timoneiro-sync-now") {
    // Pedido da Twitch (aba voltou a ficar visível, Guia aberto): no máximo 1 leitura completa a cada 15 s.
    if (Date.now() - lastForcedSync < 15000) { reply({ ok: true, skipped: true }); return false; }
    lastForcedSync = Date.now();
    TimoneiroSync.syncOnce({ force: true }).then(() => reply({ ok: true }), () => reply({ ok: false })); return true;
  }
  if (msg?.type === "timoneiro-check-update") { TimoneiroSync.checkUpdate({ force: true }).then(reply, () => reply(null)); return true; }
  if (msg?.type === "timoneiro-open-options") { chrome.runtime.openOptionsPage().catch(() => {}); return false; }
  if (msg?.type === "timoneiro-open-chat") { openChat(null).then(() => reply({ ok: true }), () => reply({ ok: false })); return true; }
  if (msg?.type === "timoneiro-open-guide") {
    // Popup: foca a live do barco e abre o Guia nela.
    (async () => {
      const tab = await openChat(null);
      for (let i = 0; tab && i < 8; i++) {
        try { if (await chrome.tabs.sendMessage(tab.id, { type: "timoneiro-open-guide" })) break; } catch (_) {}
        await new Promise((ok) => setTimeout(ok, 1500));
      }
      reply({ ok: !!tab });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-sync-events") { TimoneiroSync.syncOnce(); return false; }
  if (msg?.type === "timoneiro-channels-refresh") {
    // A aba da Twitch abriu um canal que não está na lista guardada: confere a lista pública.
    TimoneiroSync.refreshChannels({ channel: TimoneiroBoats.slug(msg.channel) || null }).then(() => reply({ ok: true }), () => reply({ ok: false })); return true;
  }
  if (msg?.type === "timoneiro-keep-tab" && _sender?.tab?.id != null) {
    // A aba que ouve o tempo real não pode ser descarregada pela economia de memória do navegador.
    chrome.tabs.update(_sender.tab.id, { autoDiscardable: !msg.on }).catch(() => {});
    return false;
  }
  if (msg?.type === "timoneiro-diagnostics") {
    (async () => {
      const level = chrome.notifications.getPermissionLevel ? await new Promise((ok) => chrome.notifications.getPermissionLevel(ok)) : "granted";
      const alarms = await chrome.alarms.getAll();
      reply({ notifications: level, alarms: alarms.map((a) => ({ name: a.name, period: a.periodInMinutes || null, next: a.scheduledTime })), offscreen: !!chrome.offscreen, audio: typeof Audio === "function", version: chrome.runtime.getManifest().version, ua: navigator.userAgent });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-test-alert") {
    (async () => {
      await chrome.notifications.create(`timoneiro-test-${Date.now()}`, { type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), title: "Teste do Timoneiro", message: "Se você viu esta notificação e ouviu o som, os avisos funcionam em outra aba.", silent: true }).catch(() => {});
      const r = (await chrome.storage.local.get(SOUND_KEY))[SOUND_KEY] || {};
      const played = await playAsset("sounds/pesca.wav", ((r.fishingAlert?.volume) || 7) / 10);
      reply({ ok: true, played });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-discord-test") { postDiscord("timoneiro-event", "Teste do Timoneiro", "Se você está lendo isto, os avisos vão chegar aqui.", { test: true }).then(reply); return true; }
  return false;
});

// ---------- primeira instalação: página de boas-vindas ----------
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("pages/welcome.html") }).catch(() => {}); });

// ---------- instalou ou atualizou: os scripts entram nas abas já abertas ----------
// O navegador não põe os scripts novos em abas que já estavam abertas, e os antigos param (core/alive.js
// tira a barra velha). Aqui a versão nova entra na hora, sem precisar recarregar a Twitch e o Twish.
async function injectOpenTabs() {
  for (const cs of chrome.runtime.getManifest().content_scripts || []) {
    let tabs = [];
    try { tabs = await chrome.tabs.query({ url: cs.matches }); } catch (_) { continue; }
    for (const t of tabs) {
      if (t.discarded || !t.id) continue;
      const target = { tabId: t.id, allFrames: !!cs.all_frames };
      try {
        if (cs.css?.length) await chrome.scripting.insertCSS({ target, files: cs.css });
        await chrome.scripting.executeScript({ target, files: cs.js });
      } catch (_) { /* aba carregando ou sem acesso: ela recebe os scripts ao recarregar */ }
    }
  }
}
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "install" || d.reason === "update") injectOpenTabs(); });

// ---------- pasta descompactada: arquivos novos no disco → recarrega sozinho ----------
// Quem atualiza extraindo o zip por cima da pasta (ou pelo ajudante) não precisa clicar em
// Recarregar: o fundo lê o manifest.json do disco e, se a versão for maior e o arquivo estiver
// inteiro, recarrega a extensão. Confere a cada 30 min, e a cada 1 min com a página de atualização aberta.
var TimoneiroFiles = (() => {
  const ALARM = "timoneiro-files", WATCH = "timoneiro.watchFiles.v1", PENDING = "timoneiro.filesPending.v1";
  async function unpacked() {
    try { return (await chrome.management.getSelf()).installType === "development"; } catch (_) { return !("update_url" in chrome.runtime.getManifest()); }
  }
  async function check() {
    if (!(await unpacked())) return "loja";
    let disk = null;
    try { disk = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json(); } catch (_) { return "incompleto"; }
    if (!disk || !/^\d+(\.\d+){1,3}$/.test(disk.version || "") || !disk.background) return "incompleto";
    if (TimoneiroUpdate.compare(disk.version, chrome.runtime.getManifest().version) <= 0) return "igual";
    // Quem extrai o zip por cima pode ter o manifest novo antes dos outros arquivos: só recarrega
    // quando a mesma versão nova continua lá pelo menos 15 s depois (confere de novo em 30 s).
    const p = (await chrome.storage.local.get(PENDING))[PENDING];
    if (!p || p.version !== disk.version) {
      await chrome.storage.local.set({ [PENDING]: { version: disk.version, at: Date.now() } });
      chrome.alarms.create(ALARM + "-confirmar", { delayInMinutes: 0.5 });
      return "conferindo";
    }
    if (Date.now() - p.at < 15e3) return "conferindo";
    await chrome.storage.local.remove(PENDING);
    chrome.runtime.reload();
    return "recarregando";
  }
  async function schedule() {
    const w = (await chrome.storage.local.get(WATCH))[WATCH] || 0;
    const fast = Date.now() < w;
    const a = await chrome.alarms.get(ALARM);
    const period = fast ? 1 : 30;
    if (!a || a.periodInMinutes !== period) await chrome.alarms.create(ALARM, { delayInMinutes: period, periodInMinutes: period });
  }
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM || a.name === ALARM + "-confirmar") check().then(schedule).catch(() => {}); });
  chrome.runtime.onMessage.addListener((msg, sender) => {
    if (sender?.id !== chrome.runtime.id || msg?.type !== "timoneiro-watch-files") return false;
    chrome.storage.local.set({ [WATCH]: msg.on ? Date.now() + 30 * 60e3 : 0 }).then(schedule);
    return false;
  });
  schedule();
  return { check, schedule };
})();
