// Timoneiro — sincronização em segundo plano (roda no service worker).
// Antes, toda leitura dependia da aba do twish.com.br. Com a aba em segundo plano o navegador
// roda os timers dela 1x por minuto, e a Economia de memória (Chrome) / Guias em suspensão (Edge)
// descarregam a aba: aí nada mais era lido nem notificado. Agora o service worker lê sozinho,
// acordado por chrome.alarms, mesmo sem nenhuma aba do Twish aberta.
// Só leituras (GET). Nunca escreve no chat, nunca compra, vende ou pesca.
//  - A cada ~30 s: /events/active e /shop (públicos) e, se a aba do Twish não estiver ativa,
//    /me (sua conta, com a sessão do navegador).
//  - A cada ~60 s, se a aba não estiver ativa: /me/inventory e /titles, para o Guia e os seletores.
//  - Logo depois de você mandar $pescar na Twitch: relê /me para marcar o próximo cooldown.
/* global TimoneiroStatus, TimoneiroEvents, TimoneiroHistory, TimoneiroForecast */
var TimoneiroSync = (() => {
  "use strict";
  const ORIGIN = "https://twish.com.br";
  const ALARM = "timoneiro-sync";
  const K = {
    boat: "timoneiro.boat.v2",
    leader: "timoneiro.tabLeader.v1",
    fishing: "timoneiro.fishingStatus.v1",
    event: "timoneiro.eventStatus.v1",
    events: "timoneiro.events.v2",
    smart: "timoneiro.smartData.v1",
    syncStatus: "timoneiro.syncStatus.v1",
    bg: "timoneiro.bgSync.v1",
    history: "timoneiro.history.v1",
    eventHistory: "timoneiro.eventHistory.v1",
    syncReq: "timoneiro.syncRequest.v1",
    lastRate: "timoneiro.lastDiscountRate.v1",
    eventLog: "timoneiro.eventLog.v1",
    marketWatch: "timoneiro.marketWatch.v1",
    marketHits: "timoneiro.marketHits.v1",
  };
  const MARKET_EVERY_MS = 10 * 60e3;
  const TAB_HEALTHY_MS = 15000;   // a aba líder bate a cada 2 s; sem batida há 15 s, ela está dormindo
  const SMART_EVERY_MS = 55000;
  let running = null;
  // O service worker é encerrado entre alarmes: pausa (429) e última leitura completa ficam no storage.
  let pausedUntil = 0, lastSmartAt = 0;

  const slug = (v) => String(v || "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_]/g, "");
  // Sem barco escolhido (pessoa nova que ainda não abriu a live de um barco): null.
  async function boatName() { const r = await chrome.storage.local.get(K.boat); return slug(r[K.boat]?.boat) || null; }

  // Lista pública de barcos (/api/channels): decide em quais canais da Twitch o Timoneiro aparece.
  // Pública e sem login: vai sem cookies. Falhou? Fica o cache anterior.
  // Falhou (Twish fora do ar, 429)? Espera 1, 2, 4... até 30 min antes de tentar de novo. A espera fica
  // no storage porque o service worker é encerrado entre os alarmes de 30 s.
  const CHANNELS = "timoneiro.channels.v1", SEEN = "timoneiro.channels.seen.v1", RETRY = "timoneiro.channels.retry.v1";
  async function refreshChannels({ channel = null, force = false } = {}) {
    const r = await chrome.storage.local.get([CHANNELS, SEEN, RETRY]);
    let cache = r[CHANNELS] || null;
    const now = Date.now();
    const retry = r[RETRY] || null;
    if ((force || TimoneiroBoats.needsRefresh(cache, now, channel)) && !(retry && now < retry.nextTryAt)) {
      let list = null;
      try {
        const res = await fetch(`${ORIGIN}/api/channels`, { credentials: "omit", cache: "no-store", signal: AbortSignal.timeout(10000) });
        list = res.ok ? TimoneiroBoats.parseChannels(await res.json()) : null;
      } catch (_) { /* fica o cache anterior */ }
      if (list && list.length) {
        cache = { list, fetchedAt: now };
        await chrome.storage.local.set({ [CHANNELS]: cache });
        if (retry) await chrome.storage.local.remove(RETRY);
      } else {
        const fails = (retry?.fails || 0) + 1;
        await chrome.storage.local.set({ [RETRY]: { fails, nextTryAt: now + Math.min(30 * 60e3, 60e3 * 2 ** (fails - 1)) } });
      }
    }
    if (channel && cache?.list?.includes(channel)) {
      const seen = Array.isArray(r[SEEN]) ? r[SEEN] : [];
      if (!seen.includes(channel)) await chrome.storage.local.set({ [SEEN]: [channel, ...seen].slice(0, 50) });
    }
    return cache;
  }

  async function get(path, withSession) {
    const r = await fetch(`${ORIGIN}${path}`, { credentials: withSession ? "include" : "omit", cache: "no-store", signal: AbortSignal.timeout(10000) });
    if (r.status === 429) { pausedUntil = Date.now() + 120000; throw Object.assign(new Error("429"), { status: 429 }); }
    if (!r.ok) throw Object.assign(new Error(String(r.status)), { status: r.status });
    return r.json();
  }

  function findCooldown(data, depth = 0) {
    if (!data || typeof data !== "object" || depth > 3) return null;
    if (Number.isFinite(data.cooldown_remaining)) return { cooldown_remaining: data.cooldown_remaining };
    for (const k of ["cooldown_seconds", "fishing_cooldown_remaining", "cast_cooldown_remaining"]) if (Number.isFinite(data[k])) return { cooldown_remaining: data[k] };
    for (const v of Object.values(data)) if (v && typeof v === "object" && !Array.isArray(v)) { const f = findCooldown(v, depth + 1); if (f) return f; }
    return null;
  }

  async function tabHealthy(boat) {
    const r = await chrome.storage.local.get([K.leader, K.smart]);
    const beat = r[K.leader]?.at || 0;
    const smart = r[K.smart];
    return Date.now() - beat < TAB_HEALTHY_MS && smart?.boat === boat && smart?.source !== "background" && Date.now() - (smart.updatedAt || 0) < 90000;
  }

  async function syncOnce({ force = false } = {}) {
    if (running) return running;
    running = (async () => {
      await TimoneiroKeys.ready(); // nomes antigos (pescaskills.*) migrados antes de ler
      const prev = (await chrome.storage.local.get(K.bg))[K.bg] || {};
      pausedUntil = Math.max(pausedUntil, prev.pausedUntil || 0);
      lastSmartAt = Math.max(lastSmartAt, prev.smartAt || 0);
      if (Date.now() < pausedUntil) return;
      const boat = await boatName();
      if (!boat) { await chrome.storage.local.set({ [K.bg]: { at: Date.now(), boat: null, events: "sem barco", me: "skip", tab: false } }); return; }
      const base = `/api/${encodeURIComponent(boat)}`;
      const at = Date.now();
      const status = { at, boat, events: "ok", me: "skip", tab: false };
      const healthy = await tabHealthy(boat);
      status.tab = healthy;

      // 1) Eventos e loja: públicos.
      let shop = null;
      try {
        const [payload, shopData] = await Promise.all([get(`${base}/events/active`, false), get(`${base}/shop`, true).catch((e) => { if (e.status === 429) throw e; return null; })]);
        shop = shopData;
        const list = TimoneiroEvents.extract(payload, shop, at);
        const disc = list.find((e) => e.kind === "store_discount" && e.rate);
        const writes = { [K.events]: { boat, at, list, source: "background" } };
        // Previsão: guarda cada evento visto e as horas em que o Timoneiro estava lendo.
        writes[K.eventLog] = TimoneiroForecast.record((await chrome.storage.local.get(K.eventLog))[K.eventLog], list, at, boat);
        if (disc) writes[K.lastRate] = { rate: disc.rate, at };
        if (!healthy) {
          const parsed = TimoneiroStatus.eventFromApi(payload, at, at);
          if (parsed) {
            const main = list.find((e) => e.slot !== "shop");
            writes[K.event] = { ...parsed, apiKind: main?.kind || null, boat, updatedAt: at, source: "background" };
          }
          const saved = await chrome.storage.local.get(K.eventHistory);
          const evs = [payload?.event, payload?.grande_evento].flatMap((e, i) => (e && Number.isFinite(e.seconds_remaining) ? [{ name: e.name, endsAt: at + e.seconds_remaining * 1000, kind: i === 1 ? "grand" : "regular", source: "background" }] : []));
          writes[K.eventHistory] = TimoneiroStatus.historyUpdate(saved[K.eventHistory], evs, at);
        }
        await chrome.storage.local.set(writes);
      } catch (e) { status.events = e.status === 429 ? "rate" : `erro ${e.status || ""}`.trim(); }

      // 2) Sua conta: só quando a aba do Twish está parada (ou logo depois de um $pescar).
      if (!healthy || force) {
        try {
          const me = await get(`${base}/me`, true);
          status.me = "ok";
          const found = findCooldown(me);
          if (found) {
            const p = TimoneiroStatus.fishingFromApi(found, at, at);
            if (p) await chrome.storage.local.set({ [K.fishing]: { status: p.status, cooldown: p.cooldown || null, readyAt: p.status === "available" ? at : p.readyAt, via: "api", source: "background", boat, updatedAt: at } });
          }
          await recordHistory(boat, me, at);
          if (!healthy && (force || at - lastSmartAt >= SMART_EVERY_MS)) {
            const [inventory, titles] = await Promise.all([get(`${base}/me/inventory`, true), get(`${base}/titles`, true)]);
            lastSmartAt = at;
            const now = Date.now();
            await chrome.storage.local.set({
              [K.smart]: { boat, data: { me, inventory, shop: shop || {}, titles }, fetchedAt: { me: now, inventory: now, shop: now, titles: now }, updatedAt: now, source: "background" },
              [K.syncStatus]: { state: "ok", boat, at: now, source: "background" },
            });
          }
        } catch (e) {
          status.me = e.status === 401 || e.status === 403 ? "login" : e.status === 429 ? "rate" : e.status === 404 ? "boat" : `erro ${e.status || ""}`.trim();
        }
      } else {
        // A aba está lendo a conta: aproveita o /me dela para o histórico.
        const r = await chrome.storage.local.get(K.smart);
        if (r[K.smart]?.boat === boat && r[K.smart]?.data?.me) await recordHistory(boat, r[K.smart].data.me, at);
        status.me = "tab";
      }
      if (Date.now() >= pausedUntil && (force || at - (prev.marketAt || 0) >= MARKET_EVERY_MS)) { status.market = await checkMarket(boat, base).catch(() => "erro"); status.marketAt = at; }
      else status.marketAt = prev.marketAt || 0;
      await chrome.storage.local.set({ [K.bg]: { ...status, smartAt: lastSmartAt, pausedUntil, okAt: status.me === "ok" || status.me === "tab" ? at : prev.okAt || null } });
    })().finally(() => { running = null; });
    return running;
  }

  // Alertas de preço do Mercado (v1.11.0): para cada espécie da sua lista, procura anúncios
  // até o preço que você definiu. Até 5 espécies, uma leitura a cada 1,5 s, a cada 10 min.
  async function checkMarket(boat, base) {
    const watch = ((await chrome.storage.local.get(K.marketWatch))[K.marketWatch] || []).filter((w) => w && w.id && w.name && w.max > 0).slice(0, 5);
    if (!watch.length) return "vazio";
    const hits = [];
    for (const w of watch) {
      try {
        const r = await get(`${base}/market/listings?q=${encodeURIComponent(w.name)}&page_size=50`, true);
        for (const x of r?.listings || []) {
          if (x.item_id || x.fish_id !== w.id || !(x.asking_price <= w.max)) continue;
          if (!w.asc && Number(x.ascension_level) > 0) continue;
          hits.push({ id: w.id, name: w.name, price: x.asking_price, base: x.base_price ?? null, seller: x.seller ?? null, asc: Number(x.ascension_level) || 0, key: `${boat}|${x.id ?? `${x.seller}|${x.asking_price}|${x.listed_at ?? ""}`}` });
        }
      } catch (e) { if (e.status === 429) throw e; }
      await new Promise((ok) => setTimeout(ok, 1500));
    }
    hits.sort((a, b) => a.price - b.price);
    await chrome.storage.local.set({ [K.marketHits]: { boat, at: Date.now(), hits: hits.slice(0, 20) } });
    return "ok";
  }

  async function recordHistory(boat, me, at) {
    const sample = TimoneiroHistory.sampleFromMe(me, at);
    if (!sample) return;
    const r = await chrome.storage.local.get(K.history);
    const next = TimoneiroHistory.record(r[K.history], sample, boat);
    if (next.samples.length !== (r[K.history]?.samples?.length || 0) || next.samples[next.samples.length - 1] !== r[K.history]?.samples?.at(-1)) await chrome.storage.local.set({ [K.history]: next });
  }

  // Você mandou $pescar na Twitch: relê a conta em 3 s e de novo em 10 s (o bot leva um tempo).
  let castTimers = [];
  function afterCast() {
    castTimers.forEach(clearTimeout);
    castTimers = [3000, 10000].map((ms) => setTimeout(() => syncOnce({ force: true }), ms));
  }

  async function ensureAlarm() {
    const a = await chrome.alarms.get(ALARM);
    if (!a || !a.periodInMinutes || a.periodInMinutes > 0.5) await chrome.alarms.create(ALARM, { delayInMinutes: 0.1, periodInMinutes: 0.5 });
  }

  // A lista de barcos só é baixada de novo quando o cache venceu (24 h).
  chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === ALARM) { refreshChannels().catch(() => {}); checkUpdate().catch(() => {}); syncOnce(); } });
  chrome.runtime.onStartup.addListener(() => { ensureAlarm(); refreshChannels().catch(() => {}); syncOnce(); });
  chrome.runtime.onInstalled.addListener(() => { ensureAlarm(); refreshChannels().catch(() => {}); syncOnce(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[K.syncReq]) syncOnce({ force: true });
    if (changes[K.boat]) { lastSmartAt = 0; chrome.storage.local.remove(K.bg).then(() => syncOnce({ force: true })); }
  });
  ensureAlarm();

  // Versão nova publicada? Uma vez por dia (ou na hora, pelo botão), só GET e sem cookies.
  // Se a leitura falhou (sem internet, site fora do ar), tenta de novo em 1 h em vez de esperar o dia todo.
  const UPDATE = "timoneiro.update.v1", DAY = 24 * 3600e3, UPDATE_RETRY = 3600e3;
  async function checkUpdate({ force = false } = {}) {
    const prev = (await chrome.storage.local.get(UPDATE))[UPDATE] || {};
    if (!force && Date.now() - (prev.checkedAt || 0) < (prev.ok === false ? UPDATE_RETRY : DAY)) return prev;
    const installed = chrome.runtime.getManifest().version;
    let latest = null, ok = false;
    try {
      const r = await fetch(TimoneiroUpdate.LATEST_URL, { credentials: "omit", cache: "no-store", signal: AbortSignal.timeout(10000) });
      latest = r.ok ? TimoneiroUpdate.parse(await r.json()) : null;
      ok = !!latest && (await TimoneiroUpdate.verify(latest));
    } catch (_) { /* sem internet ou site fora do ar: sem aviso */ }
    const next = { checkedAt: Date.now(), installed, ok, latest: ok ? latest : null, available: ok && TimoneiroUpdate.newer(latest, installed) };
    await chrome.storage.local.set({ [UPDATE]: next });
    return next;
  }

  return { syncOnce, afterCast, refreshChannels, boatName, checkUpdate, K };
})();
