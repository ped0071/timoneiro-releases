// Timoneiro — menu (modelo D): grade de abas, busca, comandos em linhas com ☆, seletores
// (isca, venda, compra, título, duelo), Ajustes e o Guia. Tudo só escreve no chat.
(function (root) {
  "use strict";
  if (root.TimoneiroMenu) return;
  const Store = root.TimoneiroStore, St = root.TimoneiroStatus, Cmd = root.TimoneiroCommands, Chat = root.TimoneiroChat, Gate = root.TimoneiroChannel;
  const K = { smart: "timoneiro.smartData.v1", fishing: "timoneiro.fishingStatus.v1", event: "timoneiro.eventStatus.v1", history: "timoneiro.eventHistory.v1", boat: "timoneiro.boat.v2" };
  const TABS = [{ id: "guia", icon: "🧭", label: "Guia" }, ...Cmd.GROUPS.map(({ id, icon, label }) => ({ id, icon, label })), { id: "ajustes", icon: "⚙", label: "Ajustes" }];
  const make = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const button = (cls, txt, onClick) => { const b = make("button", cls, txt); b.type = "button"; if (onClick) b.addEventListener("click", onClick); return b; };
  const $panel = () => document.getElementById("tmn-panel");
  const boat = () => root.TimoneiroBoat?.get() || null;
  let active = "guia";

  // ---------- executar um comando ----------
  function run(id, { fromBar = false } = {}) {
    const c = Cmd.find(id);
    if (!c) return;
    if (c.url) { window.open(root.TimoneiroBoat?.url(c.url) || "https://twish.com.br/", "_blank", "noopener,noreferrer"); return; }
    if (c.kind) { open(c.group); picker(c); return; }
    const fn = c.id === "$pescar" ? root.TimoneiroBar?.fishingNow() : null;
    const fish = fn?.state || null, info = { fish, left: fn?.left };
    if (fish === "cooldown") { if (fromBar && Chat.clickSend()) Chat.noteSend("cooldown", info); return; } // ainda não libera
    if (!Chat.findEditor()) { if (fromBar && fish && Chat.clickSend()) Chat.noteSend("no-editor", info); return; }
    Chat.fill(c.cmd); // o editor da Twitch pode redesenhar depois; o envio confere o texto com calma
    if (!fromBar) close(false);
    if (fromBar && fish === "available") Chat.sendFishingOnce(info);
    else if (fromBar && fish === "unknown" && Chat.clickSend()) Chat.noteSend("unknown", info);
  }

  // ---------- painel ----------
  function mount() {
    if ($panel()) return;
    const p = make("section"); p.id = "tmn-panel"; p.dataset.open = "false";
    p.setAttribute("role", "dialog"); p.setAttribute("aria-label", "Menu do Timoneiro");
    const head = make("div", "tmn-head");
    const logo = make("img"); logo.alt = ""; logo.width = 26; logo.height = 26;
    try { logo.src = chrome.runtime.getURL("assets/timoneiro-logo.png"); } catch (_) {}
    head.append(logo, make("span", "tmn-head-title", "Timoneiro"), make("span", "tmn-head-boat"), (() => { const x = button("tmn-close", null, () => close()); x.append(root.TimoneiroIcons.icon("close", 14)); return x; })());
    head.querySelector(".tmn-close").setAttribute("aria-label", "Fechar o menu");
    const search = make("input", "tmn-search");
    const tabs = make("div", "tmn-tabs"); tabs.setAttribute("role", "tablist");
    for (const t of TABS) {
      const b = button("tmn-tab", null, () => { search.value = ""; show(t.id); });
      b.dataset.tab = t.id; b.setAttribute("role", "tab");
      b.append(make("span", null, t.icon), make("span", null, t.label));
      b.firstChild.setAttribute("aria-hidden", "true");
      tabs.append(b);
    }
    search.type = "search"; search.placeholder = "Buscar comando (ex.: vender)"; search.setAttribute("aria-label", "Buscar comando");
    search.addEventListener("input", () => (search.value.trim() ? results(search.value) : show(active)));
    const list = make("div", "tmn-list"); list.setAttribute("role", "tabpanel");
    const foot = make("div", "tmn-foot");
    let version = "";
    try { version = chrome.runtime.getManifest().version; } catch (_) {}
    // Aviso curto no rodapé (o leitor de tela também lê): "Isca foi para a barra (6/6)".
    const st = make("span", "tmn-status"); st.setAttribute("role", "status"); st.setAttribute("aria-live", "polite");
    foot.append(make("span", "tmn-version", `Timoneiro • v${version}`), st, make("span", "tmn-count"));
    p.append(head, tabs, search, list, foot);
    p.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); if (search.value) { search.value = ""; show(active); } else close(); } });
    document.body.append(p);
    root.TimoneiroTheme?.apply();
    show(active);
  }
  function unmount() { $panel()?.remove(); }

  const list = () => $panel()?.querySelector(".tmn-list");
  let statusTimer = null;
  function status(msg) {
    const el = $panel()?.querySelector(".tmn-status");
    if (!el) return;
    el.textContent = msg;
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { el.textContent = ""; }, 4000);
  }
  function updateCount() {
    const el = $panel()?.querySelector(".tmn-count");
    if (el) el.textContent = `Atalhos ${root.TimoneiroBar?.quickIds().length ?? 0}/${root.TimoneiroBar?.MAX ?? 6}`;
  }
  function header() {
    const b = boat(), el = $panel()?.querySelector(".tmn-head-boat");
    if (el) el.textContent = b ? `barco ${b}` : "abra a live de um barco";
  }

  function open(tab) {
    mount();
    const p = $panel();
    p.dataset.open = "true";
    document.querySelector("#tmn-root .tmn-menu")?.setAttribute("aria-expanded", "true");
    position(); header(); updateCount();
    if (tab) show(tab); else if (active === "guia") show("guia");
    p.querySelector(".tmn-search").focus();
  }
  function close(focusMenu = true) {
    const p = $panel();
    if (!p || p.dataset.open !== "true") return;
    p.dataset.open = "false";
    const m = document.querySelector("#tmn-root .tmn-menu");
    m?.setAttribute("aria-expanded", "false");
    if (focusMenu) m?.focus();
  }
  const toggle = () => ($panel()?.dataset.open === "true" ? close() : open());

  // Abre ao lado da coluna do chat quando cabe; senão por cima dela.
  function position() {
    const p = $panel(), ed = Chat.findEditor();
    const col = ed?.closest(".chat-room__content, .chat-shell, .stream-chat, aside")?.getBoundingClientRect();
    if (!p || !col || col.width < 200) { ["left", "top", "bottom", "width", "transform"].forEach((k) => p?.style.removeProperty(k)); return; }
    const h = Math.min(650, innerHeight - 16), roomL = col.left - 16, roomR = innerWidth - col.right - 16;
    let w, left;
    if (roomL >= 380 && roomL >= roomR) { w = Math.min(600, roomL); left = col.left - 8 - w; }
    else if (roomR >= 380) { w = Math.min(600, roomR); left = col.right + 8; }
    else { w = Math.min(600, col.width - 8); left = col.left + (col.width - w) / 2; }
    const top = Math.max(8, Math.min(col.bottom, innerHeight - 8) - h);
    Object.assign(p.style, { left: `${Math.round(left)}px`, top: `${Math.round(top)}px`, bottom: "auto", width: `${Math.round(w)}px`, maxHeight: `${Math.round(h)}px`, transform: "none" });
  }
  addEventListener("resize", () => { if ($panel()?.dataset.open === "true") position(); });
  // Esc fecha o menu mesmo com o foco fora dele (depois de clicar na página, por exemplo).
  document.addEventListener("keydown", (e) => {
    const p = $panel();
    if (e.key !== "Escape" || p?.dataset.open !== "true" || p.contains(e.target)) return;
    close();
  });

  function show(tab) {
    const p = $panel(), l = list();
    if (!p || !l) return;
    active = TABS.some((t) => t.id === tab) ? tab : "guia";
    p.dataset.activeGroup = active; // o Guia se redesenha quando esta é a aba aberta
    p.querySelectorAll(".tmn-tab").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === active)));
    l.replaceChildren();
    if (active === "guia") return root.TimoneiroGuide?.renderTab(l, guideContext());
    if (active === "ajustes") return settings(l);
    const g = Cmd.GROUPS.find((x) => x.id === active);
    for (const c of g.commands) l.append(row(c));
    if (active === "eventos") l.append(history());
  }
  function results(text) {
    const l = list(); l.replaceChildren();
    const found = Cmd.search(text);
    if (!found.length) l.append(make("p", "tmn-empty-note", "Nenhum comando com esse nome. Tente outra palavra."));
    for (const c of found) l.append(row(c));
  }

  // Linha de comando: emoji, nome, dica (ou estado da pesca/evento), comando e ☆.
  function row(c) {
    const r = button("tmn-row"); r.dataset.cmd = c.id;
    const icon = make("span", "tmn-row-icon", c.icon); icon.setAttribute("aria-hidden", "true");
    const main = make("span"); main.append(make("span", "tmn-row-name", c.label), make("span", "tmn-row-hint", hintFor(c, r)));
    // Favorito: estrela desenhada (preenchida quando está na barra), cartão marcado e a ficha "Na barra".
    const star = button("tmn-star");
    const foot = make("span", "tmn-row-foot");
    foot.append(make("code", "tmn-row-cmd", c.url ? "abre o site ↗" : c.cmd.trim()));
    const chip = make("span", "tmn-fav-chip", "Na barra");
    const paintFav = () => {
      const on = !!root.TimoneiroBar?.isQuick(c.id);
      r.dataset.fav = String(on);
      star.replaceChildren(root.TimoneiroIcons.icon("star", 20, { filled: on }));
      star.setAttribute("aria-pressed", String(on));
      star.setAttribute("aria-label", on ? `Tirar da barra: ${c.label}` : `Pôr na barra: ${c.label}`);
      star.title = on ? "Na barra de atalhos. Clique para tirar." : "Pôr na barra de atalhos";
      if (on) foot.append(chip); else chip.remove();
    };
    paintFav();
    star.addEventListener("click", async (e) => {
      e.stopPropagation();
      const ok = await root.TimoneiroBar?.toggleQuick(c.id);
      if (ok === false) { status(`A barra já tem ${root.TimoneiroBar?.MAX ?? 6} atalhos. Tire um antes de pôr ${c.label}.`); return; }
      paintFav(); updateCount();
      const n = root.TimoneiroBar?.quickIds().length ?? 0;
      status(root.TimoneiroBar?.isQuick(c.id) ? `${c.label} foi para a barra (${n}/${root.TimoneiroBar?.MAX ?? 6}).` : `${c.label} saiu da barra.`);
    });
    r.append(icon, main, foot, star);
    r.addEventListener("click", () => run(c.id));
    return r;
  }
  function hintFor(c, r) {
    if (c.id === "$pescar") { const f = root.TimoneiroBar?.fishingNow(); r.dataset.state = f?.state || "unknown"; return f?.state === "cooldown" ? `Libera em ${f.left}` : c.hint; }
    if (c.id === "$evento") { const e = St.eventUi(Store.get(K.event), Date.now()); return e.active ? `${e.name}, acaba em ${e.remaining}` : c.hint; }
    if (c.id === "$vender todos") {
      // Quanto a venda rende agora, pelo inventário lido do Twish.
      const s = Store.get(K.smart);
      const d = s && (!s.boat || s.boat === boat()) ? St.smartData(s, ["inventory"], Date.now()) : null;
      const total = d ? Cmd.sellOptions(d.inventory).reduce((sum, f) => sum + (f.totalValue || 0), 0) : 0;
      if (total > 0) return `${total.toLocaleString("pt-BR")} coins agora`;
    }
    return c.hint;
  }

  // ---------- seletores ----------
  const NEEDS = { bait: ["me", "shop"], sell: ["me", "inventory"], title: ["me", "titles"], buy: ["shop"] };
  const TITLES = { bait: "Equipar isca", sell: "Vender peixe", title: "Escolher título", buy: "Comprar item", user: "Desafiar alguém do chat" };
  function options(kind) {
    if (kind === "user") return chatUsers().map((n) => ({ id: n, name: n }));
    const s = Store.get(K.smart);
    if (s && s.boat && s.boat !== boat()) return null;
    const d = St.smartData(s, NEEDS[kind], Date.now());
    if (!d) return null;
    return kind === "bait" ? Cmd.baitOptions(d.me, d.shop) : kind === "sell" ? Cmd.sellOptions(d.inventory) : kind === "title" ? Cmd.titleOptions(d.me, d.titles) : Cmd.shopOptions(d.shop);
  }
  function chatUsers() {
    const names = new Set();
    for (const el of document.querySelectorAll('[data-a-target="chat-message-username"], .chat-author__display-name, [data-test-selector="message-username"]')) {
      const n = (el.getAttribute("data-a-user") || el.textContent || "").trim().replace(/^@/, "");
      if (n && n.length <= 40) names.add(n);
    }
    return [...names].sort((a, b) => a.localeCompare(b)).slice(0, 40);
  }
  function meta(kind, o) {
    if (kind === "sell") return `${o.count} no inventário${o.totalValue ? `, ${o.totalValue} coins` : ""}`;
    if (kind === "bait") return `${o.owned} na bolsa${o.equipped ? ", equipada" : ""}`;
    if (kind === "buy") { const cost = Number(o.discounted_cost ?? o.cost); return `${cost.toLocaleString("pt-BR")} coins`; }
    if (kind === "title") return o.equipped ? "Equipado" : "";
    return "";
  }
  function picker(c) {
    const l = list(); if (!l) return;
    l.replaceChildren();
    const head = make("div", "tmn-picker-head");
    head.append(button("tmn-back", "← Voltar", () => show(active)), make("span", "tmn-picker-title", TITLES[c.kind]));
    const filter = make("input", "tmn-search"); filter.type = "search"; filter.placeholder = "Filtrar"; filter.setAttribute("aria-label", "Filtrar opções");
    const box = make("div"); box.style.cssText = "display:grid;gap:6px";
    const manual = button("tmn-manual", "Escrever o comando sem escolher", () => { if (Chat.fill(c.cmd)) close(false); });
    l.append(head, filter, box, manual);
    const draw = () => {
      box.replaceChildren();
      const all = options(c.kind);
      if (!all) { box.append(make("p", "tmn-empty-note", "Ainda sem os dados da sua conta. Entre no twish.com.br neste navegador; o Timoneiro lê sozinho em seguida.")); return; }
      const q = filter.value.trim().toLowerCase();
      const shown = all.filter((o) => !q || String(o.name || o.id).toLowerCase().includes(q));
      if (!shown.length) box.append(make("p", "tmn-empty-note", c.kind === "user" ? "Ninguém com esse nome no chat agora." : "Nada encontrado."));
      for (const o of shown) box.append(pick(c, o));
    };
    filter.addEventListener("input", draw);
    draw();
    filter.focus();
  }
  function pick(c, o) {
    const el = make("div", "tmn-pick"); el.dataset.id = o.id;
    const info = make("span"); info.append(make("span", "tmn-pick-name", o.name || o.id), make("span", "tmn-pick-meta", meta(c.kind, o)));
    const act = make("div", "tmn-qty");
    const write = (cmd) => { if (Chat.fill(cmd)) close(false); };
    if (c.kind === "user") act.append(button("tmn-go", "Escrever no chat", () => write(`${c.cmd}${o.id}`)));
    else if (c.kind === "title") act.append(button("tmn-go", o.equipped ? "Equipado" : "Escrever no chat", () => write(Cmd.build("title", o.id))));
    else {
      const max = c.kind === "sell" ? o.count : c.kind === "bait" ? o.owned : 99;
      const n = make("input"); n.type = "number"; n.min = "1"; n.max = String(max); n.value = "1"; n.setAttribute("aria-label", `Quantidade de ${o.name || o.id}`);
      const fix = () => { n.value = String(Math.min(max, Math.max(1, Math.floor(Number(n.value) || 1)))); return Number(n.value); };
      n.addEventListener("change", fix);
      const minus = button("tmn-minus", "−", () => { n.value = String(fix() - 1); fix(); }); minus.setAttribute("aria-label", "Menos um");
      const plus = button("tmn-plus", "+", () => { n.value = String(fix() + 1); fix(); }); plus.setAttribute("aria-label", "Mais um");
      act.append(minus, n, plus, button("tmn-go", "Escrever no chat", () => write(Cmd.build(c.kind, o.id, fix()))));
    }
    el.append(info, act);
    return el;
  }

  // ---------- histórico de eventos de hoje ----------
  function history() {
    const box = make("section", "tmn-history"); box.setAttribute("aria-label", "Eventos de hoje");
    box.append(make("h3", null, "Eventos de hoje"));
    const v = St.historyView(Store.get(K.history), Date.now());
    if (!v.entries.length) box.append(make("p", "tmn-empty-note", "Nenhum evento visto hoje ainda."));
    for (const e of v.entries) {
      const r = make("div", "tmn-history-row"); r.dataset.status = e.status;
      const hora = new Date(e.detectedAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });
      r.append(make("span", null, hora), make("b", null, e.name), make("span", null, e.status === "active" ? "agora" : e.status === "ended" ? "acabou" : ""));
      box.append(r);
    }
    return box;
  }

  // ---------- ajustes ----------
  const section = (title) => { const s = make("section", "tmn-set"); s.append(make("h3", null, title)); return s; };
  function sw(label, on, onToggle) {
    const line = make("label", "tmn-line");
    const b = button("tmn-switch"); b.setAttribute("role", "switch"); b.setAttribute("aria-checked", String(!!on)); b.setAttribute("aria-label", label);
    b.addEventListener("click", async () => { await onToggle(); });
    line.append(make("span", null, label), b);
    return line;
  }
  function settings(l) {
    const rerender = () => { if (active === "ajustes") show("ajustes"); };
    // Neste canal
    const here = section("Neste canal");
    here.append(make("p", null, "O Timoneiro aparece sozinho na live de qualquer barco do Twish e usa esse barco."));
    const hide = button("tmn-small-btn", "Esconder o Timoneiro neste canal", () => Gate?.hideHere(true)); hide.dataset.hideHere = "";
    here.append(hide, make("p", null, "Para mostrar de novo: clique no ícone do Timoneiro na barra do navegador e em Mostrar aqui."));
    const only = make("input"); only.type = "text"; only.id = "tmn-only-channels"; only.dataset.onlyChannels = ""; only.placeholder = "vazio: qualquer live de barco do Twish";
    only.value = (Gate?.get().only || []).join(", ");
    only.addEventListener("change", () => Gate?.setOnly(only.value));
    const onlyLabel = make("label", "tmn-line", "Mostrar só nestes canais (opcional)"); onlyLabel.htmlFor = "tmn-only-channels";
    here.append(onlyLabel, only, make("p", null, "Separe por vírgula. Com a lista preenchida, o Timoneiro some nos outros canais."));
    const pin = make("input"); pin.type = "text"; pin.id = "tmn-pin-boat"; pin.dataset.pinBoat = ""; pin.placeholder = "automático: o canal da live";
    pin.value = Gate?.get().pinned || "";
    pin.addEventListener("change", () => Gate?.pin(pin.value));
    const pinLabel = make("label", "tmn-line", "Fixar barco (opcional)"); pinLabel.htmlFor = "tmn-pin-boat";
    const now = make("p"); now.dataset.boatNow = ""; now.textContent = boat() ? `Barco agora: ${boat()} (${Gate?.get().pinned ? "fixado" : "segue o canal da live"}).` : "Nenhum barco ainda.";
    here.append(pinLabel, pin, now, make("p", null, "Com um barco fixado, o Timoneiro só aparece na live dele. Apague para voltar ao automático."));

    // Avisos
    const A = root.TimoneiroAlerts;
    const alerts = section("Avisos");
    const n = A.notifications();
    alerts.append(sw("Notificação quando a pesca liberar", n.fishing, () => A.toggleNotification("fishing").then(rerender)));
    alerts.append(sw("Notificação de eventos", n.event, () => A.toggleNotification("event").then(rerender)));
    const s = A.sounds();
    for (const [g, label] of [["fishingAlert", "Som da pesca"], ["eventAlert", "Som de evento"]]) {
      alerts.append(sw(label, s[g].enabled, () => A.setSound(g, { enabled: !s[g].enabled }).then(rerender)));
      const line = make("div", "tmn-line");
      const range = make("input"); range.type = "range"; range.min = "1"; range.max = "10"; range.step = "1"; range.value = String(s[g].volume); range.setAttribute("aria-label", `Volume: ${label}`);
      range.addEventListener("change", () => A.setSound(g, { volume: range.value }));
      line.append(make("span", null, "Volume"), range, button("tmn-small-btn", "Ouvir", () => A.play(g)));
      alerts.append(line);
    }

    // Arremesso automático
    const cast = section("Arremesso automático");
    cast.append(sw("Um clique no 🎣 da barra já envia o $pescar", Chat.clickSend(), () => Promise.resolve(Chat.setClickSend(!Chat.clickSend())).then(rerender)));
    cast.append(make("p", "tmn-warn-note", "Desligado, o 🎣 só escreve e você aperta Enter. Ligado, o clique envia. O manual do Twish proíbe automação: use por sua conta e risco."));
    const ls = Chat.lastSend();
    const hhmmss = (at) => new Date(at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    if (ls) cast.append(make("p", null, `Último clique no 🎣: ${ls.label} (às ${hhmmss(ls.at)}).`));
    // Os últimos cliques (só neste computador): se o 🎣 não enviar, mostra o porquê de cada vez.
    const log = Chat.castLog?.() || [];
    if (log.length) {
      const det = make("details", "tmn-cast-details");
      det.append(make("summary", null, `Últimos cliques no 🎣 (${Math.min(log.length, 8)})`));
      const ul = make("ul", "tmn-cast-log");
      for (const e of log.slice(0, 8)) ul.append(make("li", null, `${hhmmss(e.at)} · ${e.label}`));
      det.append(ul);
      cast.append(det);
    }

    // Aparência
    const look = section("Aparência");
    const th = make("select"); th.setAttribute("aria-label", "Tema");
    for (const [v, label] of root.TimoneiroTheme.CHOICES) { const o = make("option", null, label); o.value = v; o.selected = root.TimoneiroTheme.get() === v; th.append(o); }
    th.addEventListener("change", () => root.TimoneiroTheme.set(th.value));
    const pos = make("select"); pos.setAttribute("aria-label", "Posição da barra");
    for (const [v, label] of [["dock", "Presa acima da caixa do chat"], ["float", "Solta: arraste pela alça ⠿"]]) { const o = make("option", null, label); o.value = v; o.selected = (root.TimoneiroBar.layout().mode === "float" ? "float" : "dock") === v; pos.append(o); }
    pos.addEventListener("change", () => root.TimoneiroBar.setLayout({ mode: pos.value }));
    look.append(make("span", "tmn-line", "Tema"), th, make("span", "tmn-line", "Posição da barra"), pos, button("tmn-small-btn", "Voltar a barra para o lugar padrão", () => root.TimoneiroBar.setLayout({ x: null, y: null })));

    l.append(here, alerts, cast, look);
    const guide = make("div"); l.append(guide);
    root.TimoneiroGuide?.renderSettings(guide, rerender);
  }

  // ---------- Guia ----------
  function guideContext() {
    return {
      getSmartData: () => Store.get(K.smart) || null,
      getEvent: () => St.eventUi(Store.get(K.event), Date.now()),
      getEventState: () => Store.get(K.event) || null,
      getFishing: () => { const f = root.TimoneiroBar?.fishingNow() || { state: "unknown" }; return { mode: f.state === "cooldown" ? "cooldown" : "available", cooldown: f.left || null, known: f.state !== "unknown", tooltip: f.state === "cooldown" ? `Pescar • ${f.left}` : "Pescar" }; },
      fill: (cmd) => Chat.fill(cmd),
      closePanel: () => close(false),
      openGroup: (id) => open(id),
      openUrl: (page) => window.open(root.TimoneiroBoat?.url(page) || "https://twish.com.br/", "_blank", "noopener,noreferrer"),
      panelId: "tmn-panel",
      rootId: "tmn-root",
    };
  }
  root.TimoneiroGuideContext = guideContext;

  // ---------- mensagens do fundo e sinais para ele ----------
  try {
    chrome.runtime.onMessage.addListener((msg, sender, reply) => {
      if (sender.id !== chrome.runtime.id) return false;
      const ok = !Gate || Gate.allowed();
      if (msg?.type === "timoneiro-open-guide") { if (!ok) return false; open("guia"); reply(true); return false; }
      if (msg?.type === "timoneiro-fill" && typeof msg.command === "string" && /^\$[a-z]+$/i.test(msg.command)) {
        if (!ok || !Chat.findEditor()) return false;
        reply(Chat.fill(msg.command)); return false;
      }
      return false;
    });
  } catch (_) {}

  // Você mandou $pescar (Enter ou botão de enviar): o fundo relê o cooldown na hora. Só observa.
  let lastCast = 0;
  function castSent() {
    if ((Gate && !Gate.allowed()) || !/^\s*\$pescar\b/i.test(Chat.text()) || Date.now() - lastCast < 3000) return;
    lastCast = Date.now();
    try { chrome.runtime.sendMessage({ type: "timoneiro-cast" }).catch(() => {}); } catch (_) {}
  }
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
    const ed = Chat.findEditor();
    if (ed && e.target instanceof Node && (ed === e.target || ed.contains(e.target))) castSent();
  }, true);
  document.addEventListener("click", (e) => { if (e.target instanceof Element && e.target.closest('[data-a-target="chat-send-button"]')) castSent(); }, true);

  // Voltou para a live depois de um tempo: pede uma leitura (o fundo limita a 1 a cada 15 s).
  let lastWake = 0;
  function wake() {
    if (Gate && !Gate.allowed()) return;
    const age = Date.now() - Math.max(Store.get(K.fishing)?.updatedAt || 0, Store.get(K.smart)?.updatedAt || 0);
    if (age < 20e3 || Date.now() - lastWake < 15e3) return;
    lastWake = Date.now();
    try { chrome.runtime.sendMessage({ type: "timoneiro-sync-now" }).catch(() => {}); } catch (_) {}
  }
  root.TimoneiroWake = wake; // o Guia chama ao abrir
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") wake(); });

  Store.watch([K.event, K.fishing], () => { if ($panel()?.dataset.open === "true" && !["guia", "ajustes"].includes(active) && !$panel().querySelector(".tmn-search").value && !$panel().querySelector(".tmn-pick")) show(active); });
  Store.watch(K.history, () => { if (active === "eventos" && $panel()?.dataset.open === "true" && !$panel().querySelector(".tmn-pick")) show("eventos"); });
  Store.watch(K.boat, header);

  root.TimoneiroMenu = { mount, unmount, open, close, toggle, run, show, updateCount };
})(globalThis);
