// Timoneiro — barra de atalhos acima da caixa do chat (modelo D).
// Botões quadrados com emoji: o 🎣 conta o tempo no contorno, o 🎪 mostra quanto falta do evento.
// Até 6 favoritos (☆ no menu), arrastáveis para mudar a ordem. Fica presa acima do chat ou solta.
(function (root) {
  "use strict";
  if (root.TimoneiroBar) return;
  const Store = root.TimoneiroStore, St = root.TimoneiroStatus, Cmd = root.TimoneiroCommands, Gate = root.TimoneiroChannel;
  const K = { quick: "timoneiro.quick.v1", layout: "timoneiro.layout.v1", fishing: "timoneiro.fishingStatus.v1", event: "timoneiro.eventStatus.v1" };
  const MAX = 6;
  const DEFAULT_QUICK = ["$pescar", "$evento", "$hoje", "$ranking", "$vender todos"];
  const $root = () => document.getElementById("tmn-root");
  const make = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

  // ---------- favoritos ----------
  const quickIds = () => { const v = Store.get(K.quick); return (Array.isArray(v) ? v : DEFAULT_QUICK).filter((id) => Cmd.find(id)).slice(0, MAX); };
  const isQuick = (id) => quickIds().includes(id);
  function toggleQuick(id) {
    const ids = quickIds();
    if (ids.includes(id)) return Store.set(K.quick, ids.filter((x) => x !== id)).then(() => true);
    if (ids.length >= MAX) return Promise.resolve(false);
    return Store.set(K.quick, [...ids, id]).then(() => true);
  }
  function moveQuick(id, beforeId) {
    const ids = quickIds().filter((x) => x !== id);
    const at = beforeId ? ids.indexOf(beforeId) : -1;
    ids.splice(at < 0 ? ids.length : at, 0, id);
    Store.set(K.quick, ids);
  }

  // ---------- estado de pesca e evento nos botões ----------
  let cooldownTotal = null, cooldownFor = null;
  function fishingNow() {
    const c = St.countdown(Store.get(K.fishing), Date.now());
    return { state: c.mode === "cooldown" ? "cooldown" : c.mode === "available" ? "available" : "unknown", left: c.cooldown, seconds: c.seconds };
  }
  function paint() {
    const r = $root();
    if (!r) return;
    const f = fishingNow(), fs = Store.get(K.fishing);
    // 🎣: o contorno do botão enche até a pesca liberar; o tempo em texto fica na dica (mouse em cima).
    let ringDeg = 0;
    if (f.state === "cooldown" && fs && Number.isFinite(fs.readyAt)) {
      if (cooldownFor !== fs.readyAt) {
        cooldownFor = fs.readyAt;
        // Começo do cooldown: a leitura que o marcou (ou agora); assim o anel começa do ponto certo.
        const started = Math.min(Date.now(), fs.updatedAt || Date.now());
        cooldownTotal = Math.max(fs.readyAt - started, 1000);
      }
      ringDeg = Math.round(Math.min(1, Math.max(0, 1 - Math.max(0, fs.readyAt - Date.now()) / cooldownTotal)) * 360);
    }
    r.querySelectorAll('[data-cmd="$pescar"]').forEach((b) => {
      b.dataset.state = f.state;
      if (f.state === "cooldown") b.style.setProperty("--tmn-p", `${ringDeg}deg`); else b.style.removeProperty("--tmn-p");
      const label = f.state === "cooldown" ? `Pescar: libera em ${f.left}` : f.state === "available" ? "Pescar: liberado" : "Pescar";
      b.setAttribute("aria-label", label);
      b.querySelector(".tmn-tip").textContent = f.state === "cooldown" ? `$pescar • falta ${f.left}` : "$pescar";
    });
    const ev = St.eventUi(Store.get(K.event), Date.now());
    r.querySelectorAll('[data-cmd="$evento"]').forEach((b) => {
      b.dataset.active = String(!!ev.active);
      const progress = ev.active && Number.isFinite(ev.progressCount) && ev.progressTarget > 0 ? ` (${ev.progressCount}/${ev.progressTarget})` : "";
      const label = ev.active ? `${ev.name}${progress}: acaba em ${ev.remaining}` : "Evento agora";
      b.setAttribute("aria-label", label);
      b.querySelector(".tmn-tip").textContent = ev.active ? `${ev.name}${progress} • ${ev.remaining}` : "$evento";
    });
    const evChip = r.querySelector(".tmn-strip-event");
    if (evChip) {
      const prog = ev.active && Number.isFinite(ev.progressCount) && ev.progressTarget > 0 ? ` · ${ev.progressCount}/${ev.progressTarget}` : "";
      evChip.hidden = !ev.active;
      r.querySelector(".tmn-strip-sep").hidden = !(ev.active && r.querySelector(".tmn-guide-hint")?.dataset.active === "true");
      if (ev.active) {
        evChip.querySelector(".tmn-strip-ev-emoji").textContent = ev.kind === "grand" ? "🌟" : "🎪";
        evChip.querySelector(".tmn-strip-ev-name").textContent = `${ev.name}${prog}`;
        evChip.querySelector(".tmn-strip-ev-time").textContent = ev.remaining;
        evChip.setAttribute("aria-label", `${ev.name}${prog}, acaba em ${ev.remaining}. Ver detalhes no Guia.`);
      } else hideEventPop();
    }
    // O tempo do evento também anda no balão e no cartão do Guia.
    document.querySelectorAll("[data-tmn-ev-time]").forEach((e) => { e.textContent = ev.active ? `acaba em ${ev.remaining}` : "encerrado"; });
  }

  // ---------- balão do evento (passar o mouse ou focar o evento na faixa) ----------
  function eventPop() {
    const r = $root();
    let pop = document.getElementById("tmn-event-pop");
    if (!pop && r) {
      pop = make("div", "tmn-event-pop"); pop.id = "tmn-event-pop";
      pop.setAttribute("role", "tooltip"); pop.hidden = true;
      r.append(pop);
    }
    return pop;
  }
  function showEventPop(chip) {
    // Com o menu aberto o balão ficaria atrás dele (e o Guia já mostra o mesmo cartão).
    if (document.getElementById("tmn-panel")?.dataset.open === "true") return;
    const pop = eventPop();
    if (!pop || !root.TimoneiroGuide?.fillEvent?.(pop)) return;
    pop.append(make("div", "tmn-event-foot", "Clique para ver no Guia."));
    pop.hidden = false;
    // Fixo na tela, acima do evento (abaixo se não couber), sem sair pelas bordas.
    const a = chip.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
    pop.style.left = `${Math.max(8, Math.min(a.right - w, innerWidth - w - 8))}px`;
    pop.style.top = `${a.top - h - 8 >= 8 ? a.top - h - 8 : Math.min(a.bottom + 8, innerHeight - h - 8)}px`;
  }
  function hideEventPop() { const pop = document.getElementById("tmn-event-pop"); if (pop) pop.hidden = true; }
  function eventChip() {
    const chip = make("button", "tmn-strip-event");
    chip.type = "button"; chip.hidden = true;
    chip.setAttribute("aria-describedby", "tmn-event-pop");
    chip.append(make("span", "tmn-strip-ev-emoji", "🎪"), make("span", "tmn-strip-ev-name"), make("span", "tmn-strip-ev-time"));
    chip.firstChild.setAttribute("aria-hidden", "true");
    chip.addEventListener("mouseenter", () => showEventPop(chip));
    chip.addEventListener("focus", () => showEventPop(chip));
    chip.addEventListener("mouseleave", hideEventPop);
    chip.addEventListener("blur", hideEventPop);
    chip.addEventListener("keydown", (e) => { if (e.key === "Escape") hideEventPop(); });
    chip.addEventListener("click", (e) => { if (!e.isTrusted) return; hideEventPop(); root.TimoneiroMenu?.open("guia"); });
    return chip;
  }

  // ---------- botões ----------
  let dragging = null;
  function quickButton(c) {
    const b = make("button", "tmn-btn");
    b.type = "button"; b.dataset.cmd = c.id; b.draggable = true;
    b.append(make("span", null, c.icon), make("span", "tmn-tip", c.cmd.trim()));
    b.firstChild.setAttribute("aria-hidden", "true");
    b.setAttribute("aria-label", c.label);
    b.addEventListener("click", (e) => {
      if (!e.isTrusted) return; // script da página não aciona a barra
      if (!b.dataset.dragged) root.TimoneiroMenu?.run(c.id, { fromBar: true });
      delete b.dataset.dragged;
    });
    b.addEventListener("dragstart", (e) => { dragging = c.id; b.dataset.dragged = "1"; e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", c.id); });
    b.addEventListener("dragend", () => { dragging = null; setTimeout(() => delete b.dataset.dragged, 0); $root()?.querySelectorAll(".tmn-drop").forEach((x) => x.classList.remove("tmn-drop")); });
    dropTarget(b, c.id);
    return b;
  }
  function dropTarget(el, id) {
    el.addEventListener("dragover", (e) => { if (dragging && dragging !== id) { e.preventDefault(); el.classList.add("tmn-drop"); } });
    el.addEventListener("dragleave", () => el.classList.remove("tmn-drop"));
    el.addEventListener("drop", (e) => { if (!dragging) return; e.preventDefault(); el.classList.remove("tmn-drop"); moveQuick(dragging, id); dragging = null; });
  }
  function tool(cls, icon, label, onClick) {
    const b = make("button", `tmn-btn ${cls}`);
    b.type = "button"; b.setAttribute("aria-label", label);
    const i = make("span"); i.setAttribute("aria-hidden", "true");
    if (typeof icon === "string") i.textContent = icon; else i.append(icon);
    b.append(i, make("span", "tmn-tip", label));
    b.addEventListener("click", onClick);
    return b;
  }

  function render() {
    const r = $root();
    if (!r) return;
    const row = r.querySelector(".tmn-quick");
    row.replaceChildren();
    const ids = quickIds();
    for (const id of ids) row.append(quickButton(Cmd.find(id)));
    for (let i = ids.length; i < MAX; i++) { const e = make("span", "tmn-empty"); e.setAttribute("aria-hidden", "true"); dropTarget(e, null); row.append(e); }
    const menu = tool("tmn-menu", root.TimoneiroIcons.icon("menu", 18), "Abrir o menu do Timoneiro", () => root.TimoneiroMenu?.toggle());
    menu.setAttribute("aria-haspopup", "dialog"); menu.setAttribute("aria-expanded", "false"); menu.setAttribute("aria-controls", "tmn-panel");
    row.append(menu, tool("tmn-mini tmn-hide", root.TimoneiroIcons.icon("minus"), "Recolher o Timoneiro", () => collapse(true)), tool("tmn-show", "⎈", "Mostrar o Timoneiro", () => collapse(false)));
    draggable(row.querySelector(".tmn-show"));
    root.TimoneiroMenu?.updateCount();
    paint();
  }

  function collapse(on) { if (on) root.TimoneiroMenu?.close(); Gate?.set({ collapsed: on }); }

  // ---------- onde a barra fica ----------
  // Presa: primeiro filho do contêiner .chat-input (acima da caixa e dos emblemas da Twitch).
  // Solta: posição guardada em proporção da janela, arrastando pela alça ⠿ (ou pelo ⎈ recolhido).
  const frac = (v) => (Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : null);
  const layout = () => { const l = Store.get(K.layout) || {}; return { mode: l.mode === "float" ? "float" : "dock", x: frac(l.x), y: frac(l.y) }; };
  function dockSpot() {
    const ed = root.TimoneiroChat.findEditor();
    if (!ed) return null;
    const box = ed.closest(".chat-input");
    if (box) return { parent: box, before: box.firstElementChild === $root() ? $root().nextElementSibling : box.firstElementChild };
    let block = ed.closest('[data-a-target="chat-input"]') || ed.parentElement;
    for (let n = block, i = 0; i < 6 && n.parentElement && !n.parentElement.matches("aside, body, html, .chat-shell"); i++) { n = n.parentElement; if (getComputedStyle(n).position !== "static") block = n; }
    return block?.parentElement ? { parent: block.parentElement, before: block } : null;
  }
  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), Math.max(lo, hi));
  function place() {
    const r = $root();
    if (!r) return;
    const l = layout();
    if (l.mode === "float") {
      if (r.parentElement !== document.body) document.body.append(r);
      r.classList.add("tmn-floating");
      const w = r.offsetWidth || 320, h = r.offsetHeight || 48;
      r.style.left = `${Math.round(clamp(l.x == null ? innerWidth - w - 24 : l.x * innerWidth, 0, innerWidth - w))}px`;
      r.style.top = `${Math.round(clamp(l.y == null ? innerHeight - h - 140 : l.y * innerHeight, 0, innerHeight - h))}px`;
    } else {
      r.classList.remove("tmn-floating");
      r.style.left = r.style.top = "";
      const spot = dockSpot();
      if (spot && spot.before !== r && r.nextElementSibling !== spot.before) spot.parent.insertBefore(r, spot.before);
    }
  }
  function draggable(handle) {
    handle.addEventListener("pointerdown", (down) => {
      if (layout().mode !== "float" || down.button !== 0) return;
      const r = $root(), box = r.getBoundingClientRect();
      const ox = down.clientX - box.left, oy = down.clientY - box.top;
      let moved = false;
      const move = (e) => {
        if (!moved && Math.hypot(e.clientX - down.clientX, e.clientY - down.clientY) < 4) return;
        moved = true;
        r.style.left = `${Math.round(clamp(e.clientX - ox, 0, innerWidth - box.width))}px`;
        r.style.top = `${Math.round(clamp(e.clientY - oy, 0, innerHeight - box.height))}px`;
      };
      const up = () => {
        removeEventListener("pointermove", move); removeEventListener("pointerup", up);
        if (!moved) return;
        const b = r.getBoundingClientRect();
        Store.set(K.layout, { ...layout(), x: b.left / innerWidth, y: b.top / innerHeight });
        handle.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); }, { capture: true, once: true });
      };
      addEventListener("pointermove", move); addEventListener("pointerup", up);
    });
  }

  // ---------- montar ----------
  function allowed() { return !Gate || Gate.allowed(); }
  function mount() {
    if (!allowed()) { $root()?.remove(); root.TimoneiroMenu?.unmount(); return; }
    let r = $root();
    if (!r) {
      if (!dockSpot() && layout().mode !== "float") return;
      r = make("div"); r.id = "tmn-root";
      r.setAttribute("role", "toolbar"); r.setAttribute("aria-label", "Atalhos do Timoneiro");
      const grip = make("div", "tmn-grip", "⠿ Timoneiro"); grip.title = "Arraste para mover";
      // Faixa de cima: o próximo passo do Guia (guide-ui.js desenha em .tmn-guide-hint) e o evento.
      // Sem nenhum dos dois, ela some.
      const strip = make("div", "tmn-strip"); strip.setAttribute("role", "group"); strip.setAttribute("aria-label", "Guia e evento");
      const ev = eventChip();
      const sep = make("span", "tmn-strip-sep"); sep.hidden = true; sep.setAttribute("aria-hidden", "true");
      strip.append(make("div", "tmn-guide-hint"), sep, ev);
      r.append(grip, strip, make("div", "tmn-quick"));
      (layout().mode === "float" ? document.body : dockSpot().parent).append(r);
      draggable(grip);
      root.TimoneiroMenu?.mount();
      render();
      root.TimoneiroGuide?.refresh();
    }
    r.classList.toggle("tmn-collapsed", !!Gate?.get().collapsed);
    root.TimoneiroTheme?.apply();
    place();
  }

  Store.ready.then(() => {
    Store.watch(K.quick, render);
    Store.watch(K.layout, place);
    Store.watch([K.fishing, K.event], () => { paint(); root.TimoneiroAlerts?.observe(Store.get(K.fishing), Store.get(K.event)); });
    Gate?.onChange(mount);
    let queued = false;
    new MutationObserver(() => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; mount(); });
    }).observe(document.documentElement, { childList: true, subtree: true });
    addEventListener("resize", () => { if (layout().mode === "float") place(); });
    setInterval(() => { paint(); root.TimoneiroGuide?.tick?.(); }, 1000);
    mount();
    root.TimoneiroAlerts?.observe(Store.get(K.fishing), Store.get(K.event));
  });

  root.TimoneiroBar = { MAX, quickIds, isQuick, toggleQuick, render, paint, fishingNow, place, layout, setLayout: (p) => Store.set(K.layout, { ...layout(), ...p }) };
})(globalThis);
