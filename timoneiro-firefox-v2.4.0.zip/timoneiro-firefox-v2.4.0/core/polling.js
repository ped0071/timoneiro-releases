// Timoneiro — agendas das leituras do Twish: de quanto em quanto tempo cada coisa é lida e quando pausar.
// Puro: sem fetch, timers nem chrome.*. Usado pelo fundo (background-sync.js) e pela aba (guide-sync.js).
// Cada predicado é chamado no mesmo ponto de antes, com o relógio daquele momento: a pausa do 429
// muda no meio da rodada, então nada de montar um plano no começo.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroPolling = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const MIN = 60e3, HOUR = 3600e3;
  const C = {
    PAUSE_429_MS: 2 * MIN,
    TAB_HEALTHY_MS: 15000,      // a aba líder bate a cada 2 s; sem batida há 15 s, ela está dormindo
    TAB_SMART_FRESH_MS: 90000,
    SMART_EVERY_MS: 55000,
    SEA_ROOMS_EVERY_MS: 85000,  // salas: ~90 s, como a aba do Twish
    MARKET_EVERY_MS: 10 * MIN,
    CAST_REREAD_MS: [3000, 10000],
    ALARM_PERIOD_MIN: 0.5,
    ALARM_DELAY_MIN: 0.1,
    UPDATE_EVERY: HOUR,
    UPDATE_RETRY: 15 * MIN,
    CHANNELS_RETRY_BASE: MIN,
    CHANNELS_RETRY_MAX: 30 * MIN,
    GUIDE_TICK_MS: 30000,
    GUIDE_FIRST_MS: 4000,
    GUIDE_GAP_MS: 700,
    MARKET_STATS_EVERY: 6 * HOUR,
    MARKET_SPECIES_EVERY: 45 * MIN,
    PATCH_NOTES_EVERY: 6 * HOUR,
    PATCH_NOTES_READER: 2,
    BENCH_FRESH_MS: 6 * HOUR,
    BENCH_GAP_MS: 2500,
    BENCH_429_WAIT_MS: 30000,
  };

  // Leituras do Guia: [chave, caminho(barco, handle), intervalo]. Caminho null: pula.
  const GUIDE_JOBS = [
    ["manual", () => "/api/manual", HOUR],
    ["bestiary", (b) => `/api/${b}/bestiary`, HOUR],
    ["profile", (b, h) => (h ? `/api/${b}/players/${encodeURIComponent(h)}` : null), 2 * MIN],
    ["missions", (b) => `/api/${b}/me/missions`, 3 * MIN],
    ["expeditions", (b) => `/api/${b}/expeditions`, 90e3],
    ["tournament", (b) => `/api/${b}/tournament`, 30e3],
    ["trident", (b) => `/api/${b}/trident`, 10 * MIN],
    ["portOrders", (b) => `/api/${b}/me/port-orders`, 10 * MIN],
  ];

  const jobDue = (every, fetchedAt, now, force) => !!force || now - (fetchedAt || 0) >= every;

  const EXTRA_EVERY = { marketStats: C.MARKET_STATS_EVERY, marketBySpecies: C.MARKET_SPECIES_EVERY, patchNotes: C.PATCH_NOTES_EVERY };
  function extraDue(name, pack, now, force) {
    if (force) return true;
    // Leitor das notas mudou (2.0.18): relê na hora em vez de esperar as 6 h da leitura que falhou.
    if (name === "patchNotes" && pack.patchNotesReader !== C.PATCH_NOTES_READER) return true;
    return now - (pack.fetchedAt[name] || 0) >= EXTRA_EVERY[name];
  }

  // A aba do Twish está viva e lendo a conta deste barco?
  const tabHealthy = ({ beatAt, smart, boat, now }) =>
    now - (beatAt || 0) < C.TAB_HEALTHY_MS && smart?.boat === boat && smart?.source !== "background" && now - (smart.updatedAt || 0) < C.TAB_SMART_FRESH_MS;

  // Passos de syncOnce (background-sync.js).
  const readMe = (healthy, force) => !healthy || !!force;
  const readSmart = (healthy, force, at, lastSmartAt) => !healthy && (!!force || at - lastSmartAt >= C.SMART_EVERY_MS);
  const readSea = (healthy, now, pausedUntil) => !healthy && now >= pausedUntil;
  const roomsDue = (now, roomsAt) => now - (roomsAt || 0) >= C.SEA_ROOMS_EVERY_MS;
  const readMarket = (force, now, at, pausedUntil, marketAt) => now >= pausedUntil && (!!force || at - (marketAt || 0) >= C.MARKET_EVERY_MS);

  const failState = (status) => `erro ${status || ""}`.trim();
  const meState = (status) => (status === 401 || status === 403 ? "login" : status === 429 ? "rate" : status === 404 ? "boat" : failState(status));
  const eventsState = (status) => (status === 429 ? "rate" : failState(status));

  const pauseUntilFor = (status, now) => (status === 429 ? now + C.PAUSE_429_MS : null);

  // Lista de barcos: depois de falhar espera 1, 2, 4... até 30 min.
  const channelsBlocked = (retry, now) => !!retry && now < retry.nextTryAt;
  function channelsRetry(prevRetry, now) {
    const fails = (prevRetry?.fails || 0) + 1;
    return { fails, nextTryAt: now + Math.min(C.CHANNELS_RETRY_MAX, C.CHANNELS_RETRY_BASE * 2 ** (fails - 1)) };
  }

  const updateDue = (prev, now, force) => !!force || now - (prev.checkedAt || 0) >= (prev.failed || prev.ok === false ? C.UPDATE_RETRY : C.UPDATE_EVERY);

  const alarmNeedsReset = (a) => !a || !a.periodInMinutes || a.periodInMinutes > C.ALARM_PERIOD_MIN;

  const handleFrom = (stored, me) => (stored || me?.handle || me?.login || me?.username || me?.twitch_login || "").toLowerCase() || null;

  const benchFresh = (prev, boat, now, force) => !force && prev?.boat === boat && now - prev.at < C.BENCH_FRESH_MS && !!prev.players?.length;

  // Cooldown da pesca dentro do /me: o nome do campo e o nível mudam; procura até 3 níveis, fora de listas.
  const COOLDOWN_FIELDS = ["cooldown_seconds", "fishing_cooldown_remaining", "cast_cooldown_remaining"];
  function findCooldown(data, depth = 0) {
    if (!data || typeof data !== "object" || depth > 3) return null;
    if (Number.isFinite(data.cooldown_remaining)) return { cooldown_remaining: data.cooldown_remaining };
    for (const k of COOLDOWN_FIELDS) if (Number.isFinite(data[k])) return { cooldown_remaining: data[k] };
    for (const v of Object.values(data)) {
      if (!v || typeof v !== "object" || Array.isArray(v)) continue;
      const hit = findCooldown(v, depth + 1);
      if (hit) return hit;
    }
    return null;
  }

  return {
    ...C, GUIDE_JOBS, jobDue, extraDue, tabHealthy,
    readMe, readSmart, readSea, roomsDue, readMarket,
    meState, eventsState, pauseUntilFor, channelsBlocked, channelsRetry,
    updateDue, alarmNeedsReset, handleFrom, benchFresh, findCooldown,
  };
});
