// Timoneiro — trava do som: cada aviso toca uma vez no navegador todo (aba da Twitch ou fundo).
// Puro: sem chrome.*. Usado por chat/alerts.js e por notification-worker.js.
// Até a 2.0.15 qualquer som de evento calava os outros por 12 min: Torneio, Frota e o evento seguinte
// ficavam mudos. Agora só cala o mesmo aviso; avisos diferentes ficam mudos só por alguns segundos,
// o tempo de a página e o fundo lerem o mesmo acontecimento com chaves um pouco diferentes.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroSoundLock = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const SAME = { fishing: 10 * 60e3, event: 30 * 60e3 };
  const GAP = { fishing: 60e3, event: 45e3 };

  function canPlay(lock, kind, key, now = Date.now()) {
    const at = (lock && lock[`${kind}At`]) || 0;
    if (lock && lock[kind] === key && now - at < (SAME[kind] || SAME.event)) return false;
    return now - at >= (GAP[kind] || GAP.event);
  }
  const take = (lock, kind, key, now = Date.now()) => ({ ...(lock || {}), [kind]: key, [`${kind}At`]: now });
  // O som falhou (navegador bloqueou o áudio): volta a trava como estava, para o fundo tocar.
  function release(lock, kind, key, before) {
    if (!lock || lock[kind] !== key) return lock;
    return { ...lock, [kind]: (before || {})[kind] ?? null, [`${kind}At`]: (before || {})[`${kind}At`] || 0 };
  }
  return { canPlay, take, release };
});
