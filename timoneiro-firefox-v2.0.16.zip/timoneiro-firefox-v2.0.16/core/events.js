// Timoneiro — leitura dos eventos do Twish pelo tipo (kind) e pelo valor que a API manda.
// Puro: sem DOM, sem rede, sem chrome.*. Usado pelo service worker, pela aba do Twish e pelo Guia.
// A classificação de relevância e a assinatura estável (sem contagem regressiva) vêm do
// projeto twish-eventos-discord, de younk (licença MIT): https://github.com/younk5/twish-eventos-discord
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroEvents = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  // kind da API → nome usado pelas regras do Guia. Quando o Twish renomeia um evento, o kind continua
  // o mesmo e o Guia segue reconhecendo. kinds que servem a mais de um evento (catch_contest:
  // Peso Pesado ou Menor Peixe) ficam de fora: para eles vale o nome.
  const KIND_NAME = {
    double_xp: "XP em Dobro",
    store_discount: "Desconto na Loja",
    sell_multiplier: "Venda Turbinada",
    tier_catch_boost: "Sorte Rara",
    double_twishcoins: "Coins em Dobro",
    cooldown_multiplier: "Maré Turbo",
    species_boost: "Cardume Passageiro",
    catch_drop: "Garrafa ao Mar",
    species_buyer: "Comprador do Porto",
    catch_pot: "Rede Coletiva",
    wash_away: "Tempestade",
  };
  const KNOWN_NAMES = new Set([...Object.values(KIND_NAME), "Concurso Peso Pesado", "Concurso do Menor Peixe", "Invasão Pirata", "Julgamento de Njord", "Barco Misterioso", "O Kraken", "Caldeirada", "Banquete da Caldeirada"]);

  const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
  const fold = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

  // Taxa chega como 0,2 num endpoint e 20 no outro. Devolve a fração (0,2) nos dois casos.
  function rate(v) {
    const n = num(v);
    if (n === null || n <= 0) return null;
    return n <= 1 ? n : n / 100;
  }

  // Nome que o Guia usa nas regras: o nome da API quando ele é conhecido; senão o do kind.
  function ruleName(ev) {
    if (!ev) return null;
    if (KNOWN_NAMES.has(ev.name)) return ev.name;
    return KIND_NAME[ev.kind] || ev.name || null;
  }

  const ids = (list) => (Array.isArray(list) ? list.map((x) => (x && typeof x === "object" ? x.id ?? x.label ?? x.name : x)).filter((x) => x != null) : []);
  const tiersOf = (ev) => {
    const out = ids(ev?.tiers).map(String);
    if (typeof ev?.target_tier === "string") out.push(ev.target_tier);
    if (typeof ev?.target_tier_label === "string") out.push(ev.target_tier_label);
    return [...new Set(out)];
  };

  // Alta / Média / Baixa / Desconhecida, a partir do kind e dos números que vieram.
  function relevance(ev, shopRate = null) {
    const kind = String(ev?.kind || "");
    const v = num(ev?.value);
    const tiers = tiersOf(ev).map(fold);
    const R = (level, why) => ({ level, why });
    switch (kind) {
      case "sell_multiplier": return R("alta", v > 0 ? `Venda paga ${v}x.` : "Venda turbinada ativa (multiplicador não informado).");
      case "store_discount": { const r = rate(ev?.value) ?? rate(shopRate); return r ? R("alta", `Desconto real de ${Math.round(r * 100)}%.`) : R("media", "Desconto ativo, mas a taxa não veio."); }
      case "double_xp": return R("alta", "Pontos e XP em dobro.");
      case "cooldown_reset": return R("alta", "Cooldown zerado.");
      case "fishing_frozen": return R("alta", "O $pescar está bloqueado.");
      case "tier_catch_boost":
        if (!tiers.length) return R("desconhecida", "A raridade sorteada não veio.");
        return tiers.some((t) => /secret|secreto|divin|mythic|mitico|legendary|lendario/.test(t)) ? R("alta", `Raridade sorteada: ${tiersOf(ev).join(", ")}.`) : R("baixa", `Raridade sorteada: ${tiersOf(ev).join(", ")}.`);
      case "double_twishcoins": return R("baixa", "Só afeta bits e subs.");
      case "cooldown_multiplier": case "catch_contest": case "catch_pot": case "species_boost": case "catch_drop": case "species_buyer": case "bite_factor": case "wash_away":
        return R("media", "Muda a pesca por alguns minutos.");
      default: {
        // Grandes eventos (Invasão, Njord, Barco, Kraken, Caldeirada...) não têm kind conhecido: valem o aviso.
        if (KNOWN_NAMES.has(ev?.name)) return R("alta", "Grande evento do barco.");
        return R("desconhecida", `Tipo de evento novo (${kind || "sem kind"}).`);
      }
    }
  }
  const LEVEL_RANK = { desconhecida: 0, baixa: 1, media: 2, alta: 3 };
  const LEVEL_LABEL = { desconhecida: "Desconhecida", baixa: "Baixa", media: "Média", alta: "Alta" };

  // Muda só quando o evento muda de verdade: a contagem regressiva fica de fora.
  function fingerprint(ev) {
    const o = ev || {};
    return JSON.stringify([o.kind ?? null, o.name ?? null, o.message ?? null, o.value ?? null, o.phase ?? null, o.target_tier_label ?? null, ids(o.species), ids(o.tiers)]);
  }

  // /events/active + /shop → lista de eventos normalizada. O Desconto na Loja às vezes vem só no
  // /shop (oferta do barco), sem evento: nesse caso entra como evento "shop".
  function extract(payload, shop, fetchedAt = Date.now()) {
    const out = [];
    const shopRate = rate(shop?.discount_rate);
    let hasDiscount = false;
    for (const [slot, ev] of [["grand", payload?.grande_evento], ["regular", payload?.event]]) {
      if (!ev || typeof ev !== "object" || typeof ev.name !== "string") continue;
      const secs = num(ev.seconds_remaining);
      if (secs !== null && secs <= 0) continue;
      if (ev.kind === "store_discount") hasDiscount = true;
      out.push(normalizeOne(ev, slot, fetchedAt, shopRate));
    }
    if (!hasDiscount && shopRate) {
      const secs = num(shop?.discount_seconds_remaining);
      if (secs === null || secs > 0) out.push(normalizeOne({ kind: "store_discount", name: "Desconto na Loja", value: shopRate, seconds_remaining: secs, message: `Itens da loja com ${Math.round(shopRate * 100)}% de desconto.` }, "shop", fetchedAt, shopRate));
    }
    return out;
  }
  function normalizeOne(ev, slot, fetchedAt, shopRate) {
    const secs = num(ev.seconds_remaining);
    const rel = relevance(ev, shopRate);
    return {
      slot, name: ev.name, rule: ruleName(ev), kind: ev.kind || null, value: num(ev.value),
      rate: ev.kind === "store_discount" ? rate(ev.value) ?? shopRate : null,
      message: typeof ev.message === "string" ? ev.message : "",
      emoji: typeof ev.emoji === "string" ? ev.emoji : null,
      tiers: tiersOf(ev), species: ids(ev.species),
      phase: ev.phase ?? null, progressCount: num(ev.progress_count), progressTarget: num(ev.progress_target),
      // Caldeirada: a panela espaço por espaço ({label, count, filled}), quando o Twish manda.
      recipe: Array.isArray(ev.recipe) ? ev.recipe.filter((r) => r && typeof r.label === "string").map((r) => ({ label: r.label, count: num(r.count), filled: num(r.filled) })) : null,
      endsAt: secs === null ? null : fetchedAt + secs * 1000,
      relevance: rel.level, relevanceWhy: rel.why,
      fingerprint: fingerprint(ev),
    };
  }

  // Volta para o formato cru que o planejador lê (event / grande_evento / shop_discount).
  function toPlannerEvents(list, now = Date.now()) {
    const out = {};
    for (const e of list || []) {
      if (Number.isFinite(e.endsAt) && e.endsAt <= now) continue;
      const raw = { name: e.rule || e.name, api_name: e.name, kind: e.kind, value: e.value, rate: e.rate, message: e.message, tiers: e.tiers, species: e.species, phase: e.phase, progress_count: e.progressCount, progress_target: e.progressTarget, recipe: e.recipe || undefined, seconds_remaining: Number.isFinite(e.endsAt) ? Math.max(0, (e.endsAt - now) / 1000) : null };
      const key = e.slot === "grand" ? "grande_evento" : e.slot === "shop" ? "shop_discount" : "event";
      if (!out[key]) out[key] = raw;
    }
    return out;
  }

  return { KIND_NAME, KNOWN_NAMES, LEVEL_RANK, LEVEL_LABEL, rate, ruleName, relevance, fingerprint, extract, toPlannerEvents };
});
