// Timoneiro — avisos na aba da Twitch: som quando a pesca libera e quando começa um evento,
// volume de cada som, e as preferências de notificação (usadas pelo fundo da extensão).
// O som toca uma vez por acontecimento em todo o navegador (trava no storage) e só na aba visível;
// com a Twitch em outra aba, quem toca é o fundo (notification-worker.js).
(function (root) {
  "use strict";
  if (root.TimoneiroAlerts) return;
  const Store = root.TimoneiroStore;
  const SOUNDS = "timoneiro.sounds.v1", NOTIF = "timoneiro.notifications.v1", LOCK = "timoneiro.soundLock.v1";
  const FILES = { fishingAlert: "sounds/pesca.wav", eventAlert: "sounds/evento.wav" };
  const DEFAULT = { fishingAlert: { enabled: true, volume: 7 }, eventAlert: { enabled: true, volume: 7 } };

  // ---------- sons ----------
  const vol = (v) => Math.round(Math.min(10, Math.max(1, Number(v) || 7)));
  function sounds() {
    const saved = Store?.get(SOUNDS, {}) || {};
    const out = {};
    for (const g of Object.keys(DEFAULT)) {
      const s = saved[g] || {};
      out[g] = { enabled: s.volume === 0 ? false : typeof s.enabled === "boolean" ? s.enabled : true, volume: s.volume === 0 ? DEFAULT[g].volume : vol(s.volume ?? DEFAULT[g].volume) };
    }
    return out;
  }
  function setSound(group, patch) {
    const all = sounds();
    if (!all[group]) return;
    if (typeof patch.enabled === "boolean") all[group].enabled = patch.enabled;
    if (patch.volume != null) all[group].volume = vol(patch.volume);
    return Store.set(SOUNDS, all);
  }
  const players = new Map();
  // Devolve true se tocou (ou se o som está desligado: aí ninguém deve tocar), false se o navegador bloqueou.
  async function play(group) {
    const s = sounds()[group];
    if (!s || !s.enabled) return true;
    try {
      if (!players.has(group)) players.set(group, new Audio(chrome.runtime.getURL(`assets/${FILES[group]}`)));
      const a = players.get(group);
      a.volume = s.volume / 10; a.currentTime = 0;
      await a.play();
      return true;
    } catch (_) { return false; }
  }

  // ---------- notificações (padrão: ligadas) ----------
  const notifications = () => { const n = Store?.get(NOTIF, {}) || {}; return { fishing: n.fishing !== false, event: n.event !== false }; };
  function toggleNotification(group) {
    const cur = Store?.get(NOTIF, {}) || {};
    return Store.set(NOTIF, { ...cur, [group]: !notifications()[group] });
  }

  // ---------- aviso na própria página (Twitch na tela) ----------
  // Com o navegador em foco, alguns sistemas escondem a notificação dele (o GNOME, no Linux, manda
  // direto para a lista, sem balão). Com a Twitch visível, o aviso aparece também aqui, acima da barra.
  // O mesmo aviso vindo da página e do fundo aparece uma vez só. A chave é a mesma do som
  // ("fishing|barco|hora em que liberou", "event|barco|nome|fim"); sem chave, vale o título.
  let toastTimer = null;
  const shown = new Map();
  const sameKey = (title) => "t|" + String(title || "").replace(/[^\p{L}\p{N}]+/gu, "").toLowerCase();
  const make = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  function hideToast() { clearTimeout(toastTimer); const t = document.getElementById("tmn-toast"); if (t) t.hidden = true; }
  function toast({ icon, title, text, action, onAction, key }) {
    const host = document.getElementById("tmn-root");
    if (!host) return;
    const k = key || sameKey(title), at = shown.get(k);
    if (at && Date.now() - at < (key ? 30 * 60e3 : 30e3)) return;
    shown.set(k, Date.now());
    let t = document.getElementById("tmn-toast");
    if (!t) {
      t = make("div", "tmn-toast"); t.id = "tmn-toast";
      t.setAttribute("role", "status"); t.setAttribute("aria-live", "polite");
      host.append(t);
    }
    t.replaceChildren();
    const body = make("div", "tmn-toast-body");
    body.append(make("b", null, title));
    if (text) body.append(make("span", null, text));
    const icn = make("span", "tmn-toast-icon", icon); icn.setAttribute("aria-hidden", "true");
    const go = action ? make("button", "tmn-toast-action", action) : null;
    if (go) { go.type = "button"; go.addEventListener("click", (e) => { if (!e.isTrusted) return; hideToast(); onAction?.(); }); }
    const close = make("button", "tmn-toast-close"); close.type = "button";
    close.setAttribute("aria-label", "Fechar aviso");
    close.append(root.TimoneiroIcons ? root.TimoneiroIcons.icon("close", 14) : document.createTextNode("✕"));
    close.addEventListener("click", hideToast);
    t.append(...[icn, body, go, close].filter(Boolean));
    t.hidden = false;
    // Fixo na tela, logo acima da barra e alinhado à direita dela.
    const a = host.getBoundingClientRect(), w = t.offsetWidth, h = t.offsetHeight;
    t.style.left = `${Math.max(8, Math.min(a.right - w, innerWidth - w - 8))}px`;
    t.style.top = `${a.top - h - 8 >= 8 ? a.top - h - 8 : Math.min(a.bottom + 8, innerHeight - h - 8)}px`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(hideToast, 20e3);
  }

  // ---------- quando tocar ----------
  // A trava vale só para o som (toca uma vez no navegador todo). O aviso na página não depende dela:
  // se o fundo avisou primeiro (o Twish disse "liberado" antes da hora), a Twitch na tela mostra mesmo assim.
  const onScreen = () => document.visibilityState === "visible" && !(root.TimoneiroChannel && !root.TimoneiroChannel.allowed());
  async function once(kind, key, group, notice) {
    if (!onScreen()) return;
    const SL = root.TimoneiroSoundLock;
    let sound = false, before = null;
    try {
      before = (await chrome.storage.local.get(LOCK))[LOCK] || {};
      if (SL.canPlay(before, kind, key)) {
        await chrome.storage.local.set({ [LOCK]: SL.take(before, kind, key) });
        sound = true;
      }
    } catch (_) {}
    // Depois do await: as preferências que chegaram junto com o evento já valem aqui.
    if (notice && notifications()[kind]) toast({ ...notice, key: `${kind}|${key}` });
    if (!sound || (await play(group))) return;
    // O navegador bloqueou o áudio desta aba (ex.: aba que dormiu e recarregou sem clique): o fundo toca.
    try {
      const now = (await chrome.storage.local.get(LOCK))[LOCK] || {};
      await chrome.storage.local.set({ [LOCK]: SL.release(now, kind, key, before) });
    } catch (_) {}
  }

  // Avisos do fundo (pesca, evento, Torneio, Frota, sala, Mercado): com a Twitch na tela, aparecem aqui
  // também. No Windows com as notificações do sistema desligadas, este é o único aviso que se vê.
  const FILL = { "timoneiro-fishing": "$pescar", "timoneiro-tournament": "$entrar", "timoneiro-fleet": "$embarcar" };
  const ICON = { "timoneiro-fishing": "🎣", "timoneiro-event": "🎪", "timoneiro-event-end": "🎪", "timoneiro-tournament": "🏆", "timoneiro-fleet": "⚓", "timoneiro-room": "🧭", "timoneiro-market": "🛒" };
  function fromBackground(msg) {
    if (!onScreen()) return;
    const fill = FILL[msg.id];
    const guide = !fill && msg.id !== "timoneiro-market";
    toast({
      icon: ICON[msg.id] || "🔔", title: msg.title, text: msg.message, key: msg.key || null,
      action: fill || (guide ? "Ver no Guia" : null),
      onAction: () => (fill ? root.TimoneiroMenu?.run(fill, { fromBar: true }) : root.TimoneiroMenu?.open("guia")),
    });
  }
  try { chrome.runtime.onMessage.addListener((msg) => { if (msg?.type === "timoneiro-notice") fromBackground(msg); return false; }); } catch (_) {}

  let armedFor = null, timer = null, lastEvent = null, eventSeen = false;
  // Pesca: agenda o som para a hora exata em que libera (readyAt), sem esperar outra leitura.
  // Evento: toca quando aparece um evento com nome novo.
  function observe(fishing, event, now = Date.now()) {
    const c = root.TimoneiroStatus?.countdown(fishing, now);
    if (c && c.mode === "cooldown" && Number.isFinite(fishing.readyAt) && armedFor !== fishing.readyAt) {
      clearTimeout(timer);
      const at = (armedFor = fishing.readyAt), boat = fishing.boat;
      const notice = { icon: "🎣", title: "Pesca disponível!", text: "Seu cooldown no Twish acabou.", action: "$pescar", onAction: () => root.TimoneiroMenu?.run("$pescar", { fromBar: true }) };
      timer = setTimeout(() => { if (armedFor === at) once("fishing", `${boat}|${Math.round(at / 10000)}`, "fishingAlert", notice); }, Math.max(0, at - Date.now()) + 300);
    }
    const recent = event && Number.isFinite(event.updatedAt) && now - event.updatedAt <= 30e3;
    if (!recent) return;
    const name = event.active ? event.name : null;
    if (eventSeen && name && name !== lastEvent) {
      const end = Number.isFinite(event.endsAt) ? Math.round(event.endsAt / 60000) : "x";
      once("event", `${event.boat}|${name}|${end}`, "eventAlert", { icon: event.kind === "grand" ? "🌟" : "🎪", title: `Evento: ${name}`, text: event.description || "Começou agora.", action: "Ver no Guia", onAction: () => root.TimoneiroMenu?.open("guia") });
    }
    if (name) lastEvent = name; else if (!event.active) lastEvent = null;
    eventSeen = true;
  }

  root.TimoneiroAlerts = { observe, sounds, setSound, play, notifications, toggleNotification, toast, hideToast };
})(globalThis);
