// Boas-vindas: "Mostrar só nestes canais" e "Fixar barco" (só o nome do canal, validado como em Ajustes).
(() => {
  "use strict";
  const B = globalThis.TimoneiroBoats;
  const PREFS = "timoneiro.boatPrefs.v1", CHANNELS = "timoneiro.channels.v1";
  const $ = (id) => document.getElementById(id);
  const only = $("bv-only"), pin = $("bv-pin"), status = $("bv-status");
  if (!B || !only || !pin) return;
  let known = [];

  function showErrors(input, box, errors) {
    box.replaceChildren();
    box.hidden = !errors.length;
    input.setAttribute("aria-invalid", String(!!errors.length));
    for (const e of errors) {
      const p = document.createElement("p");
      p.textContent = B.nameError(e);
      if (e.suggestion) {
        const fix = document.createElement("button");
        fix.type = "button"; fix.className = "bv-fix"; fix.textContent = `Usar ${e.suggestion}`;
        fix.addEventListener("click", () => {
          input.value = input.value.split(/([,;\s]+)/).map((tok) => (tok === e.raw ? e.suggestion : tok)).join("");
          check();
        });
        p.append(fix);
      }
      box.append(p);
    }
  }
  // Confere os dois campos e mostra o que está errado. Devolve os valores prontos para salvar ou null.
  function check() {
    const list = B.checkList(only.value, known);
    const pinText = pin.value.trim();
    const p = pinText ? B.checkName(pinText, known) : { ok: true, name: null };
    showErrors(only, $("bv-only-error"), list.errors);
    showErrors(pin, $("bv-pin-error"), p.ok ? [] : [{ raw: pinText, ...p }]);
    return list.errors.length || !p.ok ? null : { only: list.names, pinned: p.name };
  }
  // Confere ao clicar em Salvar (e no "Usar …"), não ao sair do campo: a mensagem de erro aparecendo
  // naquela hora empurraria o botão Salvar para baixo no meio do clique.

  $("bv-salvar").addEventListener("click", async () => {
    const v = check();
    if (!v) { status.textContent = "Nada foi salvo: corrija o que está marcado acima."; return; }
    const cur = (await chrome.storage.local.get(PREFS))[PREFS] || { pinned: null, hidden: [] };
    await chrome.storage.local.set({ [PREFS]: { ...cur, pinned: v.pinned, only: v.only, migrated: true } });
    status.textContent = v.pinned ? `Salvo. Barco fixado: ${v.pinned}. A barra aparece só na live dele.`
      : v.only.length ? `Salvo. O Timoneiro aparece só em: ${v.only.join(", ")}.`
      : "Salvo. O Timoneiro aparece em qualquer live de barco do Twish.";
  });

  chrome.storage.local.get([PREFS, CHANNELS]).then((r) => {
    known = Array.isArray(r[CHANNELS]?.list) ? r[CHANNELS].list : [];
    const p = r[PREFS] || {};
    if (!only.value) only.value = (p.only || []).join(", ");
    if (!pin.value) pin.value = p.pinned || "";
  });
})();

// Boas-vindas: botão de teste do aviso (notificação + som), 3 s depois para dar tempo de trocar de aba.
(() => {
  "use strict";
  const btn = document.getElementById("testar");
  const status = document.getElementById("teste-status");
  btn.addEventListener("click", () => {
    btn.disabled = true;
    status.textContent = "Troque de aba agora. O aviso chega em 3 segundos.";
    setTimeout(async () => {
      try {
        const r = await chrome.runtime.sendMessage({ type: "timoneiro-test-alert" });
        status.textContent = r?.played === false ? "Notificação enviada. O som não tocou: confira o volume do navegador." : "Aviso enviado. Se você viu e ouviu, está tudo certo.";
      } catch (_) {
        status.textContent = "Não deu para enviar o aviso. Recarregue o Timoneiro em chrome://extensions e tente de novo.";
      }
      btn.disabled = false;
    }, 3000);
  });
})();
