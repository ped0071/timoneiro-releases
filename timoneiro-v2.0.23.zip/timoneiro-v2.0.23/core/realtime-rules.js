// Timoneiro — regras do tempo real do Twish (Centrifugo): o que cada aviso pede e quanto esperar.
// Puro: sem WebSocket, timers nem chrome.*. Usado por twish-realtime.js; o socket e os timers ficam lá.
// O sorteio entra como rand (padrão Math.random), para os testes ficarem determinísticos.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroRealtimeRules = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const KINDS = ["player", "events", "tournament"];
  const later = (key, ms, job) => ({ do: "later", key, ms, job });

  // Ação para um aviso do canal `kind`. null: nada a fazer (outro barco ou tipo desconhecido).
  function route(kind, d, channelId, rand = Math.random) {
    // O canal do jogador é global: avisos de outro barco ficam de fora (o site faz o mesmo).
    if (kind === "player" && d.channel_id && channelId && d.channel_id !== channelId && d.type !== "listing_sold" && d.type !== "listing_held") return null;
    const t = d.type;
    if (kind === "player") {
      if (t === "cooldown_changed") return typeof d.remaining === "number" ? { do: "setCooldown", seconds: d.remaining } : { do: "refetchFishing" };
      if (t === "cooldowns_cleared") return { do: "setCooldown", seconds: 0 };
      if (t === "capture_added") return later("account", 1500, "account");
      if (t === "challenge_changed") return { do: "setChallenge", secondsLeft: d.seconds_left };
      if (t === "resync") return later("resync", rand() * 10000, "catchUp");
      if (/^expedition_/.test(t || "")) return later("sea", 1000, "expeditions");
      if (t === "listing_sold" || t === "listing_held") return later("account", 1500, "account");
      return null;
    }
    if (kind === "events") {
      if (t === "cooldowns_cleared") return { do: "setCooldown", seconds: 0 };
      // Sem "state" o servidor pede para todos relerem: espalha no tempo como o site (até 30 s).
      return later("events", t === "events_changed" && d.state ? rand() * 2000 : rand() * 30000, "events");
    }
    if (kind === "tournament") return later("tour", 500 + rand() * 1500, "tournament");
    return null;
  }

  // Nome do canal → tipo, a partir de info.channels de /api/<barco>/realtime.
  function channelKinds(channels) {
    const out = {};
    for (const [kind, ch] of Object.entries(channels || {})) if (typeof ch === "string" && KINDS.includes(kind)) out[ch] = kind;
    return out;
  }

  function wsUrl(url, origin) {
    const u = new URL(url, origin);
    if (u.protocol === "https:") u.protocol = "wss:";
    if (u.protocol === "http:") u.protocol = "ws:";
    return u.href;
  }

  // Espera antes de reconectar. O expoente para em 6: na prática o teto é 64 s × (0,5 a 1,5), não 120 s.
  const retryDelay = (retries, rand = Math.random) => Math.min(120, 2 ** Math.min(retries, 6)) * 1000 * (0.5 + rand());

  // Token com validade: renova 30 s antes de vencer (no mínimo 10 s). null: sem renovação.
  function refreshDelay(res) {
    if (!res?.expires || !Number.isFinite(res.ttl)) return null;
    return Math.max(10, res.ttl - 30) * 1000;
  }

  return { route, channelKinds, wsUrl, retryDelay, refreshDelay };
});
