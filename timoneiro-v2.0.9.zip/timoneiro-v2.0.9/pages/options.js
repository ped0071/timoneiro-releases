// Opções: Discord (permissão pedida só ao salvar) e backup dos dados.
(() => {
  "use strict";
  const KEY = "timoneiro.discord.v1";
  const ORIGINS = ["https://discord.com/api/webhooks/*", "https://discordapp.com/api/webhooks/*"];
  const WEBHOOK_RE = /^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+$/;
  const $ = (id) => document.getElementById(id);

  async function render() {
    const cfg = (await chrome.storage.local.get(KEY))[KEY] || {};
    const allowed = await chrome.permissions.contains({ origins: ORIGINS });
    $("webhook").value = cfg.url || "";
    $("sem-permissao").hidden = !cfg.url || allowed;
    $("chaves").hidden = !cfg.url;
    $("remover").hidden = !cfg.url;
    $("testar").disabled = !cfg.url || !allowed;
    document.querySelectorAll("#chaves input").forEach((i) => { i.checked = cfg[i.dataset.k] === true; });
  }

  $("salvar").onclick = async () => {
    const url = $("webhook").value.trim();
    if (!WEBHOOK_RE.test(url)) { $("msg-discord").textContent = "Essa URL não é um webhook do Discord. Ela começa com https://discord.com/api/webhooks/."; return; }
    // Precisa vir do clique: o navegador mostra o pedido de permissão agora.
    const ok = await chrome.permissions.request({ origins: ORIGINS }).catch(() => false);
    if (!ok) { $("msg-discord").textContent = "Sem a permissão o Timoneiro não consegue enviar ao Discord. O webhook não foi salvo."; return; }
    const cur = (await chrome.storage.local.get(KEY))[KEY] || {};
    await chrome.storage.local.set({ [KEY]: cur.url ? { ...cur, url } : { fishing: true, event: true, alerts: true, url } });
    $("msg-discord").textContent = "Webhook salvo. Use Testar para conferir.";
    render();
  };
  $("testar").onclick = async () => {
    $("testar").disabled = true; $("msg-discord").textContent = "Enviando…";
    const r = await chrome.runtime.sendMessage({ type: "timoneiro-discord-test" }).catch(() => null);
    $("msg-discord").textContent = r?.ok ? "Mensagem de teste enviada. Confira o canal." : r?.error || "Não deu para enviar. Recarregue o Timoneiro e tente de novo.";
    render();
  };
  $("remover").onclick = async () => {
    if (!confirm("Remover o webhook? Os avisos param de ir para o Discord.")) return;
    await chrome.storage.local.remove(KEY);
    await chrome.permissions.remove({ origins: ORIGINS }).catch(() => {});
    $("msg-discord").textContent = "Webhook removido.";
    render();
  };
  $("chaves").addEventListener("change", async (e) => {
    const k = e.target?.dataset?.k; if (!k) return;
    const cur = (await chrome.storage.local.get(KEY))[KEY] || {};
    await chrome.storage.local.set({ [KEY]: { ...cur, [k]: e.target.checked } });
  });

  $("exportar").onclick = async () => {
    const out = TimoneiroBackup.exportData(await chrome.storage.local.get(null));
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 1)], { type: "application/json" }));
    a.download = `timoneiro-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    $("msg-backup").textContent = `Backup salvo com ${Object.keys(out.data).length} itens.`;
  };
  $("importar").onclick = () => $("arquivo").click();
  $("arquivo").onchange = async () => {
    const f = $("arquivo").files?.[0]; if (!f) return;
    let json = null;
    try { json = JSON.parse(await f.text()); } catch (_) { $("msg-backup").textContent = "Esse arquivo não é um JSON válido."; return; }
    const r = TimoneiroBackup.importData(json);
    if (!r.ok) { $("msg-backup").textContent = r.error; return; }
    await chrome.storage.local.set(r.data);
    $("msg-backup").textContent = `Backup importado: ${Object.keys(r.data).length} itens. Recarregue as abas da Twitch e do Twish.`;
    $("arquivo").value = "";
  };

  // Barco e canais escondidos: na Twitch, um canal escondido some com a barra (e com os Ajustes),
  // então é aqui que se desfaz.
  const PREFS = "timoneiro.boatPrefs.v1", BOAT = "timoneiro.boat.v2";
  async function renderCanais() {
    const r = await chrome.storage.local.get([PREFS, BOAT]);
    const prefs = r[PREFS] || { pinned: null, hidden: [] };
    const boat = r[BOAT]?.boat || null;
    $("barco-atual").textContent = !boat ? "Nenhum barco ainda: abra a live de um barco do Twish." : prefs.pinned ? `Barco fixado: ${prefs.pinned}. Para voltar ao automático, apague em Ajustes na live.` : `Barco agora: ${boat} (segue o canal da live).`;
    const ul = $("escondidos"); ul.replaceChildren();
    if (!prefs.hidden?.length) { const li = document.createElement("li"); li.className = "muted"; li.textContent = "Nenhum canal escondido."; ul.append(li); return; }
    for (const ch of prefs.hidden) {
      const li = document.createElement("li");
      const b = document.createElement("button"); b.type = "button"; b.dataset.unhide = ch; b.textContent = "Mostrar de novo";
      b.onclick = async () => {
        const cur = (await chrome.storage.local.get(PREFS))[PREFS] || prefs;
        await chrome.storage.local.set({ [PREFS]: { ...cur, hidden: (cur.hidden || []).filter((x) => x !== ch), migrated: true } });
      };
      const name = document.createElement("span"); name.textContent = ch;
      li.append(name, b); ul.append(li);
    }
  }

  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== "local") return;
    if (c[KEY]) render();
    if (c[PREFS] || c[BOAT]) renderCanais();
  });
  render();
  renderCanais();
})();
