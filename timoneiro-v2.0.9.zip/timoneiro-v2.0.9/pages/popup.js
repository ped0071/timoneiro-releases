// Popup do ícone: barco, próxima pesca, eventos e saúde dos avisos. Só lê o storage.
(() => {
  "use strict";
  const K = {
    boat: "timoneiro.boat.v2",
    prefs: "timoneiro.boatPrefs.v1",
    fishing: "timoneiro.fishingStatus.v1",
    events: "timoneiro.events.v2",
    bg: "timoneiro.bgSync.v1",
    realtime: "timoneiro.realtime.v1",
    smart: "timoneiro.smartData.v1",
    channels: "timoneiro.channels.v1",
    update: "timoneiro.update.v1",
  };
  const $ = (id) => document.getElementById(id);
  let data = {};

  const mmss = (ms) => { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
  const restante = (ms) => { const m = Math.round(ms / 60000); return m < 1 ? "menos de 1 min" : m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`; };

  function render() {
    const boat = data[K.boat]?.boat || null;
    const pinned = data[K.prefs]?.pinned || null;
    $("vazio").hidden = !!boat;
    $("painel").hidden = !boat;
    $("abrir-chat").disabled = !boat;
    $("abrir-guia").disabled = !boat;
    $("barco").replaceChildren();
    if (boat) {
      const b = document.createElement("strong"); b.textContent = boat;
      $("barco").append(b, pinned ? "barco fixado" : "canal da live");
    }

    // Versão nova (conferida pela assinatura), comparada com a instalada agora.
    const installed = chrome.runtime.getManifest().version;
    const up = globalThis.TimoneiroUpdate?.pending(data[K.update], installed);
    $("atualizacao").hidden = !up;
    if (up) {
      const b = document.createElement("b"); b.textContent = `⬆ Atualize o Timoneiro: versão ${up.version}`;
      const s = document.createElement("span"); s.textContent = `Você está na ${installed}.${up.important ? " Atualização importante." : ""} Clique para ver como atualizar.`;
      $("atualizacao").replaceChildren(b, s);
    }

    const now = Date.now();
    const f = data[K.fishing];
    const fresh = f && f.boat === boat && now - (f.updatedAt || 0) < 15 * 60e3;
    const leme = $("leme");
    if (!fresh) {
      leme.dataset.state = "unknown"; leme.style.setProperty("--p", 0);
      $("tempo").textContent = "—"; $("pesca-titulo").textContent = "Próxima pesca";
      $("pesca-texto").textContent = "Esperando a primeira leitura da sua conta.";
      leme.setAttribute("aria-label", "Tempo até a próxima pesca desconhecido");
    } else if (f.status === "available" || (f.readyAt && f.readyAt <= now)) {
      leme.dataset.state = "ready"; $("tempo").textContent = "Já!";
      $("pesca-titulo").textContent = "Pode pescar";
      $("pesca-texto").textContent = "Use $pescar no chat da live.";
      leme.setAttribute("aria-label", "Pesca disponível");
    } else {
      const left = f.readyAt - now;
      const total = (f.cooldown || 0) * 1000 || Math.max(left, 1);
      leme.dataset.state = "cooldown"; leme.style.setProperty("--p", Math.min(1, left / total));
      $("tempo").textContent = mmss(left);
      $("pesca-titulo").textContent = "Próxima pesca";
      $("pesca-texto").textContent = "Você recebe um aviso quando liberar.";
      leme.setAttribute("aria-label", `Próxima pesca em ${mmss(left)}`);
    }

    const ev = data[K.events];
    const list = ev && ev.boat === boat ? (ev.list || []).filter((e) => !Number.isFinite(e.endsAt) || e.endsAt > now) : [];
    const ul = $("eventos"); ul.replaceChildren();
    if (!list.length) { const li = document.createElement("li"); li.textContent = "Nenhum evento agora."; ul.append(li); }
    for (const e of list) {
      const li = document.createElement("li");
      const a = document.createElement("span"); a.textContent = `${e.emoji ? e.emoji + " " : ""}${e.rule || e.name || "Evento"}`;
      const b = document.createElement("span"); b.textContent = Number.isFinite(e.endsAt) ? restante(e.endsAt - now) : "";
      li.append(a, b); ul.append(li);
    }

    const h = globalThis.TimoneiroHealth.compute({ bg: data[K.bg], fishingAt: fresh ? f.updatedAt : 0, smartAt: data[K.smart]?.boat === boat ? data[K.smart]?.updatedAt || 0 : 0, realtime: data[K.realtime], boat, now });
    // Com dica (login, limite, fundo parado) a bolinha não fica verde: o texto é um alerta.
    $("saude").dataset.level = !boat ? "bad" : h.hint && h.level === "ok" ? "warn" : h.level;
    $("saude").textContent = boat ? (h.hint || h.text) : "Nenhum barco ainda.";
  }

  // "Neste canal": a aba aberta é uma live da Twitch? Esconder, mostrar ou soltar o barco fixado, com um clique.
  let tabChannel = null;
  async function findTab() {
    try { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabChannel = TimoneiroBoats.channelFromUrl(t?.url || ""); } catch (_) { tabChannel = null; }
  }
  async function setPrefs(patch) {
    const cur = (await chrome.storage.local.get(K.prefs))[K.prefs] || { pinned: null, hidden: [] };
    await chrome.storage.local.set({ [K.prefs]: { ...cur, ...patch, migrated: true } });
  }
  function renderHere() {
    const box = $("aqui"), btn = document.querySelector("[data-here-toggle]");
    if (!tabChannel) { box.hidden = true; return; }
    const prefs = data[K.prefs] || { pinned: null, hidden: [] };
    const list = data[K.channels]?.list || null;
    const hidden = (prefs.hidden || []).includes(tabChannel);
    box.hidden = false;
    if (hidden) {
      $("aqui-texto").textContent = `Escondido em ${tabChannel}.`;
      btn.textContent = "Mostrar aqui";
      btn.onclick = () => setPrefs({ hidden: (prefs.hidden || []).filter((x) => x !== tabChannel) });
    } else if (prefs.pinned && prefs.pinned !== tabChannel) {
      $("aqui-texto").textContent = `Barco fixado em ${prefs.pinned}: o Timoneiro só aparece lá.`;
      btn.textContent = "Soltar o barco fixado";
      btn.onclick = () => setPrefs({ pinned: null });
    } else if (!prefs.pinned && (prefs.only || []).length && !prefs.only.includes(tabChannel)) {
      $("aqui-texto").textContent = `${tabChannel} está fora da sua lista de canais.`;
      btn.textContent = "Adicionar aqui";
      btn.onclick = () => setPrefs({ only: [...new Set([...prefs.only, tabChannel])] });
    } else if (list && !list.includes(tabChannel) && prefs.pinned !== tabChannel && !(prefs.only || []).includes(tabChannel)) {
      $("aqui-texto").textContent = `${tabChannel} não tem barco no Twish.`;
      btn.hidden = true; return;
    } else {
      $("aqui-texto").textContent = `Aparecendo em ${tabChannel}.`;
      btn.textContent = "Esconder aqui";
      btn.onclick = () => setPrefs({ hidden: [...new Set([...(prefs.hidden || []), tabChannel])] });
    }
    btn.hidden = false;
  }

  async function load() { data = await chrome.storage.local.get(Object.values(K)); render(); renderHere(); }
  chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && Object.values(K).some((k) => c[k])) load(); });
  setInterval(render, 1000);

  $("abrir-twish").onclick = () => chrome.tabs.create({ url: "https://twish.com.br/" });
  $("abrir-chat").onclick = () => chrome.runtime.sendMessage({ type: "timoneiro-open-chat" }).then(() => window.close());
  $("abrir-guia").onclick = () => chrome.runtime.sendMessage({ type: "timoneiro-open-guide" }).then(() => window.close());
  $("opcoes").onclick = () => chrome.runtime.openOptionsPage();
  findTab().then(load).then(() => {
    // Abriu o popup e a última procura por versão nova tem mais de 15 min: procura agora (o aviso aparece sozinho).
    if (Date.now() - (data[K.update]?.checkedAt || 0) > 15 * 60e3) chrome.runtime.sendMessage({ type: "timoneiro-check-update" }).catch(() => {});
  });
})();
