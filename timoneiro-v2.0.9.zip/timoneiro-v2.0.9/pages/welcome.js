// Boas-vindas: botão de teste do aviso (notificação + som), 3 s depois para dar tempo de trocar de aba.
(() => {
  "use strict";
  const btn = document.getElementById("testar");
  const status = document.getElementById("teste-status");
  btn.addEventListener("click", () => {
    btn.disabled = true;
    status.textContent = "Troque de aba agora. O aviso chega em 3 segundos.";
    setTimeout(async () => {
      try {
        const r = await chrome.runtime.sendMessage({ type: "timoneiro-test-alert" });
        status.textContent = r?.played === false ? "Notificação enviada. O som não tocou: confira o volume do navegador." : "Aviso enviado. Se você viu e ouviu, está tudo certo.";
      } catch (_) {
        status.textContent = "Não deu para enviar o aviso. Recarregue o Timoneiro em chrome://extensions e tente de novo.";
      }
      btn.disabled = false;
    }, 3000);
  });
})();
