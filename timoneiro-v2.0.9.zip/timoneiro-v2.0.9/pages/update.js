// Página de atualização: mostra a versão nova (já conferida pelo fundo), as notas e o passo a passo.
(() => {
  "use strict";
  const KEY = "timoneiro.update.v1";
  const $ = (id) => document.getElementById(id);
  const installed = chrome.runtime.getManifest().version;

  function render(u) {
    const has = !!(u && u.available && u.latest);
    $("tem").hidden = !has;
    $("titulo").textContent = has ? `Timoneiro ${u.latest.version} saiu` : "Você está na versão mais nova";
    $("versoes").textContent = has ? `Instalada: ${installed}. Nova: ${u.latest.version}.` : u && u.checkedAt ? `Instalada: ${installed}. Conferido agora há pouco.` : `Instalada: ${installed}.`;
    if (!has) return;
    $("notas").textContent = u.latest.notes || "Melhorias e correções.";
    $("baixar").href = u.latest.files.chrome.url;
    $("baixar-ff").href = u.latest.files.firefox.url;
  }

  $("procurar").onclick = async () => {
    $("procurar").disabled = true;
    $("versoes").textContent = "Procurando…";
    const u = await chrome.runtime.sendMessage({ type: "timoneiro-check-update" }).catch(() => null);
    $("procurar").disabled = false;
    if (!u || (!u.ok && !u.available)) { $("versoes").textContent = `Instalada: ${installed}. Não deu para conferir agora; tente de novo mais tarde.`; return; }
    render(u);
  };

  chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && c[KEY]) render(c[KEY].newValue); });
  chrome.storage.local.get(KEY).then((r) => render(r[KEY]));
  // Com esta página aberta, o fundo confere a pasta a cada minuto (recarrega sozinho quando os arquivos mudam).
  try { chrome.runtime.sendMessage({ type: "timoneiro-watch-files", on: true }).catch(() => {}); } catch (_) {}
})();
