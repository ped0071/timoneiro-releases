// Timoneiro — versão nova na Twitch: a barra, o menu e o Guia perguntam aqui se há atualização
// pendente (conferida pela assinatura no fundo) e pedem ao fundo para abrir a página de atualização.
(function (root) {
  "use strict";
  if (root.TimoneiroUpdateNotice) return;
  const Store = root.TimoneiroStore;
  const KEY = "timoneiro.update.v1";
  function installed() { try { return chrome.runtime.getManifest().version; } catch (_) { return null; } }
  // { version, notes, important, installed } ou null. Some sozinho depois de atualizar.
  function pending() {
    const v = installed();
    const p = v && root.TimoneiroUpdate?.pending(Store?.get(KEY), v);
    return p ? { version: p.version, notes: p.notes || "", important: !!p.important, installed: v } : null;
  }
  function open() { try { chrome.runtime.sendMessage({ type: "timoneiro-open-update" }).catch(() => {}); } catch (_) {} }
  root.TimoneiroUpdateNotice = { KEY, pending, open };
})(globalThis);
