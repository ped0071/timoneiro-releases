// Timoneiro — preferências da barra no chrome.storage da extensão (a página da Twitch não lê).
// Até a 1.99 algumas ficavam no localStorage da Twitch: são trazidas uma vez e apagadas de lá.
(function (root) {
  "use strict";
  if (root.TimoneiroStore) return;
  const cache = new Map();
  const watchers = new Map();

  // [chave antiga no localStorage, chave nova, conversão]
  const FROM_PAGE = [
    ["twish.quick.shortcuts.v1", "timoneiro.quick.v1", (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string").slice(0, 6) : undefined)],
    ["pescaskills.soundSettings.v2", "timoneiro.sounds.v1", (v) => (v && typeof v === "object" ? v : undefined)],
    ["pescaskills.guide.v2", "timoneiro.guide.v2", (v) => (v && typeof v === "object" ? v : undefined)],
    ["pescaskills.theme.v1", "timoneiro.theme.v1", (v) => (v === "classic" ? "auto" : v === "skills" ? "skills" : undefined)],
  ];

  function readPage(key) {
    let raw = null;
    try { raw = localStorage.getItem(key); } catch (_) { return undefined; }
    if (raw == null) return undefined;
    try { return JSON.parse(raw); } catch (_) { return raw; }
  }

  // Uma vez só: depois disso a página não consegue plantar valores (ela também escreve no localStorage).
  // O Arremesso automático nunca vem de lá: quem usava liga de novo em Ajustes.
  const ADOPTED = "timoneiro.pageKeysAdopted.v1";
  async function adoptPageKeys() {
    try { localStorage.removeItem("pescaskills.clickSendFishing.v1"); } catch (_) {}
    if ((await chrome.storage.local.get(ADOPTED))[ADOPTED]) return;
    const have = await chrome.storage.local.get(FROM_PAGE.map(([, nu]) => nu));
    const set = {};
    for (const [old, nu, conv] of FROM_PAGE) {
      const v = readPage(old);
      if (v === undefined) continue;
      const value = conv(v);
      if (value !== undefined && !(nu in have)) set[nu] = value;
      try { localStorage.removeItem(old); } catch (_) {}
    }
    set[ADOPTED] = true;
    await chrome.storage.local.set(set);
  }

  const ready = (async () => {
    await root.TimoneiroKeys?.ready();
    await adoptPageKeys().catch(() => {});
    const all = await chrome.storage.local.get(null).catch(() => ({}));
    for (const [k, v] of Object.entries(all)) if (k.startsWith("timoneiro.")) cache.set(k, v);
  })();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    for (const [k, ch] of Object.entries(changes)) {
      if (ch.newValue === undefined) cache.delete(k); else cache.set(k, ch.newValue);
      for (const fn of watchers.get(k) || []) { try { fn(ch.newValue); } catch (_) {} }
    }
  });

  root.TimoneiroStore = {
    ready,
    get: (key, fallback) => (cache.has(key) ? cache.get(key) : fallback),
    set: (key, value) => { cache.set(key, value); return chrome.storage.local.set({ [key]: value }).catch(() => {}); },
    watch(keys, fn) { for (const k of [].concat(keys)) { if (!watchers.has(k)) watchers.set(k, new Set()); watchers.get(k).add(fn); } },
  };
})(globalThis);
