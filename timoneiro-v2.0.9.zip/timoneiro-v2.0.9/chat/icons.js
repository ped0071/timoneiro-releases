// Timoneiro — ícones de traço em SVG (fechar, menu, recolher). Glifos de texto como ✕ e ≡ mudam
// de altura conforme a fonte do sistema; desenhados, ficam no centro em qualquer computador.
(function (root) {
  "use strict";
  if (root.TimoneiroIcons) return;
  const NS = "http://www.w3.org/2000/svg";
  const PATHS = {
    close: "M4 4l8 8M12 4l-8 8",
    menu: "M3 4.5h10M3 8h10M3 11.5h10",
    minus: "M4 8h8",
    star: "M8 1.8l1.9 4 4.4.5-3.25 3 .9 4.35L8 11.45l-3.95 2.2.9-4.35-3.25-3 4.4-.5z",
  };
  // filled: preenchido com a cor do texto (estrela marcada).
  function icon(name, size = 16, { filled = false } = {}) {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 16 16");
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    svg.style.display = "block";
    const p = document.createElementNS(NS, "path");
    p.setAttribute("d", PATHS[name] || "");
    p.setAttribute("fill", filled ? "currentColor" : "none");
    p.setAttribute("stroke", "currentColor");
    p.setAttribute("stroke-width", name === "star" ? "1.3" : "1.8");
    p.setAttribute("stroke-linejoin", "round");
    p.setAttribute("stroke-linecap", "round");
    svg.append(p);
    return svg;
  }
  root.TimoneiroIcons = { icon };
})(globalThis);
