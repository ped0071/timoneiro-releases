// Timoneiro — catálogo dos comandos de chat do Twish e montagem dos comandos com escolha.
// `cmd` é o texto que vai para o chat (com espaço no fim quando pede um complemento).
// `kind` liga o comando a um seletor: isca, venda, compra, título ou usuário do chat.
(function (root) {
  "use strict";
  const c = (icon, label, cmd, hint, kind) => ({ id: cmd, icon, label, cmd, hint, ...(kind ? { kind } : {}) });
  // Atalho para uma página do barco no site (abre em outra aba; não escreve no chat).
  const link = (icon, label, page, hint) => ({ id: `link:${page}`, icon, label, cmd: "", url: page, hint });

  const GROUPS = [
    { id: "jogador", icon: "👤", label: "Jogador", commands: [
      c("💰", "Saldo", "$coins", "Quantas twishcoins você tem"),
      c("✨", "Pontos", "$points", "Seus pontos (também vale $pts)"),
      c("⭐", "Nível", "$nivel", "Nível, XP e quanto falta para o próximo"),
      c("📅", "Hoje", "$hoje", "O que você pescou hoje"),
      c("💎", "Apoio", "$apoio", "Como estão seus selos de apoio"),
      c("🏷", "Título", "$titulo ", "Escolha um dos seus títulos", "title"),
    ] },
    { id: "pesca", icon: "🎣", label: "Pesca", commands: [
      c("🎣", "Pescar", "$pescar", "Lança a linha"),
      c("🐟", "Destaque", "$destaque", "O peixe em destaque neste barco"),
      c("🪱", "Isca", "$isca ", "Equipa uma isca que você tem", "bait"),
      c("↩", "Tirar isca", "$desequiparisca", "Guarda a isca equipada"),
      c("🪝", "Tirar anzol", "$desequiparanzol", "Guarda o anzol equipado"),
      c("⚙", "Venda automática: ligar", "$autovenda on", "Vende sozinho o que você pescar"),
      c("⚙", "Venda automática: desligar", "$autovenda off", "Para de vender sozinho"),
    ] },
    { id: "duelos", icon: "⚔", label: "Duelos", commands: [
      c("⚔", "Desafiar", "$duelar ", "Escolha alguém do chat para um duelo", "user"),
      c("✓", "Aceitar", "$aceitar", "Aceita o duelo que te fizeram"),
      c("✕", "Recusar", "$recusar", "Recusa o duelo"),
      c("🚫", "Cancelar", "$cancelarduelo", "Desiste do duelo que você pediu"),
      c("⌛", "Espera", "$cooldown", "Quanto falta para duelar de novo"),
    ] },
    { id: "eventos", icon: "🎪", label: "Eventos", commands: [
      c("🎪", "Evento agora", "$evento", "Qual evento está rolando no barco"),
      c("🎟️", "Entrar no torneio", "$entrar", "Participa do torneio aberto"),
      c("🏆", "Placar do torneio", "$rankingtorneio", "Quem está na frente no torneio"),
      c("⏱", "Tempo do torneio", "$tempotorneio", "Quanto falta para o torneio acabar"),
      c("⛵", "Embarcar", "$embarcar", "Sobe no Barco Misterioso"),
      c("🍲", "Cozinhar", "$cozinhar ", "Escreva o prato depois do comando"),
      c("💰", "Pagar", "$pagar ", "Escreva quem e quanto depois do comando"),
      c("🔱", "Tridente", "$tridente", "Situação do seu tridente"),
    ] },
    { id: "rankings", icon: "🏆", label: "Rankings", commands: [
      c("🏆", "Ranking", "$ranking", "Os melhores do barco"),
      c("⬆", "Ascensão", "$rankingascensao", "Ranking de ascensão"),
      c("✨", "Por pontos", "$rankingpts", "Ranking de pontos"),
      c("💰", "Por coins", "$rankingcoins", "Ranking de twishcoins"),
      c("📍", "Minha posição", "$meurank", "Onde você está no ranking"),
    ] },
    { id: "loja", icon: "🎒", label: "Loja", commands: [
      c("🛒", "Comprar", "$comprar ", "Escolha um item da loja", "buy"),
      c("💵", "Vender", "$vender ", "Escolha um peixe e a quantidade", "sell"),
      c("💰", "Vender tudo", "$vender todos", "Vende todos os peixes do inventário"),
      link("🎒", "Inventário no site", "inventory", "Abre o seu inventário no Twish"),
      link("🏪", "Loja no site", "shop", "Abre a loja do barco no Twish"),
      link("🏛", "Mercado no site", "market", "Abre o mercado do barco no Twish"),
    ] },
    { id: "ajuda", icon: "?", label: "Ajuda", commands: [
      c("?", "Tutorial", "$tutorial", "Explica o jogo no chat"),
      link("📖", "Comandos no site", "commands", "Lista completa de comandos no Twish"),
    ] },
  ];

  const ALL = GROUPS.flatMap((g) => g.commands.map((x) => ({ ...x, group: g.id })));
  const plain = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

  const find = (id) => ALL.find((x) => x.id === id) || null;
  function search(text) {
    const q = plain(text).trim();
    if (!q) return [];
    return ALL.filter((x) => plain(`${x.label} ${x.cmd} ${x.hint}`).includes(q));
  }

  // Comando final de um seletor. Quantidade inteira, no mínimo 1.
  function build(kind, id, qty = 1) {
    if (kind === "title") return `$titulo ${id}`;
    const verb = { bait: "$isca", sell: "$vender", buy: "$comprar" }[kind];
    if (!verb) return "";
    return `${verb} ${id} ${Math.max(1, Math.floor(Number(qty) || 1))}`;
  }

  // ---------- opções dos seletores, a partir dos dados da conta ----------
  const byName = (a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id));

  // Iscas que você tem (com o nome da loja quando houver).
  function baitOptions(me, shop) {
    const info = new Map(((shop && shop.baits) || []).map((x) => [x.id, x]));
    const have = (me && me.owned && me.owned.baits) || {};
    const equipped = me && me.equipment && me.equipment.bait_id;
    return Object.keys(have).filter((id) => have[id] > 0)
      .map((id) => ({ ...info.get(id), id, name: (info.get(id) || {}).name || id, owned: have[id], equipped: equipped === id }))
      .sort(byName);
  }

  // Peixes do inventário, com o valor somado das unidades.
  function sellOptions(inv) {
    return ((inv && inv.fish) || []).filter((f) => f.count > 0)
      .map((f) => ({ ...f, id: f.fish_id || f.id, totalValue: (f.instances || []).reduce((sum, u) => sum + (Number(u.price) || 0), 0) }))
      .sort(byName);
  }

  // Títulos que você tem, de todas as listas do Twish.
  const TITLE_LISTS = ["shop_titles", "titles", "rank_titles", "pix_titles", "earned_titles"];
  function titleOptions(me, titles) {
    const mine = new Set((me && me.owned && me.owned.title_ids) || []);
    const equipped = me && me.equipment && me.equipment.title_id;
    return TITLE_LISTS.flatMap((k) => (titles && titles[k]) || []).filter((t) => mine.has(t.id))
      .map((t) => ({ ...t, name: t.male_display_name || t.female_display_name || t.id, equipped: equipped === t.id }))
      .sort(byName);
  }

  // Itens da loja (todas as categorias) com preço válido.
  function shopOptions(shop) {
    return Object.entries(shop || {}).filter(([, list]) => Array.isArray(list))
      .flatMap(([category, list]) => list.map((x) => ({ ...x, category })))
      .filter((x) => x.id && x.name && Number.isFinite(Number(x.discounted_cost ?? x.cost)))
      .sort(byName);
  }

  const api = { GROUPS, ALL, find, search, build, baitOptions, sellOptions, titleOptions, shopOptions };
  root.TimoneiroCommands = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
