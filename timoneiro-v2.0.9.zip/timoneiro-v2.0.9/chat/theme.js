// Timoneiro — tema da barra e do menu: "auto" (segue o claro/escuro da Twitch), "skills" ou "claro".
(function (root) {
  "use strict";
  if (root.TimoneiroTheme) return;
  const Store = root.TimoneiroStore;
  const KEY = "timoneiro.theme.v1";
  const CHOICES = [["auto", "Automático (igual à Twitch)"], ["skills", "Skills (escuro)"], ["claro", "Claro"]];

  const twitchIsLight = () => {
    const h = document.documentElement.classList;
    return h.contains("tw-root--theme-light") && !h.contains("tw-root--theme-dark");
  };
  const choice = () => { const v = Store?.get(KEY, "auto"); return CHOICES.some(([c]) => c === v) ? v : "auto"; };
  const resolved = () => (choice() === "auto" ? (twitchIsLight() ? "claro" : "skills") : choice());

  function apply() {
    const t = resolved();
    for (const id of ["tmn-root", "tmn-panel"]) { const el = document.getElementById(id); if (el && el.dataset.tmnTheme !== t) el.dataset.tmnTheme = t; }
    const panel = document.getElementById("tmn-panel");
    if (panel && !panel.style.getPropertyValue("--tmn-bg-img")) {
      try { panel.style.setProperty("--tmn-bg-img", `url("${chrome.runtime.getURL("assets/timoneiro-background.png")}")`); } catch (_) {}
    }
  }

  new MutationObserver(apply).observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  Store?.watch(KEY, apply);

  root.TimoneiroTheme = { CHOICES, get: choice, resolved, apply, set: (v) => Store?.set(KEY, v).then(apply) };
})(globalThis);
