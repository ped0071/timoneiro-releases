// Timoneiro — documento invisível que toca os avisos sonoros quando nenhuma aba da Twitch está visível.
// O service worker não tem áudio; o Chrome fecha este documento sozinho depois que o som acaba.
"use strict";
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  // Só o service worker do Timoneiro pede som: nada vindo de aba (sender.tab) ou de outra extensão.
  if (_sender?.id !== chrome.runtime.id || _sender?.tab) return false;
  if (msg?.type !== "timoneiro-play" || !/^sounds\/[a-z-]+\.wav$/.test(msg.asset || "")) return false;
  try {
    const audio = new Audio(chrome.runtime.getURL(`assets/${msg.asset}`));
    audio.volume = Math.max(0.1, Math.min(1, Number(msg.volume) || 0.7));
    audio.play().then(() => reply(true), () => reply(false));
  } catch (_) { reply(false); }
  return true;
});
