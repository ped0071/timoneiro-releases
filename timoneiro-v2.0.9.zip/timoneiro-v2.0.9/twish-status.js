// Timoneiro — leitura na aba do Twish. Só a aba líder (tab-leader.js) lê e publica.
// Publica no chrome.storage: pesca (cooldown com a hora em que libera), evento ativo, histórico
// do dia e os dados da conta para o Guia e os seletores. Só GET, com a sessão do próprio site.
(() => {
  "use strict";
  const St = globalThis.TimoneiroStatus;
  const Boat = globalThis.TimoneiroBoat;
  const Leader = globalThis.TimoneiroLeader;
  if (!St || !Boat || !Leader || !chrome?.storage?.local) return;

  const KEY = {
    fishing: "timoneiro.fishingStatus.v1",
    event: "timoneiro.eventStatus.v1",
    smart: "timoneiro.smartData.v1",
    history: "timoneiro.eventHistory.v1",
    sync: "timoneiro.syncStatus.v1",
    syncReq: "timoneiro.syncRequest.v1",
  };
  const REPUBLISH_MS = 10e3;        // reescreve o mesmo estado só a cada 10 s (validade de 30 s)
  const leading = () => Leader.isLeader();
  const save = (obj) => chrome.storage.local.set(obj).catch(() => {});

  async function getJson(path, timeout) {
    const base = Boat.apiBase();
    if (!base) throw Object.assign(new Error("sem barco"), { status: 0 });
    const r = await fetch(base + path, { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(timeout) });
    if (!r.ok) throw Object.assign(new Error(`${path} ${r.status}`), { status: r.status });
    return r.json();
  }

  // Procura o cooldown na resposta de /me (o campo mudou de nome algumas vezes no Twish).
  function cooldownIn(data, depth = 0) {
    if (!data || typeof data !== "object" || depth > 3) return null;
    for (const k of ["cooldown_remaining", "cooldown_seconds", "fishing_cooldown_remaining", "cast_cooldown_remaining"]) {
      if (Number.isFinite(data[k])) return { cooldown_remaining: data[k] };
    }
    for (const k of ["next_cast_at", "cooldown_until", "can_fish_at"]) {
      const v = data[k];
      const at = typeof v === "number" ? (v > 1e12 ? v : v * 1000) : typeof v === "string" ? Date.parse(v) : NaN;
      if (Number.isFinite(at)) return { cooldown_remaining: Math.max(0, (at - Date.now()) / 1000) };
    }
    for (const v of Object.values(data)) {
      if (v && typeof v === "object" && !Array.isArray(v)) { const hit = cooldownIn(v, depth + 1); if (hit) return hit; }
    }
    return null;
  }

  // ---------- pesca ----------
  // Fonte principal: /me. O título da aba ("(4:59) ...") percebe na hora quando você pescou:
  // se ele muda de estado, relê /me. O título só manda quando /me está velho ou desatualizado.
  const fish = { api: null, apiAt: 0, busy: false, titleState: null, titleAt: 0, refetchAt: 0, readyAt: null, sig: "", publishedAt: 0 };

  async function readFishing() {
    if (!leading() || fish.busy) return;
    fish.busy = true;
    const at = Date.now();
    try {
      const hit = cooldownIn(await getJson("/me", 8000));
      if (hit) { fish.api = hit; fish.apiAt = at; pushFishing(); }
    } catch (_) { /* tenta de novo no próximo ciclo */ } finally { fish.busy = false; }
  }

  function pushFishing(force = false) {
    if (!leading()) return;
    const now = Date.now();
    const title = St.fishingFromTitle(document.title, now);
    const api = St.fishingFromApi(fish.api, fish.apiAt, now);
    const apiRecent = !!api && now - fish.apiAt < 60e3;

    if (title.status !== fish.titleState) {
      if (fish.titleState !== null && now - fish.refetchAt > 4000) { fish.refetchAt = now; setTimeout(readFishing, 300); }
      fish.titleState = title.status; fish.titleAt = now;
    }

    let pick = apiRecent ? { ...api, via: "api" } : title.status !== "unknown" ? { ...title, via: "title" } : api ? { ...api, via: "api" } : null;
    if (!pick) return;
    // Você pescou depois da última leitura: /me ainda diz liberado, o título já conta.
    if (apiRecent && api.status === "available" && title.status === "cooldown" && fish.apiAt < fish.titleAt) pick = { ...title, via: "title" };
    if (pick.status === "available") pick.readyAt = api && api.status === "available" ? Math.min(api.readyAt, now) : now;
    // O título só tem segundos inteiros: segura a hora de liberar estável.
    if (pick.status === "cooldown" && fish.readyAt && Math.abs(pick.readyAt - fish.readyAt) < 2500) pick.readyAt = fish.readyAt;

    const sig = pick.status + "|" + (pick.status === "cooldown" ? Math.round(pick.readyAt / 1000) : "");
    if (sig === fish.sig && !(force && now - fish.publishedAt >= REPUBLISH_MS)) return;
    fish.sig = sig; fish.publishedAt = now;
    fish.readyAt = pick.status === "cooldown" ? pick.readyAt : null;
    save({ [KEY.fishing]: { status: pick.status, cooldown: pick.cooldown || null, readyAt: pick.readyAt, via: pick.via, source: "twish", boat: Boat.get(), updatedAt: now } });
  }

  // ---------- evento ----------
  const ev = { data: null, at: 0, busy: false, last: null, lastAt: 0, emptyReads: 0, emptyReadAt: 0, endsAt: null, sig: "", publishedAt: 0 };

  async function readEvents() {
    if (!leading() || ev.busy) return;
    ev.busy = true;
    const at = Date.now();
    try {
      const data = await getJson("/events/active", 10000);
      if (St.eventFromApi(data, at) === null) return;
      const seen = [["regular", data.event], ["grand", data.grande_evento]]
        .filter(([, e]) => e)
        .map(([kind, e]) => ({ name: e.name, endsAt: at + e.seconds_remaining * 1000, kind }));
      const saved = (await chrome.storage.local.get(KEY.history))[KEY.history];
      await save({ [KEY.history]: St.historyUpdate(saved, seen, at) });
      ev.data = data; ev.at = at;
      pushEvent(true);
    } catch (_) { /* sem leitura nova: o último estado continua até vencer */ } finally { ev.busy = false; }
  }

  function pushEvent(force = false) {
    if (!leading() || !ev.at) return;
    const now = Date.now();
    let cur = St.eventFromApi(ev.data, ev.at, now);
    const stillRunning = ev.last && ev.last.active && Number.isFinite(ev.last.endsAt) && ev.last.endsAt > now + 5000;
    if (cur && !cur.active && stillRunning) {
      // "Sem evento" no meio de um evento que não venceu: só acredita na 2ª leitura seguida.
      if (ev.emptyReadAt !== ev.at) { ev.emptyReads++; ev.emptyReadAt = ev.at; }
      if (ev.emptyReads < 2) cur = ev.last;
    } else if (cur && cur.active) ev.emptyReads = 0;

    if (cur) { ev.last = cur; ev.lastAt = now; }
    else if (ev.last && now - ev.lastAt < 60e3) cur = ev.last.active && Number.isFinite(ev.last.endsAt) && ev.last.endsAt <= now ? { active: false } : ev.last;
    else return; // leitura falhou há pouco: não publica um "sem evento" falso

    // A API manda segundos inteiros: o fim "balança" ~1 s entre leituras; até 3 s é o mesmo fim.
    if (Number.isFinite(cur.endsAt) && Number.isFinite(ev.endsAt) && Math.abs(cur.endsAt - ev.endsAt) < 3000) cur = { ...cur, endsAt: ev.endsAt };
    ev.endsAt = Number.isFinite(cur.endsAt) ? cur.endsAt : null;
    // A contagem regressiva fica fora da assinatura: grava quando muda de verdade.
    const sig = cur.active ? [cur.name, cur.description, ev.endsAt ?? cur.remaining, cur.kind, cur.apiKind, cur.progressCount, cur.progressTarget].join("|") : "off";
    if (sig === ev.sig && !(force && now - ev.publishedAt >= REPUBLISH_MS)) return;
    ev.sig = sig; ev.publishedAt = now;
    save({ [KEY.event]: { ...cur, boat: Boat.get(), updatedAt: now } });
  }

  // ---------- dados da conta (Guia e seletores) ----------
  const acct = { busy: false, pausedUntil: 0 };
  async function readAccount() {
    if (acct.busy || Date.now() < acct.pausedUntil || !leading()) return;
    acct.busy = true;
    const boat = Boat.get();
    try {
      const parts = { me: "/me", inventory: "/me/inventory", shop: "/shop", titles: "/titles" };
      const got = await Promise.all(Object.entries(parts).map(async ([k, p]) => [k, await getJson(p, 10000)]));
      if (Boat.get() !== boat) return; // trocou de barco no meio
      const now = Date.now();
      await save({ [KEY.smart]: { boat, data: Object.fromEntries(got), fetchedAt: Object.fromEntries(got.map(([k]) => [k, now])), updatedAt: now } });
      await save({ [KEY.sync]: { state: "ok", boat, at: Date.now() } });
    } catch (e) {
      const s = e && e.status;
      if (s === 429) acct.pausedUntil = Date.now() + 120e3;
      const state = s === 401 || s === 403 ? "login" : s === 404 ? "boat" : s === 429 ? "rate" : "error";
      await save({ [KEY.sync]: { state, boat, status: s || null, at: Date.now() } });
    } finally { acct.busy = false; }
  }

  const readAll = () => { readAccount(); readEvents(); readFishing(); };

  // Tempo real (twish-realtime.js): o servidor avisa e a aba relê ou publica na hora.
  globalThis.TimoneiroTwish = {
    refetchFishing: readFishing,
    refetchEvents: readEvents,
    refetchAccount: readAccount,
    setCooldown(remaining, at = Date.now()) {
      if (!leading() || !Number.isFinite(remaining)) return;
      fish.api = { cooldown_remaining: Math.max(0, remaining) }; fish.apiAt = at; fish.sig = "";
      pushFishing(true);
    },
  };

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY.syncReq]) { readAccount(); readEvents(); }
  });
  Boat.onChange(() => {
    chrome.storage.local.remove([KEY.smart, KEY.event]).catch(() => {});
    ev.data = null; ev.at = 0;
    readAccount(); readEvents();
  });
  Leader.onChange((on) => { if (on) readAll(); });

  Boat.ready.then(() => Boat.adoptFromUrl(location.pathname)).then(() => Leader.ready).then(() => {
    pushFishing(true); pushEvent(true);
    readAll();
  });

  const titleEl = document.querySelector("title");
  if (titleEl) new MutationObserver(() => pushFishing()).observe(titleEl, { childList: true, characterData: true, subtree: true });

  setInterval(() => { pushFishing(true); pushEvent(true); }, 1000);
  setInterval(readAccount, 30e3);
  setInterval(readEvents, 15e3);
  setInterval(readFishing, 20e3);
  addEventListener("pagehide", () => { if (leading()) chrome.storage.local.remove([KEY.fishing, KEY.event]).catch(() => {}); }, { once: true });
})();
