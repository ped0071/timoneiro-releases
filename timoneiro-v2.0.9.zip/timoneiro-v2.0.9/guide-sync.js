// Timoneiro — leitor extra do Guia, na aba do twish.com.br.
// Só leituras (GET), com intervalos longos para não sobrecarregar o Twish (que responde 429 a rajadas).
(() => {
  "use strict";
  if (window.__pescaSkillsGuideSync) return;
  window.__pescaSkillsGuideSync = true;
  const boat = globalThis.TimoneiroBoat;
  if (!boat || !chrome?.storage?.local) return;

  const KEYS = {
    data: "timoneiro.guideData.v1",
    handle: "timoneiro.handle.v1",
    smart: "timoneiro.smartData.v1",
    compareReq: "timoneiro.compareRequest.v1",
    compareRes: "timoneiro.compareResult.v1",
    benchReq: "timoneiro.boatBenchRequest.v1",
    benchRes: "timoneiro.boatBench.v1",
    syncReq: "timoneiro.syncRequest.v1",
  };
  // [chave, caminho, intervalo em ms, por barco?]
  const JOBS = [
    ["manual", () => "/api/manual", 60 * 60e3],
    ["bestiary", (b) => `/api/${b}/bestiary`, 60 * 60e3],
    ["profile", (b, h) => (h ? `/api/${b}/players/${encodeURIComponent(h)}` : null), 2 * 60e3],
    ["missions", (b) => `/api/${b}/me/missions`, 3 * 60e3],
    ["expeditions", (b) => `/api/${b}/expeditions`, 90e3],
    ["tournament", (b) => `/api/${b}/tournament`, 30e3],
    ["portOrders", (b) => `/api/${b}/me/port-orders`, 10 * 60e3],
  ];
  let pausedUntil = 0;
  let running = false;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function get(path) {
    const r = await fetch(path, { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(10000) });
    if (r.status === 429) { pausedUntil = Date.now() + 120000; throw Object.assign(new Error("429"), { status: 429 }); }
    if (!r.ok) throw Object.assign(new Error(String(r.status)), { status: r.status });
    return r.json();
  }

  async function handle() {
    const s = await chrome.storage.local.get([KEYS.handle, KEYS.smart]);
    const me = s[KEYS.smart]?.data?.me || {};
    const fromMe = me.handle || me.login || me.username || me.twitch_login || null;
    return (s[KEYS.handle] || fromMe || "").toLowerCase() || null;
  }

  const isLeader = () => !!globalThis.TimoneiroLeader?.isLeader();
  async function tick(force = false) {
    if (running || Date.now() < pausedUntil || !isLeader()) return;
    running = true;
    try {
      const b = boat.get();
      const h = await handle();
      const saved = (await chrome.storage.local.get(KEYS.data))[KEYS.data];
      const pack = saved?.boat === b ? saved : { boat: b, data: {}, fetchedAt: {}, errors: {} };
      for (const [key, path, every] of JOBS) {
        const p = path(b, h);
        if (!p) continue;
        if (!force && Date.now() - (pack.fetchedAt[key] || 0) < every) continue;
        try { pack.data[key] = await get(p); pack.fetchedAt[key] = Date.now(); delete pack.errors[key]; }
        catch (e) { pack.errors[key] = e.status || "erro"; pack.fetchedAt[key] = Date.now(); if (e.status === 429) break; }
        await sleep(700);
      }
      if (Date.now() >= pausedUntil) {
        if (force || Date.now() - (pack.fetchedAt.marketStats || 0) >= 6 * 3600e3) {
          try { const m = await marketStats(b, pack.data.bestiary); if (m) pack.data.marketStats = m; } catch (_) {}
          pack.fetchedAt.marketStats = Date.now();
        }
        if (force || Date.now() - (pack.fetchedAt.marketBySpecies || 0) >= 45 * 60e3) {
          try { const m = await marketBySpecies(b, pack.data.marketBySpecies); if (m) pack.data.marketBySpecies = m; } catch (_) {}
          pack.fetchedAt.marketBySpecies = Date.now();
        }
        if (force || Date.now() - (pack.fetchedAt.patchNotes || 0) >= 6 * 3600e3) {
          try { const n = await patchNotes(); if (n) pack.data.patchNotes = n; } catch (_) {}
          pack.fetchedAt.patchNotes = Date.now();
        }
      }
      pack.handle = h; pack.updatedAt = Date.now();
      pack.data.voyageStats = voyageStats(pack.data.expeditions, pack.data.voyageStats);
      pack.alerts = alertsFrom(b, h, pack.data);
      if (boat.get() === b) await chrome.storage.local.set({ [KEYS.data]: pack });
    } finally { running = false; }
  }

  // Mercado: 5 páginas de vendas recentes → razão preço ÷ valor base por raridade e mediana por espécie.
  async function marketStats(b, bestiary) {
    const pts = {};
    for (const f of bestiary?.fish || []) pts[f.id] = f.points;
    if (!Object.keys(pts).length) return null;
    const sales = [];
    for (let page = 1; page <= 5; page++) {
      const j = await get(`/api/${b}/market/sales?page=${page}`);
      sales.push(...(j.sales || []));
      if (!j.has_more) break;
      await sleep(1500);
    }
    const med = (a) => { const x = [...a].sort((p, q) => p - q); return x.length ? x[Math.floor(x.length / 2)] : null; };
    const byTier = {}, byFish = {};
    for (const v of sales) {
      if (v.item_id || v.ascension_level || !pts[v.fish_id]) continue;
      (byTier[v.tier] = byTier[v.tier] || []).push(v.price / (pts[v.fish_id] * 2));
      (byFish[v.fish_id] = byFish[v.fish_id] || []).push(v.price);
    }
    const times = sales.map((v) => v.sold_at).filter(Number.isFinite);
    const days = times.length > 1 ? (Math.max(...times) - Math.min(...times)) / 86400 : null;
    return {
      at: Date.now(), sample: sales.length, days,
      tiers: Object.fromEntries(Object.entries(byTier).map(([t, r]) => [t, { ratio: +med(r).toFixed(2), n: r.length, perDay: days ? +(r.length / days).toFixed(1) : null }])),
      fish: Object.fromEntries(Object.entries(byFish).filter(([, p]) => p.length >= 3).map(([id, p]) => [id, { median: med(p), n: p.length }])),
    };
  }

  // Preço por espécie: vendas e anúncios da mesma espécie (busca por nome), para os peixes
  // que valem o Mercado (raro+, mandarim, ascendidos). Até 6 espécies por rodada, 1,5 s entre chamadas.
  async function marketBySpecies(b, prev = {}) {
    const smart = (await chrome.storage.local.get(KEYS.smart))[KEYS.smart];
    const fish = smart?.boat === b && Array.isArray(smart?.data?.inventory?.fish) ? smart.data.inventory.fish : [];
    const wanted = new Map();
    for (const f of fish) {
      const tier = f.tier || f.instances?.[0]?.tier;
      const insts = Array.isArray(f.instances) && f.instances.length ? f.instances : [{}];
      for (const i of insts) {
        const asc = Number(i.ascension_level ?? f.ascension_level ?? 0) || 0;
        if (["legendary", "mythic", "secret", "divine"].includes(tier) || f.fish_id === "peixe_mandarim" || asc > 0 || tier === "rare")
          if (!wanted.has(`${f.fish_id}|${asc}`) || (!wanted.get(`${f.fish_id}|${asc}`).capture && i.capture_id && !i.escrowed)) wanted.set(`${f.fish_id}|${asc}`, { id: f.fish_id, name: f.name || f.fish_name || f.fish_id, asc, tier, capture: i.escrowed ? null : i.capture_id || null });
      }
    }
    const order = [...wanted.values()].sort((x, y) => ["divine", "secret", "mythic", "legendary", "rare", "uncommon", "common"].indexOf(x.tier) - ["divine", "secret", "mythic", "legendary", "rare", "uncommon", "common"].indexOf(y.tier)).slice(0, 6);
    const out = {};
    for (const w of order) {
      const key = `${w.id}|${w.asc}`;
      if (prev[key] && Date.now() - prev[key].at < 45 * 60e3) { out[key] = prev[key]; continue; }
      try {
        const sales = await get(`/api/${b}/market/sales?q=${encodeURIComponent(w.name)}`);
        await sleep(1500);
        const lists = await get(`/api/${b}/market/listings?q=${encodeURIComponent(w.name)}&page_size=50`);
        await sleep(1500);
        const same = (x) => x.fish_id === w.id && (Number(x.ascension_level) || 0) === w.asc && !x.item_id;
        // Preço sugerido do próprio site (vendas reais de 7 dias, uma por dupla comprador/vendedor).
        let suggested = null;
        if (w.capture) {
          try { const sp = await get(`/api/${b}/market/suggested-price?capture_id=${encodeURIComponent(w.capture)}`); suggested = { price: sp.suggested_price, base: sp.base_price, floor: sp.floor, ceiling: sp.ceiling, sample: sp.sample_size, fallback: !!sp.is_fallback }; } catch (e) { if (e.status === 429) throw e; }
          await sleep(1500);
        }
        out[key] = { at: Date.now(), suggested, sales: (sales.sales || []).filter(same).map((x) => x.price), asks: (lists.listings || []).filter(same).map((x) => ({ ask: x.asking_price, base: x.base_price, seller: x.seller })) };
      } catch (e) { if (e.status === 429) break; }
    }
    return { ...prev, ...out };
  }

  // Resultado real de outros jogadores: o cais mostra as viagens recentes com o valor pescado por
  // tripulante. Guardamos as que já terminaram (uma vez cada) e somamos por mar e tipo.
  function voyageStats(h, prev) {
    const st = prev && prev.v === 1 ? prev : { v: 1, seen: [], seas: {} };
    for (const v of Array.isArray(h?.voyages) ? h.voyages : []) {
      const done = v.state === "finished" || v.state === "closed" || v.seconds_to_end === 0 || (Number.isFinite(v.ends_at) && v.ends_at * 1000 < Date.now());
      if (!done || !v.id || st.seen.includes(v.id) || !Array.isArray(v.crew) || !v.crew.length) continue;
      st.seen.push(v.id);
      const k = `${v.sea}|${v.kind === "fleet" ? "fleet" : "voyage"}`;
      const s = (st.seas[k] = st.seas[k] || { trips: 0, people: 0, value: 0, catches: 0, refunded: 0, fragments: 0 });
      s.trips++;
      for (const c of v.crew) { s.people++; s.value += Number(c.value) || 0; s.catches += Number(c.catches) || 0; s.refunded += Number(c.refunded) || 0; s.fragments += Number(c.fragments) || 0; }
    }
    st.seen = st.seen.slice(-300);
    return st;
  }

  // Alertas para o service worker (cada um notifica uma vez só).
  function alertsFrom(b, h, d) {
    const out = [];
    const t = d.tournament;
    if (t?.active && t.join_window_open && !t.is_participant) out.push({ type: "tournament", key: `tour|${b}|${t.id || t.started_at || Math.round(((t.seconds_remaining || 0) * 1000 + Date.now()) / 300000)}`, title: "Torneio aberto!", message: "Digite $entrar no chat: entrar zera seu cooldown e você só arrisca o peixe pescado na disputa." });
    const rooms = Array.isArray(d.expeditions?.rooms) ? d.expeditions.rooms : [];
    for (const r of rooms) {
      const owner = (r.crew || []).find((c) => c.owner)?.boat || r.boat;
      if (owner !== b || r.started || (r.state && !/lobby|open|waiting|forming|boarding/.test(r.state))) continue;
      const mine = (r.crew || []).some((c) => h && String(c.handle).toLowerCase() === h);
      if (mine) continue;
      if (r.kind === "fleet") out.push({ type: "fleet", key: `fleet|${b}|${r.id}`, title: "Frota do Capitão aberta!", message: "Viagem grátis à Baía. Digite $embarcar no chat (zarpa em até 10 min)." });
      else out.push({ type: "room", key: `room|${b}|${r.id}`, title: `Sala de expedição aberta (${r.sea || "mar"})`, message: `${(r.crew || []).length} tripulante(s) no barco ${b}. Veja no Guia se compensa.` });
    }
    return out;
  }

  // Patch notes: o site guarda o histórico dentro do próprio bundle (JSON.parse('[{"postedAt"...]')).
  async function patchNotes() {
    const src = [...document.querySelectorAll("script[src]")].map((x) => x.src).find((u) => /\/assets\/index-[^/]+\.js$/.test(u));
    if (!src) return null;
    const t = await fetch(src, { cache: "no-store" }).then((r) => r.text());
    const marker = "JSON.parse('[{\"postedAt\"";
    const i = t.indexOf(marker);
    if (i < 0) return null;
    const start = i + "JSON.parse('".length;
    const end = t.indexOf("')", start);
    const raw = t.slice(start, end).replace(/\\'/g, "'").replace(/\\\\/g, "\\");
    const notes = JSON.parse(raw);
    return { at: Date.now(), notes: notes.slice(0, 12).map((n) => ({ postedAt: n.postedAt, version: n.version, tagline: n.tagline || "", sections: (n.sections || []).map((x) => ({ title: x.title, items: (x.items || []).slice(0, 12) })) })) };
  }

  // Comparar com outro jogador (perfil público).
  async function compare(req) {
    if (!req?.handle) return;
    const b = boat.slug(req.boat) || boat.get();
    const h = boat.slug(req.handle);
    let result;
    try { result = { ok: true, boat: b, handle: h, profile: await get(`/api/${b}/players/${encodeURIComponent(h)}`), at: Date.now() }; }
    catch (e) { result = { ok: false, boat: b, handle: h, error: e.status === 404 ? "Jogador não encontrado nesse barco." : e.status === 429 ? "O Twish pediu para ir mais devagar. Tente em 2 minutos." : `Erro ${e.status || ""}`.trim(), at: Date.now() }; }
    await chrome.storage.local.set({ [KEYS.compareRes]: result });
  }

  // Top 10 do barco (pontos): um perfil a cada 2,5 s, guardado por 6 h.
  async function boatBench(req) {
    const b = boat.slug(req?.boat) || boat.get();
    const prev = (await chrome.storage.local.get(KEYS.benchRes))[KEYS.benchRes];
    if (!req?.force && prev?.boat === b && Date.now() - prev.at < 6 * 3600e3 && prev.players?.length) return;
    await chrome.storage.local.set({ [KEYS.benchRes]: { boat: b, at: Date.now(), loading: true, players: prev?.boat === b ? prev.players : [] } });
    const players = [];
    try {
      const rank = await get(`/api/${b}/ranking?board=points`);
      for (const e of (rank.entries || []).slice(0, 10)) {
        await sleep(2500);
        try { players.push(await get(`/api/${b}/players/${encodeURIComponent(e.username)}`)); }
        catch (err) { if (err.status === 429) { await sleep(30000); } }
        await chrome.storage.local.set({ [KEYS.benchRes]: { boat: b, at: Date.now(), loading: true, players } });
      }
      await chrome.storage.local.set({ [KEYS.benchRes]: { boat: b, at: Date.now(), loading: false, players } });
    } catch (e) {
      await chrome.storage.local.set({ [KEYS.benchRes]: { boat: b, at: Date.now(), loading: false, players, error: `Erro ${e.status || ""}`.trim() } });
    }
  }

  // Tempo real: relê só um item (ex.: torneio mudou) e recalcula os alertas na hora.
  async function refreshJob(name) {
    if (!isLeader() || Date.now() < pausedUntil) return;
    const job = JOBS.find(([k]) => k === name);
    if (!job) return;
    const b = boat.get();
    const h = await handle();
    const p = job[1](b, h);
    if (!p) return;
    try {
      const data = await get(p);
      const saved = (await chrome.storage.local.get(KEYS.data))[KEYS.data];
      const pack = saved?.boat === b ? saved : { boat: b, data: {}, fetchedAt: {}, errors: {} };
      pack.data[name] = data; pack.fetchedAt[name] = Date.now(); delete pack.errors?.[name];
      if (name === "expeditions") pack.data.voyageStats = voyageStats(data, pack.data.voyageStats);
      pack.alerts = alertsFrom(b, h, pack.data); pack.updatedAt = Date.now();
      if (boat.get() === b) await chrome.storage.local.set({ [KEYS.data]: pack });
    } catch (_) {}
  }
  globalThis.TimoneiroGuideSync = { refreshJob, tick };

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[KEYS.syncReq] || changes[KEYS.handle]) tick(true);
    if (changes[KEYS.compareReq]?.newValue && isLeader()) compare(changes[KEYS.compareReq].newValue);
    if (changes[KEYS.benchReq]?.newValue && isLeader()) boatBench(changes[KEYS.benchReq].newValue);
  });
  boat.onChange(() => tick(true));

  boat.ready.then(() => setTimeout(() => tick(), 4000));
  setInterval(() => tick(), 30000);
})();
