// Timoneiro — guarda dos scripts da página. Quando a extensão é atualizada ou recarregada, os scripts
// antigos continuam vivos nas abas da Twitch e do Twish, mas sem acesso ao chrome.* ("Extension context
// invalidated" a cada temporizador). Este guarda, carregado antes de todos, percebe isso em até 1 s e
// desliga a cópia antiga: para temporizadores, observadores e conexões, tira a barra velha da página e
// silencia esses erros. A versão nova entra sozinha (o fundo injeta os scripts de novo nas abas abertas).
(function (root) {
  "use strict";
  if (root.TimoneiroAlive) return;

  const native = {
    setInterval: root.setInterval.bind(root), clearInterval: root.clearInterval.bind(root),
    setTimeout: root.setTimeout.bind(root), clearTimeout: root.clearTimeout.bind(root),
  };
  const intervals = new Set(), timeouts = new Set(), observers = new Set(), stops = [];
  let dead = false;

  function ok() {
    try { return !!(root.chrome && chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }
  const INVALID = /Extension context invalidated/i;
  const isInvalid = (e) => INVALID.test(String((e && e.message) || e || ""));

  // Os scripts do Timoneiro rodam num mundo isolado: trocar estas funções aqui não muda nada na página.
  root.setInterval = function (fn, ms, ...args) {
    if (dead) return 0;
    const id = native.setInterval(fn, ms, ...args);
    intervals.add(id);
    return id;
  };
  root.clearInterval = function (id) { intervals.delete(id); native.clearInterval(id); };
  root.setTimeout = function (fn, ms, ...args) {
    if (dead) return 0;
    const id = native.setTimeout((...a) => { timeouts.delete(id); if (typeof fn === "function") fn(...a); }, ms, ...args);
    timeouts.add(id);
    return id;
  };
  root.clearTimeout = function (id) { timeouts.delete(id); native.clearTimeout(id); };
  if (typeof root.MutationObserver === "function") {
    const NativeMO = root.MutationObserver;
    root.MutationObserver = class extends NativeMO {
      constructor(cb) { super(cb); observers.add(this); }
    };
  }

  // Tudo o que o Timoneiro põe na página tem id "tmn-…". A página é a mesma para a cópia velha e a nova,
  // então cada cópia marca a sua geração: a velha só limpa se nenhuma mais nova tiver assumido.
  const gen = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const mine = () => { try { return document.documentElement.dataset.tmnGen === gen; } catch (_) { return false; } };
  function removeDom() {
    try { for (const el of document.querySelectorAll('[id^="tmn-"]')) el.remove(); } catch (_) {}
  }

  function stop() {
    if (dead) return;
    dead = true;
    native.clearInterval(guard);
    for (const id of intervals) native.clearInterval(id);
    for (const id of timeouts) native.clearTimeout(id);
    intervals.clear(); timeouts.clear();
    for (const o of observers) { try { o.disconnect(); } catch (_) {} }
    for (const fn of stops.splice(0)) { try { fn(); } catch (_) {} }
    if (mine()) removeDom();
  }

  // Uma cópia nova começa limpando o que a antiga deixou na página e assume a geração.
  removeDom();
  try { document.documentElement.dataset.tmnGen = gen; } catch (_) {}

  const guard = native.setInterval(() => { if (!ok()) stop(); }, 1000);
  root.addEventListener("error", (ev) => {
    if (isInvalid(ev.error || ev.message)) { ev.preventDefault(); stop(); }
  }, true);
  root.addEventListener("unhandledrejection", (ev) => {
    if (isInvalid(ev.reason)) { ev.preventDefault(); stop(); }
  });

  root.TimoneiroAlive = {
    ok: () => !dead && ok(),
    get dead() { return dead; },
    onStop(fn) { if (dead) { try { fn(); } catch (_) {} } else stops.push(fn); },
    stop,
  };
})(globalThis);
