// Catálogo de reserva, extraído de https://twish.com.br/api/manual em 05/11/2026.
// A extensão busca o manual ao vivo na aba do Twish e só usa este arquivo se não conseguir.
(function (root) {
  "use strict";
  const rod = (id, name, cost, mult, req) => ({ id, name, cost, discounted_cost: cost, cooldown_multiplier: mult, requires_rod_id: req });
  root.TimoneiroCatalog = {
    snapshotDate: "2026-11-05",
    shop: {
      rods: [
        rod("vara_bambu", "Vara de Bambu", 0, 1, null),
        rod("vara_madeira", "Vara de Madeira Reforçada", 300, 0.9, "vara_bambu"),
        rod("vara_fibra", "Vara de Fibra de Vidro", 800, 0.8, "vara_madeira"),
        rod("vara_aco", "Vara de Aço", 1600, 0.7, "vara_fibra"),
        rod("vara_carbono", "Vara de Carbono", 3000, 0.6, "vara_aco"),
        rod("vara_encantada", "Vara Encantada", 6000, 0.5, "vara_carbono"),
        rod("vara_abissal", "Vara Abissal", 7000, 0.4, "vara_encantada"),
        rod("vara_lendaria", "Vara Lendária", 16000, 0.3, "vara_abissal"),
        rod("vara_njord", "Vara Njord", 32000, 0.2, "vara_lendaria"),
      ],
      hooks: [
        { id: "anzol_duplo", name: "Anzol Duplo", cost: 50000, discounted_cost: 50000, num_fish: 2, requires_hook_id: null },
        { id: "anzol_triplo", name: "Anzol Triplo", cost: 80000, discounted_cost: 80000, num_fish: 3, requires_hook_id: "anzol_duplo" },
      ],
      backpacks: [
        { id: "mochila_couro", name: "Mochila de Couro", cost: 400, extra_fish_total: 50, extra_fish_per_species: 5, requires_backpack_id: null },
        { id: "mochila_encerada", name: "Mochila Encerada", cost: 1000, extra_fish_total: 100, extra_fish_per_species: 10, requires_backpack_id: "mochila_couro" },
        { id: "mochila_navegador", name: "Mochila do Navegador", cost: 2200, extra_fish_total: 150, extra_fish_per_species: 15, requires_backpack_id: "mochila_encerada" },
        { id: "mochila_abissal", name: "Mochila Abissal", cost: 4500, extra_fish_total: 200, extra_fish_per_species: 20, requires_backpack_id: "mochila_navegador" },
        { id: "mochila_leviata", name: "Mochila do Leviatã", cost: 9000, extra_fish_total: 250, extra_fish_per_species: 25, requires_backpack_id: "mochila_abissal" },
      ],
      baits: [
        { id: "isca_turbinada", name: "Isca Turbinada", cost: 15, guarantee_bite: true },
        { id: "isca_de_mar", name: "Isca de Mar", cost: 20, species_group: "saltwater" },
        { id: "isca_de_mariscos", name: "Isca de Mariscos", cost: 20, species_group: "shellfish" },
        { id: "isca_de_rio", name: "Isca de Rio", cost: 20, species_group: "freshwater" },
        { id: "isca_de_fundo", name: "Isca de Fundo", cost: 25, weight_floor: 0.5 },
        { id: "isca_de_chumbo", name: "Isca de Chumbo", cost: 100, weight_floor: 0.6 },
        { id: "isca_milagrosa", name: "Isca Milagrosa", cost: 150, guarantee_bite: true, guarantee_min_tier: "rare" },
      ],
      boosters: [
        { id: "turbo", name: "Turbo de Pesca", cost: 200, duration_seconds: 300, cooldown_seconds: 20 },
        { id: "turbo_torneio", name: "Turbo Torneio", cost: 250, duration_seconds: 180, cooldown_seconds: 10, tournament_only: true },
      ],
      upkeep: [
        { id: "afiacao_anzol", name: "Afiação de Anzol", effect: "points", bonus: 0.05, seconds: 1800,
          prices_by_rod: { vara_bambu: 20, vara_madeira: 25, vara_fibra: 30, vara_aco: 40, vara_carbono: 55, vara_encantada: 75, vara_abissal: 100, vara_lendaria: 140, vara_njord: 200 } },
        { id: "graxa_molinete", name: "Graxa de Molinete", effect: "weight", bonus: 0.05, casts: 20,
          prices_by_rod: { vara_bambu: 20, vara_madeira: 25, vara_fibra: 30, vara_aco: 40, vara_carbono: 55, vara_encantada: 75, vara_abissal: 100, vara_lendaria: 140, vara_njord: 200 } },
      ],
      incubators: [{ id: "incubadora", name: "Incubadora", cost: 300 }],
      fertilizers: [
        { id: "fertilizante_basico", name: "Fertilizante Básico", cost: 80, failure_multiplier: 0.75 },
        { id: "fertilizante_premium", name: "Fertilizante Premium", cost: 200, failure_multiplier: 0.5 },
      ],
    },
    fishing: { cooldown_seconds: 600, no_bite_chance: 0.5, legendary_rod_floor_id: "vara_aco", divine_rod_floor_id: "vara_encantada" },
    levels: { max_level: 150, xp_base: 10, bite_bonus_max: 0.4, tier_boost_max: 0.5, sell_bonus_max: 0.3 },
    inventory: { max_fish_total: 100, max_fish_per_species: 10 },
    featured: { common: 20, uncommon: 50, rare: 100, legendary: 250, mythic: 500, secret: 1250, divine: 2500 },
    seas: [
      { sea: "baia", name: "Baía das Lendas", min_rod: "vara_fibra", ticket: 200, refund: 120, insurance: null, hazard: 0, orders: 50, hazards: [], coinLoss: 0, coinCap: 200,
        shares: { common: 0.516, uncommon: 0.22, rare: 0.211, legendary: 0.053 }, exclusiveTiers: ["rare", "legendary"],
        casts: { vara_fibra: 4, vara_aco: 5, vara_carbono: 5, vara_encantada: 6, vara_abissal: 8, vara_lendaria: 10, vara_njord: 15 },
        exclusive: { vara_fibra: 0.43, vara_aco: 0.51, vara_carbono: 0.51, vara_encantada: 0.57, vara_abissal: 0.68, vara_lendaria: 0.76, vara_njord: 0.88 } },
      { sea: "sereias", name: "Mar das Sereias", min_rod: "vara_encantada", ticket: 600, refund: 360, insurance: 90, hazard: 0.2, orders: 150, hazards: ["coins", "siren"], coinLoss: 0.05, coinCap: 600,
        shares: { common: 0.55, uncommon: 0.234, rare: 0.112, legendary: 0.056, mythic: 0.019, fragment: 0.028 }, exclusiveTiers: ["legendary", "mythic", "fragment"],
        casts: { vara_encantada: 6, vara_abissal: 8, vara_lendaria: 10, vara_njord: 15 },
        exclusive: { vara_encantada: 0.2, vara_abissal: 0.26, vara_lendaria: 0.32, vara_njord: 0.44 } },
      { sea: "abismo", name: "Abismo dos Deuses", min_rod: "vara_abissal", ticket: 1100, refund: 0, insurance: 165, hazard: 0.2, orders: 275, hazards: ["coins", "curse", "lose_fish"], coinLoss: 0.1, coinCap: 1100,
        shares: { common: 0.555, uncommon: 0.237, rare: 0.114, legendary: 0.028, mythic: 0.009, secret: 0.024, divine: 0.005, fragment: 0.028 }, exclusiveTiers: ["secret", "divine", "fragment"],
        casts: { vara_abissal: 8, vara_lendaria: 10, vara_njord: 15 },
        exclusive: { vara_abissal: 0.11, vara_lendaria: 0.13, vara_njord: 0.19 } },
      { sea: "fenda", name: "Fenda do Fim", min_rod: "vara_lendaria", ticket: null, entry: "3 Fragmentos do Fim", refund: 0, insurance: null, hazard: 0.8, orders: 0,
        casts: { vara_lendaria: 10, vara_njord: 15 },
        exclusive: { vara_lendaria: 0.049, vara_njord: 0.072 } },
    ],
    tides: {
      cheia: { label: "Maré Cheia", bite: 1.1, exclusives: 1, hazard: 1 },
      cardume: { label: "Cardume", bite: 1, exclusives: 1.5, hazard: 1 },
      nevoeiro: { label: "Nevoeiro", bite: 1, exclusives: 2, hazard: 1.5 },
      calmaria: { label: "Calmaria", bite: 1, exclusives: 1, hazard: 0.5 },
      baixa: { label: "Maré Baixa", bite: 0.9, exclusives: 1, hazard: 1 },
      turvas: { label: "Águas Turvas", bite: 1, exclusives: 0.5, hazard: 1 },
    },
  };

  // Eventos da hora (manual de 05/11/2026): nome → valor. Usado para detectar evento novo ou valor alterado.
  root.TimoneiroCatalog.events = {
    "Cardume Passageiro": 10, "Coins em Dobro": 2, "Comprador do Porto": 2.5, "Concurso do Menor Peixe": -1,
    "Desconto na Loja": 0.2, "Garrafa ao Mar": 0.35, "Maré Turbo": 0.5, "Peso Pesado": 1, "Rede Coletiva": 0.3,
    "Sorte Rara": 3, "Venda Turbinada": 1.25, "XP em Dobro": 2,
  };
  root.TimoneiroCatalog.grandEvents = ["Invasão Pirata", "Julgamento de Njord", "Barco Misterioso", "O Kraken", "Caldeirada", "Tempestade"];

  // Mercado: 300 vendas (≈41 h) e 600 anúncios coletados em 05/11/2026.
  // ratio = preço de venda ÷ valor base (valor base ≈ pontos da espécie × 2, igual ao que a loja paga).
  root.TimoneiroMarket = {
    sampledAt: "2026-11-05", fee: 0.08, slots: 4, slotLockHours: 8,
    tiers: {
      common: { ratio: 3.0, perDay: 12 }, uncommon: { ratio: 1.25, perDay: 30 }, rare: { ratio: 1.25, perDay: 62 },
      legendary: { ratio: 1.6, perDay: 24 }, mythic: { ratio: 1.55, perDay: 13 }, secret: { ratio: 1.8, perDay: 5 }, divine: { ratio: 1.8, perDay: 0 },
    },
    fish: { peixe_mandarim: { median: 75, n: 43, note: "Peixe usado para ascender: peso quase fixo, todos os ascendidos do top 10 global são mandarins." } },
    staleAboveRatio: 2.0, staleDays: 14,
  };

  // Referência coletada de 60 perfis públicos (top 10 de 8 barcos) em 05/11/2026.
  // Por faixa de nível: vara mais comum, quem já tem anzol, mochila típica e moedas medianas.
  root.TimoneiroBenchmark = {
    sampledAt: "2026-11-05",
    sample: 60,
    bands: [
      { min: 0, max: 16, label: "nível 4–16", rod: "vara_fibra", rodRange: "Madeira a Carbono", hook: "nenhum", backpack: "nenhuma", casts: "100–1.000", coins: "~700", note: "Faixa onde costuma estar o topo do ranking de um barco." },
      { min: 17, max: 32, label: "nível 17–32", rod: "vara_encantada", rodRange: "Carbono a Encantada", hook: "nenhum", backpack: "Couro", casts: "1.000–3.000", coins: "—", note: "Faixa de transição; poucos jogadores na amostra." },
      { min: 33, max: 46, label: "nível 33–46", rod: "vara_abissal", rodRange: "Abissal ou Lendária", hook: "nenhum (0 de 26)", backpack: "Couro ou Encerada", casts: "2.200–7.300", coins: "~6.000", note: "Todos já têm Secreto ou Divino como melhor captura: vêm das expedições." },
      { min: 47, max: 70, label: "nível 47–70", rod: "vara_lendaria", rodRange: "Lendária ou Njord", hook: "Duplo em ~40%", backpack: "Encerada ou Navegador", casts: "5.700–15.000", coins: "~10.000", note: "Anzol Duplo chega depois da Lendária/Njord." },
      { min: 71, max: 150, label: "nível 71+", rod: "vara_njord", rodRange: "Njord", hook: "Duplo ou Triplo", backpack: "Navegador a Leviatã", casts: "7.700–18.900", coins: "~10.000", note: "Triplo só a partir do nível 69." },
    ],
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
