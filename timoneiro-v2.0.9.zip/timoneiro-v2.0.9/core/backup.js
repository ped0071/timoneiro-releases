// Timoneiro — backup dos seus dados (Opções → Backup).
// Só entram dados seus (ajustes, histórico, previsão, favoritos): nada de estado interno (leitura,
// cache da lista de barcos, aba líder, pedidos) e nunca o webhook do Discord, que é um segredo.
// Na importação o que não está na lista é ignorado, então um backup antigo da 1.x também serve.
(function (root) {
  "use strict";
  const B = root.TimoneiroBoats || (typeof require === "function" ? require("./boats.js") : null);
  const KEYS = root.TimoneiroKeys || (typeof require === "function" ? require("./keys.js") : null);
  const USER_KEYS = new Set([
    "timoneiro.notifications.v1", "timoneiro.handle.v1", "timoneiro.marketWatch.v1",
    "timoneiro.history.v1", "timoneiro.eventLog.v1", "timoneiro.eventHistory.v1",
    "timoneiro.guideSeen.v1", "timoneiro.layout.v1", "timoneiro.theme.v1",
    "timoneiro.sounds.v1", "timoneiro.quick.v1", "timoneiro.guide.v2",
    "timoneiro.boatPrefs.v1", "timoneiro.ui.v1",
  ]);
  const OLD_BOAT = "timoneiro.boat.v2", OLD_CHANNELS = "timoneiro.legacyChannels.v1", PREFS = "timoneiro.boatPrefs.v1";
  const MAX = 5 * 1024 * 1024;

  function cleanPrefs(p) {
    const hidden = Array.isArray(p?.hidden) ? p.hidden.filter((x) => typeof x === "string").map(B.slug).filter(Boolean) : [];
    const out = { pinned: B.slug(p?.pinned) || null, hidden: [...new Set(hidden)] };
    if (Array.isArray(p?.only)) out.only = [...new Set(p.only.filter((x) => typeof x === "string").map(B.slug).filter(Boolean))];
    out.migrated = true;
    return out;
  }

  function exportData(all, now = Date.now()) {
    const data = {};
    for (const [k, v] of Object.entries(all || {})) if (USER_KEYS.has(k)) data[k] = v;
    return { app: "timoneiro", version: 1, exportedAt: now, data };
  }

  function importData(json) {
    const no = (error) => ({ ok: false, error });
    if (!json || typeof json !== "object" || Array.isArray(json) || json.app !== "timoneiro") return no("Este arquivo não é um backup do Timoneiro.");
    const src = json.data;
    if (!src || typeof src !== "object" || Array.isArray(src)) return no("O backup está vazio ou corrompido.");
    if (JSON.stringify(src).length > MAX) return no("O backup passa de 5 MB.");
    // Backup da 1.x tem os nomes antigos (pescaskills.*): converte para os do Timoneiro.
    const renamed = {};
    for (const [k, v] of Object.entries(src)) { const nu = KEYS.rename(k) || k; if (!(nu in renamed) || nu === k) renamed[nu] = v; }
    const data = {};
    for (const [k, v] of Object.entries(renamed)) if (USER_KEYS.has(k)) data[k] = v;
    // Backup da 1.x: o barco fixado antigo vira a preferência da 2.0.
    if (!data[PREFS] && (renamed[OLD_BOAT] || renamed[OLD_CHANNELS])) data[PREFS] = B.migrate(renamed[OLD_CHANNELS], renamed[OLD_BOAT]);
    if (data[PREFS]) data[PREFS] = cleanPrefs(data[PREFS]);
    if (!Object.keys(data).length) return no("O backup não tem nenhum dado do Timoneiro para importar.");
    return { ok: true, data };
  }

  const api = { exportData, importData, USER_KEYS };
  root.TimoneiroBackup = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
