// Timoneiro — recomendações específicas: expedição solo, preço no Mercado por espécie,
// torneio e incubação. Puro (sem DOM, sem rede). Usado pelo core/planner.js.
(function (root, factory) {
  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroAdvisors = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";
  const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
  const fold = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const med = (a) => { const x = a.filter(Number.isFinite).sort((p, q) => p - q); return x.length ? x[Math.floor(x.length / 2)] : null; };
  const q = (a, p) => { const x = a.filter(Number.isFinite).sort((m, n) => m - n); return x.length ? x[Math.min(x.length - 1, Math.floor((x.length - 1) * p))] : null; };
  const TIER_MULT = { divine: 10 }; // manual: sell_price_multiplier (2 nos demais)
  const SEA_NAMES = { baia: "Baía das Lendas", sereias: "Mar das Sereias", abismo: "Abismo dos Deuses", fenda: "Fenda do Fim" };

  // ---------- mares (manual ao vivo com reserva no catálogo) ----------
  function seasOf(manual) {
    const cat = root.TimoneiroCatalog?.seas || [];
    const live = manual?.expeditions?.seas;
    if (!Array.isArray(live) || !live.length) return cat;
    const rods = root.TimoneiroCatalog?.shop?.rods || [];
    const rodIdByName = (name) => rods.find((r) => fold(r.name) === fold(name))?.id || null;
    return live.map((s) => {
      const fallback = cat.find((c) => c.sea === s.sea) || {};
      const shares = {}; const exclusiveTiers = [];
      for (const x of s.shares || []) { shares[x.id] = x.share; if (x.exclusive) exclusiveTiers.push(x.id); }
      const casts = {}; const exclusive = {};
      for (const o of s.odds || []) { const id = rodIdByName(o.rod_name); if (id) { casts[id] = o.casts; exclusive[id] = o.at_least_one_level_0; } }
      return {
        sea: s.sea, name: SEA_NAMES[s.sea] || s.entry_item_name || s.sea, min_rod: rodIdByName(s.min_rod_name) || fallback.min_rod,
        ticket: num(s.entry_price), entry: s.entry_price == null ? `${s.entry_quantity || 3} ${s.entry_item_name || "Fragmentos"}` : null,
        refund: num(s.refund) ?? 0, insurance: num(s.insurance?.price) ?? null, hazard: num(s.hazard_chance) ?? 0,
        hazards: s.hazards || [], coinLoss: num(s.coin_loss) ?? 0, coinCap: num(s.coin_loss_cap) ?? 0, orders: num(s.port_order_coins) ?? 0,
        shares: Object.keys(shares).length ? shares : fallback.shares || {}, exclusiveTiers: exclusiveTiers.length ? exclusiveTiers : fallback.exclusiveTiers || [],
        casts: Object.keys(casts).length ? casts : fallback.casts || {}, exclusive: Object.keys(exclusive).length ? exclusive : fallback.exclusive || {},
      };
    });
  }

  function tierValues(ctx) {
    // valor de venda médio por raridade (loja), ou líquido no Mercado se for maior
    const out = {};
    const ref = root.TimoneiroMarket?.tiers || {};
    for (const [t, pts] of Object.entries(ctx.avgPts)) {
      const base = pts * (TIER_MULT[t] || 2);
      const shop = base * ctx.sellBonus * ctx.curse;
      const market = ["legendary", "mythic", "secret", "divine"].includes(t) ? base * (ctx.marketRatio?.[t] ?? ref[t]?.ratio ?? 1) * 0.92 : 0;
      out[t] = Math.max(shop, market);
    }
    out.fragment = ctx.fragmentValue ?? 0;
    return out;
  }

  function binomLess2(n, p) { return Math.pow(1 - p, n) + n * p * Math.pow(1 - p, n - 1); }

  // Valor esperado (em moedas) de UMA viagem solo a um mar com uma vara.
  function seaEV(sea, rodId, ctx, tide) {
    const casts = num(sea.casts?.[rodId]);
    if (!casts || sea.ticket == null) return null;
    const t = tide || { bite: 1, exclusives: 1, hazard: 1 };
    const hz = Math.min(0.95, (sea.hazard || 0) * (t.hazard ?? 1));
    const bite = Math.min(0.95, ctx.bite * (t.bite ?? 1));
    const pFish = (1 - hz) * bite;
    const fish = casts * pFish;
    const shares = { ...sea.shares };
    for (const k of sea.exclusiveTiers || []) if (shares[k] != null) shares[k] *= t.exclusives ?? 1;
    const total = Object.values(shares).reduce((a, b) => a + b, 0) || 1;
    const vals = tierValues(ctx);
    let perFish = 0, exShare = 0;
    for (const [k, v] of Object.entries(shares)) { perFish += (v / total) * (vals[k] ?? 0); if ((sea.exclusiveTiers || []).includes(k) && k !== "fragment") exShare += v / total; }
    const fishValue = fish * perFish;
    const exFish = fish * exShare;
    const orders = ctx.firstTripToday === false ? 0 : Math.min(3, exFish) * (sea.orders || 0) * 0.7;
    const refund = sea.refund ? binomLess2(casts, pFish) * sea.refund : 0;
    const hazardsN = casts * hz;
    const kinds = sea.hazards?.length || 1;
    const coinLoss = (sea.hazards || []).includes("coins") ? (hazardsN / kinds) * Math.min((sea.coinLoss || 0) * (ctx.coins ?? 0), sea.coinCap || Infinity) : 0;
    const fishLoss = (sea.hazards || []).includes("lose_fish") ? (hazardsN / kinds) * (ctx.avgStockPrice ?? 10) : 0;
    const lossUnins = coinLoss + fishLoss;
    const insure = sea.insurance != null && sea.insurance < lossUnins;
    const risk = insure ? sea.insurance : lossUnins;
    const net = fishValue + orders + refund - sea.ticket - risk;
    return { sea: sea.sea, name: sea.name, rodId, casts, fish, perFish, fishValue, exFish, orders, refund, risk, insure, ticket: sea.ticket, net,
      pExclusive: 1 - Math.pow(1 - pFish * exShare, casts), divineChance: shares.divine ? 1 - Math.pow(1 - pFish * (shares.divine / total), casts) : 0 };
  }

  function expeditionPlan(ctx) {
    const seas = seasOf(ctx.manual).filter((s) => s.ticket != null);
    const rods = (root.TimoneiroCatalog?.shop?.rods || []).map((r) => r.id);
    const idx = (id) => rods.indexOf(id);
    const rows = [];
    for (const s0 of seas) {
      const live = (ctx.live || []).find((x) => x.sea === s0.sea) || null;
      const s = live ? { ...s0,
        casts: Number.isFinite(live.chances?.casts) ? { ...s0.casts, [ctx.rodId]: live.chances.casts } : s0.casts,
        refund: num(live.refund) ?? s0.refund, coinCap: num(live.coin_loss_cap) ?? s0.coinCap, hazard: num(live.hazard_chance) ?? s0.hazard,
        insurance: live.insurance === null ? null : num(live.insurance?.price) ?? s0.insurance,
        hazards: Array.isArray(live.hazards) ? live.hazards.map((h) => h.hazard || h) : s0.hazards,
        coinLoss: (live.hazards || []).find((h) => h.hazard === "coins")?.value ?? s0.coinLoss,
        ticketOwned: (num(live.entry_owned) ?? 0) >= (num(live.entry_quantity) ?? 1),
        insuranceOwned: (num(live.insurance?.owned) ?? 0) > 0 } : s0;
      if (live?.rod_ok === false || (!live && idx(ctx.rodId) < idx(s.min_rod))) {
        rows.push({ sea: s.sea, name: s.name, locked: true, minRod: s.min_rod });
        continue;
      }
      const tideKey = ctx.tides?.[s.sea] || ctx.tides?._any || null;
      const tide = live?.tide && typeof live.tide === "object" ? { ...(root.TimoneiroCatalog?.tides?.[tideKey] || {}), ...live.tide } : tideKey ? root.TimoneiroCatalog?.tides?.[tideKey] : null;
      const ev = seaEV(s.ticketOwned ? { ...s, ticket: 0, paidTicket: s.ticket } : s, ctx.rodId, ctx, tide);
      if (ev) rows.push({ ...ev, ticketOwned: !!s.ticketOwned, tide: tideKey, tideLabel: tide?.label || null, live: !!live });
    }
    // a partir de qual vara a Baía (ou o melhor mar liberado) passa a dar lucro
    const breakEven = {};
    for (const s of seas) {
      for (const r of rods.slice(Math.max(0, idx(s.min_rod)))) {
        const ev = seaEV(s, r, { ...ctx, firstTripToday: true }, null);
        if (ev && ev.net > 0) { breakEven[s.sea] = r; break; }
      }
    }
    return { rows, breakEven };
  }

  // ---------- mercado: preço por espécie ----------
  // Usa vendas e anúncios da mesma espécie (lidos do site). Sugere:
  //  rápido = abaixo do anúncio concorrente mais barato, sem passar do que as vendas pagam;
  //  bom    = mediana das vendas, se não houver anúncio mais barato competindo.
  function priceFor(fish, species, refRatio) {
    const sales = (species?.sales || []).filter((p) => Number.isFinite(p));
    const asks = (species?.asks || []).filter((a) => Number.isFinite(a.ask)).sort((a, b) => a.ask - b.ask);
    const baseRef = med((species?.asks || []).map((a) => a.base).filter(Number.isFinite));
    const myBase = num(fish.base) ?? null;
    const scale = myBase && baseRef ? myBase / baseRef : 1; // peixe mais pesado → base maior
    const saleMed = med(sales), saleP75 = q(sales, 0.75), saleP25 = q(sales, 0.25);
    const cheapest = asks[0]?.ask ?? null;
    const floor = myBase ? Math.ceil(myBase * 0.5) : 1;
    const sug = species?.suggested && !species.suggested.fallback && species.suggested.sample >= 3 ? species.suggested : null;
    let good = saleMed != null ? Math.round(saleMed * scale) : sug ? sug.price : myBase ? Math.round(myBase * refRatio) : null;
    // as vendas recentes da espécie mandam; o sugerido do site entra como âncora quando há poucas vendas
    if (sug && sales.length < 6 && good != null) good = Math.round((good + sug.price) / 2);
    let fast = good;
    if (cheapest != null && good != null && cheapest <= good) fast = Math.max(floor, cheapest - 1);
    if (cheapest != null && good != null && cheapest > good) good = Math.min(Math.round((saleP75 ?? good) * scale), cheapest - 1);
    if (good != null) good = Math.max(floor, good);
    const stale = asks.filter((a) => saleP75 != null && a.ask > saleP75 * 1.5).length;
    return { good, fast, saleMed, saleP25, saleP75, sales: sales.length, cheapest, listings: asks.length, stale, floor, suggested: sug?.price ?? null, suggestedN: sug?.sample ?? 0, source: sales.length >= 3 ? "vendas da espécie" : sug ? "sugerido do site" : "referência por raridade" };
  }

  // ---------- torneio ----------
  function tournamentAdvice(t, acc) {
    if (!t || typeof t !== "object") return null;
    const active = !!(t.active || t.tournament?.active);
    if (!active) return { active: false, nextIn: num(t.seconds_until_next), bonus: num(t.rules?.win_bonus_twishcoins) ?? 70, joinWindow: num(t.rules?.join_window_seconds) ?? 150 };
    const joinOpen = !!(t.join_window_open ?? t.tournament?.join_window_open);
    const joined = !!(t.is_participant ?? t.joined ?? t.tournament?.is_participant);
    const joinLeft = num(t.join_window_seconds_remaining) ?? null;
    const left = num(t.seconds_remaining) ?? null;
    const leader = Array.isArray(t.standings) && t.standings[0] ? `${t.standings[0].username || t.standings[0].display_name} com ${t.standings[0].fish_name || t.standings[0].fish_id} (${t.standings[0].weight} kg)` : null;
    const participants = num(t.participants_count ?? t.participant_count ?? t.participants?.length) ?? (Array.isArray(t.standings) ? t.standings.length : null);
    return { active, joinOpen, joined, joinLeft, left, leader, participants, bonus: num(t.win_bonus_twishcoins) ?? 70, settling: !!t.settling };
  }

  // ---------- incubação ----------
  // Regras do manual: dois pais da mesma espécie e mesmo grau, o mais leve com ≥50% do mais pesado;
  // os pais sempre se perdem; falha: raro 10%, lendário 20%, mítico 35%, secreto 50%, divino 70%;
  // ascensão quando os dois têm ≥95% do peso máximo; cada grau +10% no valor de venda.
  const FAIL = { common: 0, uncommon: 0, rare: 0.1, legendary: 0.2, mythic: 0.35, secret: 0.5, divine: 0.7 };
  function incubationAdvice(acc, bestiary, owned) {
    const info = {};
    for (const f of bestiary?.fish || []) info[f.id] = f;
    const incubators = num(owned?.incubators ?? owned?.incubadora ?? owned?.incubadora_basica) ?? 0;
    const fertB = num(owned?.fertilizante_basico) ?? 0, fertP = num(owned?.fertilizante_premium) ?? 0;
    const groups = {};
    for (const f of acc.fish) {
      if (f.listed) continue; // anunciado no Mercado não pode ir para a incubadora
      if (!Number.isFinite(f.weight)) continue;
      const k = `${f.id}|${f.asc || 0}`;
      (groups[k] = groups[k] || []).push(f);
    }
    const ascend = [], grow = [];
    for (const [k, list] of Object.entries(groups)) {
      if (list.length < 2) continue;
      const [id, asc] = k.split("|");
      const max = num(info[id]?.max_kg) ?? num(list[0].maxKg);
      const tier = list[0].tier || info[id]?.tier;
      const sorted = [...list].sort((a, b) => b.weight - a.weight);
      const ready = max ? sorted.filter((f) => f.weight >= 0.95 * max) : [];
      if (ready.length >= 2) ascend.push({ id, name: list[0].name, tier, asc: Number(asc), fail: FAIL[tier] ?? 0.2, weights: ready.slice(0, 2).map((f) => f.weight), max });
      else {
        const [a, b] = sorted;
        if (b.weight >= 0.5 * a.weight) grow.push({ id, name: list[0].name, tier, asc: Number(asc), fail: FAIL[tier] ?? 0.2, weights: [a.weight, b.weight], max, pctMax: max ? a.weight / max : null });
      }
    }
    const safe = (x) => x.fail === 0;
    ascend.sort((a, b) => (safe(b) - safe(a)) || b.asc - a.asc);
    grow.sort((a, b) => (safe(b) - safe(a)) || (b.pctMax ?? 0) - (a.pctMax ?? 0));
    return { incubators, fertB, fertP, ascend, grow };
  }

  return { seasOf, seaEV, expeditionPlan, priceFor, tournamentAdvice, incubationAdvice, FAIL };
});
