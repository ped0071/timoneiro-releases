// Timoneiro — histórico de moedas, XP e lançadas da sua conta, para medir o ritmo real.
// Puro: sem DOM, sem rede. O service worker grava uma amostra a cada ~10 min; o Guia lê.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroHistory = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const EVERY_MS = 10 * 60e3;       // uma amostra a cada 10 min
  const KEEP_MS = 14 * 24 * 3600e3; // guarda 14 dias
  const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);

  function findNumber(obj, keys, maxDepth = 3) {
    let level = [obj];
    for (let d = 0; d <= maxDepth && level.length; d++) {
      for (const k of keys) for (const o of level) if (o && typeof o === "object" && !Array.isArray(o) && k in o) { const n = num(o[k]); if (n !== null) return n; }
      level = level.flatMap((o) => (o && typeof o === "object" ? Object.values(o).filter((v) => v && typeof v === "object" && !Array.isArray(v)) : []));
    }
    return null;
  }

  // Amostra a partir da resposta de /api/<barco>/me.
  function sampleFromMe(me, at = Date.now()) {
    const coins = findNumber(me, ["twishcoins", "coins", "balance", "saldo"]);
    const xp = findNumber(me, ["xp", "total_xp"]);
    const casts = findNumber(me, ["casts"]);
    if (coins === null && xp === null && casts === null) return null;
    return { t: at, coins, xp, casts };
  }

  function record(hist, sample, boat) {
    const h = hist && hist.boat === boat && Array.isArray(hist.samples) ? { boat, samples: hist.samples.slice() } : { boat, samples: [] };
    if (!sample) return h;
    // As amostras ficam a 10 min uma da outra; a última é a "ao vivo" e vai sendo trocada até
    // completar 10 min depois da penúltima.
    const n = h.samples.length;
    const last = h.samples[n - 1];
    if (n >= 2 && sample.t - h.samples[n - 2].t < EVERY_MS) {
      if (last.coins === sample.coins && last.xp === sample.xp && last.casts === sample.casts) return h;
      h.samples[n - 1] = sample;
    } else if (last && last.t >= sample.t) return h;
    else h.samples.push(sample);
    const cutoff = sample.t - KEEP_MS;
    h.samples = h.samples.filter((s) => s.t >= cutoff);
    return h;
  }

  // Ritmo medido numa janela. Moedas: só os ganhos (uma compra derruba o saldo e não é "ritmo").
  // Devolve por hora de relógio (inclui o tempo parado) e por lançada.
  function rates(hist, now = Date.now(), windowMs = 24 * 3600e3) {
    const s = (hist?.samples || []).filter((x) => x.t >= now - windowMs && x.t <= now);
    if (s.length < 2) return null;
    const hours = (s[s.length - 1].t - s[0].t) / 3600e3;
    if (hours < 1) return null;
    let gained = 0, xp = 0, casts = 0, spent = 0;
    for (let i = 1; i < s.length; i++) {
      const a = s[i - 1], b = s[i];
      if (a.coins != null && b.coins != null) { const d = b.coins - a.coins; if (d > 0) gained += d; else spent -= d; }
      if (a.xp != null && b.xp != null && b.xp >= a.xp) xp += b.xp - a.xp;
      if (a.casts != null && b.casts != null && b.casts >= a.casts) casts += b.casts - a.casts;
    }
    return {
      hours, samples: s.length,
      coinsPerHour: gained / hours, xpPerHour: xp / hours, castsPerHour: casts / hours, spent,
      coinsPerCast: casts ? gained / casts : null, xpPerCast: casts ? xp / casts : null,
      net: (s[s.length - 1].coins ?? 0) - (s[0].coins ?? 0),
    };
  }

  // Quanto tempo de relógio até juntar `missing` moedas no ritmo medido.
  function eta(r, missing) {
    if (!r || !(r.coinsPerHour > 0) || missing == null) return null;
    return missing <= 0 ? 0 : missing / r.coinsPerHour;
  }

  return { EVERY_MS, KEEP_MS, sampleFromMe, record, rates, eta, findNumber };
});
