// Timoneiro — previsão de eventos a partir do que o próprio Timoneiro já viu (v1.11.0).
// Puro: sem DOM, sem rede. O service worker grava cada evento visto e as horas em que estava
// lendo; a previsão é a frequência real: em quantas das horas observadas cada evento saiu.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroForecast = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const KEEP_MS = 14 * 24 * 3600e3;
  const TZ = "America/Sao_Paulo";
  const fmtSlot = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23" });
  // "2026-11-11T19" no horário de Brasília
  function slotOf(at) {
    const p = Object.fromEntries(fmtSlot.formatToParts(new Date(at)).map((x) => [x.type, x.value]));
    return `${p.year}-${p.month}-${p.day}T${p.hour}`;
  }
  const hourOf = (slot) => Number(slot.slice(11, 13));

  function record(log, list, at, boat) {
    const L = log && log.v === 1 && log.boat === boat ? { v: 1, boat, hours: { ...log.hours }, seen: log.seen.map((e) => ({ ...e })) } : { v: 1, boat, hours: {}, seen: [] };
    L.hours[slotOf(at)] = 1;
    for (const e of list || []) {
      if (!e || !e.rule) continue;
      const end = Number.isFinite(e.endsAt) ? e.endsAt : at;
      const same = L.seen.find((x) => x.rule === e.rule && x.slot === e.slot && (Math.abs(x.end - end) < 5 * 60e3 || (x.end >= at - 60e3 && x.last >= at - 5 * 60e3)));
      if (same) { same.end = Math.max(same.end, end); same.last = at; continue; }
      L.seen.push({ rule: e.rule, slot: e.slot, start: at, end, last: at, hour: hourOf(slotOf(at)) });
    }
    const cutoff = at - KEEP_MS;
    L.seen = L.seen.filter((x) => x.last >= cutoff);
    for (const k of Object.keys(L.hours)) if (Date.parse(`${k}:00:00-03:00`) < cutoff) delete L.hours[k];
    return L;
  }

  // Por evento: quantas vezes saiu, por dia, chance na próxima hora cheia e os horários mais comuns.
  function forecast(log, now = Date.now()) {
    const hours = Object.keys(log?.hours || {});
    const observed = hours.length;
    if (!observed) return { observed: 0, rows: [] };
    const nextHour = (hourOf(slotOf(now)) + 1) % 24;
    const byHourObs = Array(24).fill(0);
    for (const h of hours) byHourObs[hourOf(h)]++;
    const groups = {};
    for (const e of log.seen || []) (groups[e.rule] = groups[e.rule] || []).push(e);
    const rows = Object.entries(groups).map(([rule, list]) => {
      const byHour = Array(24).fill(0);
      for (const e of list) byHour[e.hour]++;
      const top = byHour.map((n, h) => ({ h, n, rate: byHourObs[h] ? n / byHourObs[h] : 0 })).filter((x) => x.n > 0).sort((a, b) => b.rate - a.rate || b.n - a.n).slice(0, 3);
      const pAny = Math.min(1, list.length / observed);
      // A chance na próxima hora usa o histórico daquela hora quando há dados suficientes nela.
      const pNext = byHourObs[nextHour] >= 3 ? byHour[nextHour] / byHourObs[nextHour] : pAny;
      const last = Math.max(...list.map((e) => e.last));
      return { rule, count: list.length, perDay: list.length / (observed / 24), pAny, pNext, top, last, grand: list.some((e) => e.slot === "grand"), shop: list.every((e) => e.slot === "shop") };
    }).sort((a, b) => b.count - a.count);
    return { observed, nextHour, enough: observed >= 12, rows };
  }

  return { record, forecast, slotOf, KEEP_MS };
});
