// Timoneiro — nomes das chaves de armazenamento e migração dos nomes antigos (pescaskills.*).
// Roda uma vez: copia cada chave antiga para a nova (se a nova ainda não existir) e apaga a antiga.
(function (root) {
  "use strict";
  const MARK = "timoneiro.keysMigrated.v1";
  // Chaves antigas em chrome.storage.local.
  const LEGACY = [
    "pescaskills.bgSync.v1", "pescaskills.boat.v2", "pescaskills.boatBench.v1", "pescaskills.boatBenchRequest.v1",
    "pescaskills.channels.v1", "pescaskills.compareRequest.v1", "pescaskills.compareResult.v1", "pescaskills.discord.v1",
    "pescaskills.eventHistory.v1", "pescaskills.eventLog.v1", "pescaskills.eventStatus.v1", "pescaskills.events.v2",
    "pescaskills.fishingStatus.v1", "pescaskills.guideData.v1", "pescaskills.guideSeen.v1", "pescaskills.handle.v1",
    "pescaskills.history.v1", "pescaskills.lastDiscountRate.v1", "pescaskills.layout.v1", "pescaskills.marketHits.v1",
    "pescaskills.marketWatch.v1", "pescaskills.notifications.v1", "pescaskills.notified.v2", "pescaskills.realtime.v1",
    "pescaskills.settingsStamp.v1", "pescaskills.smartData.v1", "pescaskills.soundLock.v1", "pescaskills.soundSettings.mirror.v1",
    "pescaskills.syncRequest.v1", "pescaskills.syncStatus.v1", "pescaskills.tabLeader.v1",
  ];
  // Chaves antigas no localStorage da página da Twitch (a página conseguia ler). Migradas pela barra.
  const PAGE_LEGACY = ["twish.quick.shortcuts.v1", "pescaskills.clickSendFishing.v1", "pescaskills.soundSettings.v2", "pescaskills.guide.v2", "pescaskills.theme.v1"];
  const SPECIAL = {
    "twish.quick.shortcuts.v1": "timoneiro.quick.v1",
    "pescaskills.channels.v1": "timoneiro.legacyChannels.v1", // timoneiro.channels.v1 é o cache da lista de barcos
    "pescaskills.clickSendFishing.v1": "timoneiro.clickSend.v1",
    "pescaskills.soundSettings.mirror.v1": "timoneiro.sounds.v1", // a cópia que o fundo lia
  };

  function rename(old) {
    if (SPECIAL[old]) return SPECIAL[old];
    return /^pescaskills\./.test(old) ? old.replace(/^pescaskills\./, "timoneiro.") : null;
  }

  function migrate(all) {
    if (!all || all[MARK]) return { set: {}, remove: [] };
    const set = {}, remove = [];
    for (const old of Object.keys(all)) {
      const nu = rename(old);
      if (!nu) continue;
      remove.push(old);
      if (!(nu in all)) set[nu] = all[old];
    }
    set[MARK] = true;
    return { set, remove };
  }

  // Na extensão: migra uma vez por sessão do fundo/aba. Quem lê chaves espera por ready().
  let running = null;
  function ready() { return running || (running = run()); }
  function run() {
    return (async () => {
      if (!root.chrome?.storage?.local) return;
      const all = await chrome.storage.local.get(null);
      const { set, remove } = migrate(all);
      if (Object.keys(set).length) await chrome.storage.local.set(set);
      if (remove.length) await chrome.storage.local.remove(remove);
    })().catch(() => {});
  }

  const api = { MARK, LEGACY, PAGE_LEGACY, rename, migrate, ready, run };
  root.TimoneiroKeys = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
