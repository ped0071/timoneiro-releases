// Timoneiro — saúde da leitura da conta (🟢/🟡/🔴), usada no Guia e no popup.
// Função pura: recebe os carimbos de tempo e devolve nível, texto e uma dica opcional.
(function (root) {
  "use strict";
  function ago(t, now = Date.now()) {
    const s = Math.max(0, Math.round((now - t) / 1000));
    return s < 60 ? `${s}s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.round(s / 3600)} h`;
  }

  // { bg, fishingAt, smartAt, realtime, boat, now }
  function compute({ bg = null, fishingAt = 0, smartAt = 0, realtime = null, boat = null, now = Date.now() } = {}) {
    const last = Math.max(fishingAt || 0, smartAt || 0, bg?.me === "ok" || bg?.me === "tab" ? bg.at || 0 : 0);
    const bgAge = bg?.at ? now - bg.at : null;
    let level = "ok", text;
    if (!last) { level = "bad"; text = "Ainda sem leitura da sua conta."; }
    else if (now - last > 5 * 60e3) { level = "bad"; text = `Última leitura da conta há ${ago(last, now)}.`; }
    else if (now - last > 2 * 60e3) { level = "warn"; text = `Última leitura da conta há ${ago(last, now)}.`; }
    else text = `Sincronizado há ${ago(last, now)}${bg?.tab ? " · aba do Twish" : bg?.me === "ok" ? " · segundo plano" : ""}`;
    if (last && realtime?.state === "live" && realtime.boat === boat) text += " · ⚡ tempo real";
    let hint = null;
    if (bg?.me === "login" && !bg?.tab) hint = "A leitura em segundo plano não recebeu sua sessão do Twish. Entre no twish.com.br neste navegador; enquanto isso, deixe a aba do inventário aberta.";
    else if (bg?.me === "rate" || bg?.events === "rate") hint = "O Twish pediu para ir mais devagar: nova leitura em 2 minutos.";
    else if (bgAge != null && bgAge > 3 * 60e3) hint = "A leitura em segundo plano está parada. Recarregue o Timoneiro em chrome://extensions.";
    return { level, text, hint };
  }

  const api = { compute, ago };
  root.TimoneiroHealth = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
