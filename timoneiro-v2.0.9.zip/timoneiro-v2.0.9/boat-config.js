// Barco do Twish usado pela extensão (o nome em twish.com.br/c/<barco>/...).
// Na Twitch ele segue o canal da live (channel-gate.js); no Twish, a URL da aba. Pode ficar sem barco (null).
(function (root) {
  "use strict";
  const KEY = "timoneiro.boat.v2"; // v2: barco fixo por padrão (antes trocava sozinho ao abrir outro barco)
  let current = { boat: null, locked: false };
  const listeners = new Set();

  const slug = (v) => String(v || "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_]/g, "");

  function get() { return current.boat || null; }
  function isLocked() { return !!current.locked; }
  function url(page) { return get() ? `https://twish.com.br/c/${encodeURIComponent(get())}/${page}` : "https://twish.com.br/"; }
  function apiBase() { return get() ? `/api/${encodeURIComponent(get())}` : null; }

  async function set(boat, { locked = true } = {}) {
    const value = slug(boat) || null;
    current = { boat: value, locked };
    await chrome.storage.local.set({ [KEY]: current });
    return value;
  }

  // Na aba do Twish: adota o barco da URL, a menos que o usuário tenha fixado outro em Ajustes.
  async function adoptFromUrl(pathname) {
    // Só adota de páginas suas (/c/<barco> ou /c/<barco>/inventory...), nunca de perfil de outro jogador.
    const fromUrl = slug(String(pathname || "").match(/^\/c\/([^/]+)(?:\/(?:inventory|shop|market|bestiario|incubation|tournament|expedicoes|ranking))?\/?$/)?.[1]);
    if (fromUrl && !current.locked && fromUrl !== current.boat) await set(fromUrl, { locked: false });
  }

  function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

  const ready = new Promise((resolve) => {
    if (!chrome?.storage?.local) return resolve(get());
    chrome.storage.local.get(KEY, (r) => {
      if (r?.[KEY]?.boat) current = { boat: slug(r[KEY].boat), locked: r[KEY].locked === true };
      resolve(get());
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[KEY]) return;
      const prev = get();
      const nv = changes[KEY].newValue;
      current = nv?.boat ? { boat: slug(nv.boat), locked: nv.locked === true } : { boat: null, locked: false };
      if (get() !== prev) listeners.forEach((fn) => { try { fn(get(), prev); } catch (_) {} });
    });
  });

  root.TimoneiroBoat = { KEY, ready, get, isLocked, set, url, apiBase, adoptFromUrl, onChange, slug };
})(typeof globalThis !== "undefined" ? globalThis : this);
