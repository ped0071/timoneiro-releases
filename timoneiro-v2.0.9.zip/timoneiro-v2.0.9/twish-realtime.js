// Timoneiro — tempo real do Twish (v1.10.0), na aba do twish.com.br.
// O próprio site do Twish recebe avisos por WebSocket (Centrifugo em wss://twish.com.br/connection/websocket):
// cooldown_changed (com os segundos restantes), cooldowns_cleared, capture_added, events_changed e
// tournament_changed. O Timoneiro abre a mesma conexão, só para ouvir, e publica na hora em vez de
// esperar a próxima leitura. O servidor só aceita conexões vindas do twish.com.br, por isso isto roda
// na aba do Twish (e nunca disfarça a origem). Só a aba líder conecta. Nada é enviado ao jogo.
(() => {
  "use strict";
  if (window.__timoneiroRealtime) return;
  window.__timoneiroRealtime = true;
  const Boat = globalThis.TimoneiroBoat;
  const Leader = globalThis.TimoneiroLeader;
  if (!Boat || !Leader || !chrome?.storage?.local || typeof WebSocket !== "function") return;
  const STATUS_KEY = "timoneiro.realtime.v1";

  let ws = null, connecting = false, seq = 0, retries = 0, retryTimer = null, refreshTimer = null;
  let pending = new Map(), channelKind = {}, channelId = null, wantPong = false, boatAtConnect = null;
  // Extensão atualizada: esta cópia fecha a conexão sem reconectar (a cópia nova abre a dela).
  globalThis.TimoneiroAlive?.onStop(() => {
    const s = ws;
    ws = null;
    if (s) { s.onclose = null; s.onmessage = null; try { s.close(); } catch (_) {} }
  });

  const status = (state, extra = {}) => chrome.storage.local.set({ [STATUS_KEY]: { state, boat: Boat.get(), at: Date.now(), ...extra } }).catch(() => {});
  const send = (obj) => { try { ws?.send(JSON.stringify(obj)); } catch (_) {} };
  function command(body) {
    const id = ++seq;
    send({ id, ...body });
    return new Promise((ok, ko) => { pending.set(id, { ok, ko }); setTimeout(() => { if (pending.delete(id)) ko(new Error("timeout")); }, 15000); });
  }
  async function tokenInfo() {
    const r = await fetch(`/api/${encodeURIComponent(Boat.get())}/realtime`, { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw Object.assign(new Error(String(r.status)), { status: r.status });
    return r.json();
  }

  async function connect() {
    if (ws || connecting || !Leader.isLeader()) return;
    connecting = true;
    clearTimeout(retryTimer);
    try {
      const info = await tokenInfo();
      if (!info?.url || !info?.token) throw new Error("sem url");
      channelId = info.channel_id ?? null;
      boatAtConnect = Boat.get();
      channelKind = {};
      for (const [kind, ch] of Object.entries(info.channels || {})) if (typeof ch === "string" && ["player", "events", "tournament"].includes(kind)) channelKind[ch] = kind;
      const url = new URL(info.url, location.origin);
      if (url.protocol === "https:") url.protocol = "wss:";
      if (url.protocol === "http:") url.protocol = "ws:";
      const sock = new WebSocket(url.href);
      ws = sock;
      sock.onopen = async () => {
        try {
          const res = await command({ connect: { token: info.token, name: "timoneiro" } });
          wantPong = !!res?.pong;
          scheduleRefresh(res);
          await Promise.all(Object.keys(channelKind).map((ch) => command({ subscribe: { channel: ch } }).catch(() => null)));
          retries = 0;
          status("live", { channels: Object.values(channelKind) });
          keepTab(true);
          catchUp();
        } catch (e) { status("off", { error: String(e?.code || e?.message || e) }); try { sock.close(); } catch (_) {} }
      };
      sock.onmessage = (e) => { for (const line of String(e.data).split("\n")) handleLine(line); };
      sock.onclose = () => {
        if (ws === sock) ws = null;
        clearTimeout(refreshTimer);
        for (const p of pending.values()) p.ko(new Error("closed"));
        pending.clear();
        status("off");
        retry();
      };
    } catch (e) {
      ws = null;
      status(e?.status === 401 || e?.status === 403 ? "login" : "off", { error: String(e?.status || e?.message || e) });
      retry();
    } finally { connecting = false; }
  }

  function handleLine(line) {
    if (!line.trim()) return;
    let m;
    try { m = JSON.parse(line); } catch (_) { return; }
    if (m && typeof m === "object" && !Object.keys(m).length) { if (wantPong) send({}); return; } // ping do servidor
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.ko(m.error); else p.ok(m.connect || m.subscribe || m.refresh || {});
      return;
    }
    const push = m.push;
    if (!push) return;
    if (push.disconnect) { try { ws?.close(); } catch (_) {} return; }
    const data = push.pub?.data;
    if (data && typeof data === "object") onPublication(channelKind[push.channel], data);
  }

  // Token com validade: renova antes de vencer pelo próprio protocolo (sem reconectar).
  function scheduleRefresh(res) {
    clearTimeout(refreshTimer);
    if (!res?.expires || !Number.isFinite(res.ttl)) return;
    refreshTimer = setTimeout(async () => {
      try { const info = await tokenInfo(); const r = await command({ refresh: { token: info.token } }); scheduleRefresh(r); }
      catch (_) { try { ws?.close(); } catch (__) {} }
    }, Math.max(10, res.ttl - 30) * 1000);
  }

  function retry() {
    clearTimeout(retryTimer);
    if (!Leader.isLeader()) return;
    const wait = Math.min(120, 2 ** Math.min(retries++, 6)) * 1000 * (0.5 + Math.random());
    retryTimer = setTimeout(connect, wait);
  }

  // ---------- o que cada aviso faz ----------
  const T = () => globalThis.TimoneiroTwish;
  const G = () => globalThis.TimoneiroGuideSync;
  const debounced = {};
  const later = (key, ms, fn) => { clearTimeout(debounced[key]); debounced[key] = setTimeout(fn, ms); };
  const askWorker = (type) => { try { chrome.runtime.sendMessage({ type }).catch(() => {}); } catch (_) {} };

  function onPublication(kind, d) {
    // O canal do jogador é global: avisos de outro barco ficam de fora (o site faz o mesmo).
    if (kind === "player" && d.channel_id && channelId && d.channel_id !== channelId && d.type !== "listing_sold" && d.type !== "listing_held") return;
    const t = d.type;
    if (kind === "player") {
      if (t === "cooldown_changed") { if (typeof d.remaining === "number") T()?.setCooldown(d.remaining); else T()?.refetchFishing(); }
      else if (t === "cooldowns_cleared") T()?.setCooldown(0);
      else if (t === "capture_added") later("account", 1500, () => T()?.refetchAccount());
      else if (t === "resync") later("resync", Math.random() * 10000, catchUp);
      else if (/^expedition_/.test(t || "")) later("sea", 1000, () => G()?.refreshJob("expeditions"));
      else if (t === "listing_sold" || t === "listing_held") later("account", 1500, () => T()?.refetchAccount());
      return;
    }
    if (kind === "events") {
      if (t === "cooldowns_cleared") { T()?.setCooldown(0); return; }
      // Sem "state" o servidor pede para todos relerem: espalha no tempo como o site (até 30 s).
      const wait = t === "events_changed" && d.state ? Math.random() * 2000 : Math.random() * 30000;
      later("events", wait, () => { T()?.refetchEvents(); askWorker("timoneiro-sync-events"); });
      return;
    }
    if (kind === "tournament") later("tour", 500 + Math.random() * 1500, () => G()?.refreshJob("tournament"));
  }

  // Depois de conectar (ou de um resync): uma leitura de tudo para não perder o que mudou antes.
  function catchUp() { T()?.refetchFishing(); T()?.refetchEvents(); G()?.refreshJob("tournament"); askWorker("timoneiro-sync-events"); }

  // A aba que ouve o tempo real não pode ser descarregada pela Economia de memória / Guias em suspensão.
  function keepTab(on) { try { chrome.runtime.sendMessage({ type: "timoneiro-keep-tab", on }).catch(() => {}); } catch (_) {} }

  function stop() {
    clearTimeout(retryTimer); clearTimeout(refreshTimer);
    if (ws) { const s = ws; ws = null; try { s.close(); } catch (_) {} }
    keepTab(false);
  }

  Leader.ready.then(() => { if (Leader.isLeader()) connect(); });
  Leader.onChange((on) => { if (on) connect(); else stop(); });
  Boat.onChange(() => { stop(); retries = 0; setTimeout(connect, 500); });
  // A aba voltou a ficar visível depois de muito tempo: confere a conexão.
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && !ws && Leader.isLeader()) { retries = 0; connect(); } });
  addEventListener("pagehide", stop, { once: true });
  globalThis.TimoneiroRealtime = { live: () => !!ws && ws.readyState === 1, boat: () => boatAtConnect };
})();
