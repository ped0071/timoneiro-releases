// Timoneiro — escolhe UMA aba do twish.com.br para publicar dados.
// Antes, toda aba aberta escrevia cooldown e evento a cada segundo; uma aba de perfil
// de outra pessoa (ou de outro barco) escrevia valores diferentes e o status ficava
// alternando, o que disparava notificações repetidas.
// Regras: só é elegível uma página SUA do barco configurado (/c/<barco>, /c/<barco>/inventory,
// /shop, /market, ..., e o SEU perfil /c/<barco>/<seu nick>/inventory). Perfis de outros
// jogadores e outros barcos nunca publicam. Entre as elegíveis, a primeira vira líder; se ela fechar ou parar
// de responder por 6 s, outra assume.
(() => {
  "use strict";
  if (window.__timoneiroLeader) return;
  const Boat = globalThis.TimoneiroBoat;
  if (!Boat || !chrome?.storage?.local) return;
  const KEY = "timoneiro.tabLeader.v1";
  const token = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const OWN_PAGES = /^\/c\/([^/]+)(?:\/(inventory|shop|market|bestiario|incubation|tournament|expedicoes|ranking|manual))?\/?$/;
  const PROFILE = /^\/c\/([^/]+)\/([^/]+)\/(?:inventory|aquario|aquarium)?\/?$/;
  const SECTIONS = /^(inventory|shop|market|bestiario|incubation|tournament|expedicoes|ranking|manual)$/;
  let ownHandle = null, askedMe = false;
  async function loadHandle() {
    if (ownHandle) return ownHandle;
    try {
      const s = await chrome.storage.local.get(["timoneiro.handle.v1", "timoneiro.smartData.v1"]);
      const me = s["timoneiro.smartData.v1"]?.data?.me || {};
      ownHandle = String(s["timoneiro.handle.v1"] || me.login || me.handle || "").toLowerCase() || null;
    } catch (_) {}
    if (!ownHandle && !askedMe && Boat.get() && PROFILE.test(location.pathname)) {
      askedMe = true; // uma leitura só por aba: /me diz quem está logado
      try { const r = await fetch(`/api/${encodeURIComponent(Boat.get())}/me`, { credentials: "same-origin", cache: "no-store" }); if (r.ok) ownHandle = String((await r.json()).login || "").toLowerCase() || null; } catch (_) {}
    }
    return ownHandle;
  }
  const STALE_MS = 6000;
  let leader = false;
  const listeners = new Set();

  function eligible() {
    const m = location.pathname.match(OWN_PAGES);
    if (m) return Boat.slug(decodeURIComponent(m[1])) === Boat.get();
    const p = location.pathname.match(PROFILE);
    return !!p && !SECTIONS.test(p[2]) && Boat.slug(decodeURIComponent(p[1])) === Boat.get() && !!ownHandle && decodeURIComponent(p[2]).toLowerCase() === ownHandle;
  }

  function setLeader(v) {
    if (v === leader) return;
    leader = v;
    listeners.forEach((fn) => { try { fn(v); } catch (_) {} });
  }

  async function beat() {
    await loadHandle();
    if (!eligible()) { setLeader(false); return; }
    const rec = (await chrome.storage.local.get(KEY))[KEY];
    const now = Date.now();
    if (!rec || rec.token === token || now - (rec.at || 0) > STALE_MS) {
      await chrome.storage.local.set({ [KEY]: { token, at: now, path: location.pathname } });
      const check = (await chrome.storage.local.get(KEY))[KEY];
      setLeader(check?.token === token);
    } else setLeader(false);
  }

  addEventListener("pagehide", () => {
    if (leader) chrome.storage.local.remove(KEY);
  });

  window.__timoneiroLeader = true;
  globalThis.TimoneiroLeader = {
    isLeader: () => leader,
    eligible,
    onChange: (fn) => { listeners.add(fn); return () => listeners.delete(fn); },
    ready: Boat.ready.then(beat),
  };
  setInterval(beat, 2000);
})();
