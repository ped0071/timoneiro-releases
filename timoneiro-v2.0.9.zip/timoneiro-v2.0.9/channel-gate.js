// Timoneiro — em quais canais da Twitch a extensão aparece e qual barco vale.
// Automático: se o canal da live é um barco do Twish (lista pública /api/channels), a barra aparece
// e o barco passa a ser esse canal. Em Ajustes dá para esconder num canal ou fixar um barco.
// A decisão é de core/boats.js; aqui ficam o storage, a URL da Twitch e o barco ativo.
(() => {
  "use strict";
  if (globalThis.TimoneiroChannel) return;
  const B = globalThis.TimoneiroBoats;
  const K = {
    prefs: "timoneiro.boatPrefs.v1",
    ui: "timoneiro.ui.v1",
    cache: "timoneiro.channels.v1",
    seen: "timoneiro.channels.seen.v1",
    boat: "timoneiro.boat.v2",
    oldChannels: "timoneiro.legacyChannels.v1",
  };
  let prefs = { pinned: null, hidden: [] }, ui = { collapsed: false }, cache = null, seen = [];
  const listeners = new Set();
  const emit = () => listeners.forEach((fn) => { try { fn(get()); } catch (_) {} });

  const current = (path = location.pathname) => B.channelFromPath(path);
  const decision = () => B.decide({ channel: current(), cache, prefs, seen });
  const get = () => ({ collapsed: !!ui.collapsed, pinned: prefs.pinned || null, hidden: [...(prefs.hidden || [])], only: [...(prefs.only || [])] });

  async function savePrefs(next) { prefs = { ...prefs, ...next, migrated: true }; await chrome.storage.local.set({ [K.prefs]: prefs }); }
  // set() continua aceitando { collapsed } (botão ocultar da barra).
  async function set(patch) {
    if ("collapsed" in patch) { ui = { ...ui, collapsed: !!patch.collapsed }; await chrome.storage.local.set({ [K.ui]: ui }); }
  }
  async function hideHere(on) {
    const ch = current(); if (!ch) return;
    const hidden = new Set(prefs.hidden || []);
    on ? hidden.add(ch) : hidden.delete(ch);
    await savePrefs({ hidden: [...hidden] });
  }
  // Só o nome do canal: link ou prefixo da Twitch grudado não é salvo (o campo mostra o erro e a sugestão).
  const knownBoats = () => (Array.isArray(cache?.list) ? cache.list : []);
  async function pin(boat) {
    if (!String(boat ?? "").trim()) { await savePrefs({ pinned: null }); return { ok: true, errors: [] }; }
    const r = B.checkName(boat, knownBoats());
    if (!r.ok) return { ok: false, errors: [{ raw: String(boat).trim(), ...r }] };
    await savePrefs({ pinned: r.name });
    return { ok: true, errors: [] };
  }
  // "Mostrar só nestes canais": lista separada por vírgula; vazia = qualquer barco.
  async function setOnly(text) {
    const r = B.checkList(Array.isArray(text) ? text.join(",") : text, knownBoats());
    if (r.errors.length) return { ok: false, errors: r.errors };
    await savePrefs({ only: r.names });
    return { ok: true, errors: [] };
  }
  const known = knownBoats;

  // A aba visível escreve o barco ativo, que o resto do Timoneiro (Twish, fundo, Guia) lê.
  let asked = 0;
  async function sync() {
    const ch = current();
    if (ch && Date.now() - asked > 60000 && B.needsRefresh(cache, Date.now(), ch)) {
      asked = Date.now();
      try { chrome.runtime.sendMessage({ type: "timoneiro-channels-refresh", channel: ch }).catch(() => {}); } catch (_) {}
    }
    if (document.visibilityState !== "visible") return;
    // Fixado: o barco ativo é sempre o fixado (avisos e leitura), em qualquer aba da Twitch.
    const pinned = B.slug(prefs.pinned) || null;
    const d = decision();
    if (!pinned && (!d.show || !d.boat)) return;
    const want = pinned ? { boat: pinned, locked: true } : { boat: d.boat, locked: false };
    const r = await chrome.storage.local.get(K.boat);
    const have = r[K.boat];
    if (!have || have.boat !== want.boat || !!have.locked !== want.locked) await chrome.storage.local.set({ [K.boat]: want });
  }

  async function load() {
    await globalThis.TimoneiroKeys?.ready();
    const r = await chrome.storage.local.get([K.prefs, K.ui, K.cache, K.seen, K.boat, K.oldChannels]);
    if (r[K.prefs]?.migrated) prefs = r[K.prefs];
    else {
      // Primeira vez na 2.0: quem tinha um barco fixado continua com ele.
      prefs = B.migrate(r[K.oldChannels], r[K.boat]);
      await chrome.storage.local.set({ [K.prefs]: prefs });
    }
    ui = r[K.ui] || { collapsed: !!r[K.oldChannels]?.collapsed };
    cache = r[K.cache] || null;
    seen = Array.isArray(r[K.seen]) ? r[K.seen] : [];
  }

  const ready = load().catch(() => {}).then(() => { emit(); return sync(); }).catch(() => {});
  try {
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== "local") return;
      let changed = false;
      if (c[K.prefs]) { prefs = c[K.prefs].newValue || { pinned: null, hidden: [] }; changed = true; }
      if (c[K.ui]) { ui = c[K.ui].newValue || { collapsed: false }; changed = true; }
      if (c[K.cache]) { cache = c[K.cache].newValue || null; changed = true; }
      if (c[K.seen]) { seen = c[K.seen].newValue || []; changed = true; }
      if (changed) { emit(); sync().catch(() => {}); }
    });
  } catch (_) {}

  // A Twitch troca de canal sem recarregar a página: vigia o endereço.
  let lastPath = location.pathname;
  setInterval(() => { if (location.pathname !== lastPath) { lastPath = location.pathname; emit(); sync().catch(() => {}); } }, 500);
  document.addEventListener("visibilitychange", () => sync().catch(() => {}));
  addEventListener("focus", () => sync().catch(() => {}));

  globalThis.TimoneiroChannel = {
    current, decision, set, hideHere, pin, setOnly, known, ready, get,
    allowed: () => decision().show,
    clean: B.slug,
    onChange: (fn) => { listeners.add(fn); return () => listeners.delete(fn); },
  };
})();
