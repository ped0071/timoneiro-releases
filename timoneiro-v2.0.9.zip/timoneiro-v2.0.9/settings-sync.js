// Timoneiro — ajustes sincronizados entre computadores (v1.11.0), pelo chrome.storage.sync
// (conta Google no Chrome, conta Microsoft no Edge, conta Firefox no Firefox).
// Vão: notificações, canais, barco, nick e alertas do Mercado. NÃO vão: o webhook do Discord
// (é um segredo) e os dados da conta.
var TimoneiroSettingsSync = (() => {
  "use strict";
  const ITEM = "timoneiro.settings.v1";
  const STAMP = "timoneiro.settingsStamp.v1";
  const KEYS = ["timoneiro.notifications.v1", "timoneiro.boatPrefs.v1", "timoneiro.handle.v1", "timoneiro.marketWatch.v1"];
  if (!chrome.storage?.sync) return { KEYS };
  let applying = false, timer = null;

  async function push() {
    const local = await chrome.storage.local.get(KEYS);
    const at = Date.now();
    const values = Object.fromEntries(KEYS.filter((k) => local[k] !== undefined).map((k) => [k, local[k]]));
    try {
      await chrome.storage.sync.set({ [ITEM]: { at, values } });
      await chrome.storage.local.set({ [STAMP]: at });
    } catch (_) { /* cota do sync cheia ou sync desligado: os ajustes continuam só neste computador */ }
  }

  async function apply(item) {
    if (!item?.values || !Number.isFinite(item.at)) return;
    const stamp = (await chrome.storage.local.get(STAMP))[STAMP] || 0;
    if (item.at <= stamp) return;
    applying = true;
    try {
      const values = Object.fromEntries(Object.entries(item.values).filter(([k]) => KEYS.includes(k)));
      await chrome.storage.local.set({ ...values, [STAMP]: item.at });
    } finally { setTimeout(() => { applying = false; }, 500); }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes[ITEM]) { apply(changes[ITEM].newValue); return; }
    if (area !== "local" || applying || !KEYS.some((k) => changes[k])) return;
    clearTimeout(timer);
    timer = setTimeout(push, 2000);
  });

  // Ao iniciar: o mais novo vence (este computador ou a nuvem).
  (async () => {
    try {
      const item = (await chrome.storage.sync.get(ITEM))[ITEM];
      const stamp = (await chrome.storage.local.get(STAMP))[STAMP] || 0;
      if (item?.at > stamp) await apply(item);
      else if (!item) await push();
    } catch (_) {}
  })();

  return { KEYS, push };
})();
