// Timoneiro — avisos do mar: Torneio com inscrições abertas, Frota do Capitão e salas de expedição do barco.
// Puro: sem chrome.*. Usado pela aba do Twish (guide-sync.js) e pelo fundo (background-sync.js), que lê
// sozinho quando a aba do Twish está dormindo. A chave é a mesma nos dois: cada aviso sai uma vez só.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroSeaAlerts = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  function from(b, h, d) {
    const out = [];
    const t = d.tournament;
    if (t?.active && t.join_window_open && !t.is_participant) out.push({ type: "tournament", key: `tour|${b}|${t.id || t.started_at || Math.round(((t.seconds_remaining || 0) * 1000 + Date.now()) / 300000)}`, title: "Torneio aberto!", message: "Digite $entrar no chat: entrar zera seu cooldown e você só arrisca o peixe pescado na disputa." });
    const rooms = Array.isArray(d.expeditions?.rooms) ? d.expeditions.rooms : [];
    for (const r of rooms) {
      const owner = (r.crew || []).find((c) => c.owner)?.boat || r.boat;
      if (owner !== b || r.started || (r.state && !/lobby|open|waiting|forming|boarding/.test(r.state))) continue;
      const mine = (r.crew || []).some((c) => h && String(c.handle).toLowerCase() === h);
      if (mine) continue;
      if (r.kind === "fleet") out.push({ type: "fleet", key: `fleet|${b}|${r.id}`, title: "Frota do Capitão aberta!", message: "Viagem grátis à Baía. Digite $embarcar no chat (zarpa em até 10 min)." });
      else out.push({ type: "room", key: `room|${b}|${r.id}`, title: `Sala de expedição aberta (${r.sea || "mar"})`, message: `${(r.crew || []).length} tripulante(s) no barco ${b}. Veja no Guia se compensa.` });
    }
    return out;
  }

  return { from };
});
