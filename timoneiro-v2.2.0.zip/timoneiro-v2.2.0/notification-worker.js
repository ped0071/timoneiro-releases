"use strict";

// Timoneiro — service worker: leitura em segundo plano + notificações. Um único worker atende todas as abas.
// No Firefox o fundo é uma "event page" que já carrega estes arquivos pelo manifest (sem importScripts).
if (typeof importScripts === "function" && !globalThis.TimoneiroSync) importScripts("core/update.js", "core/keys.js", "core/sound-lock.js", "core/sea-alerts.js", "core/status.js", "core/boats.js", "core/events.js", "core/history.js", "core/forecast.js", "core/notices.js", "core/polling.js", "background-sync.js", "settings-sync.js");

// Regras anti-repetição:
//  - Pesca: um alarme marcado para a hora em que o cooldown acaba (readyAt) notifica uma vez por
//    cooldown. A passagem cooldown → liberado também notifica (cooldowns curtos), com a mesma chave.
//  - Evento (v1.9.0): lido da lista por tipo (pescaskills.events.v2). Avisa no início, quando o
//    conteúdo muda de verdade (assinatura sem contagem regressiva) e, se você ligar, quando termina.
//    Filtro por relevância (Alta/Média/Baixa) em Ajustes.
//  - Torneio e expedição: uma vez por torneio/sala/frota (lidos pelo Guia).
const FISHING_KEY = "timoneiro.fishingStatus.v1";
const EVENTS_KEY = "timoneiro.events.v2";
const GUIDE_KEY = "timoneiro.guideData.v1";
const MARKET_HITS_KEY = "timoneiro.marketHits.v1";
const SEA_KEY = "timoneiro.seaAlerts.v1"; // Torneio/Frota/sala lidos pelo fundo com a aba do Twish dormindo
const MEMO_KEY = "timoneiro.notified.v2";
const PREFS_KEY = "timoneiro.notifications.v1";
const DISCORD_KEY = "timoneiro.discord.v1";
const BOAT_KEY = "timoneiro.boat.v2";
const FISH_ALARM = "timoneiro-fishing-ready";
const CHALLENGE_KEY = "timoneiro.challenge.v1"; // verificação anti-robô do Twish (twish-status.js)
// As regras de quando avisar e com que chave estão em core/notices.js (TimoneiroNotices).
const WEBHOOK_RE = /^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+$/;
var noticeChain = Promise.resolve();
var lastForcedSync = 0;
const SOUND_LOCK = "timoneiro.soundLock.v1";
const SOUND_KEY = "timoneiro.sounds.v1";

async function memo() {
  const r = await chrome.storage.local.get(MEMO_KEY);
  return TimoneiroNotices.pruneMemo(r[MEMO_KEY], Date.now());
}

// Categoria de cada aviso: decide o que vai para o computador e o que vai para o Discord.
const CATEGORY = { "timoneiro-market": "alerts", "timoneiro-fishing": "fishing", "timoneiro-event": "event", "timoneiro-event-end": "event", "timoneiro-tournament": "alerts", "timoneiro-fleet": "alerts", "timoneiro-room": "alerts", "timoneiro-challenge": "fishing" };
// O que o clique na notificação preenche no chat (você confere e aperta Enter).
const CLICK_FILL = { "timoneiro-fishing": "$pescar", "timoneiro-tournament": "$entrar", "timoneiro-fleet": "$embarcar" };

// ---------- som (v1.11.0; desde a 2.0.20 só daqui) ----------
// O som sai sempre do fundo: num documento invisível no Chrome/Edge/Opera, ou direto na página de
// fundo no Firefox. A aba da Twitch só mostra o aviso. Antes, com a Twitch visível, a aba tocava e
// tomava a vez; com a aba silenciada ou o áudio bloqueado sem clique, o som se perdia. A trava
// evita tocar duas vezes o mesmo aviso (alarme e leitura "liberado" chegando quase juntos).
async function playSound(kind, key) {
  const r = await chrome.storage.local.get([SOUND_LOCK, SOUND_KEY]);
  const p = globalThis.TimoneiroSoundLock.plan(r[SOUND_LOCK] || {}, r[SOUND_KEY], kind, key, Date.now());
  if (!p.play) { await soundLog({ kind, key, ...p.log }); return false; }
  await chrome.storage.local.set({ [SOUND_LOCK]: p.lock });
  const out = await playAssetWhy(p.asset, p.volume);
  await soundLog({ kind, key, result: out.ok ? "tocou" : "falhou", why: out.why || null });
  return out.ok;
}
async function playAsset(asset, volume) { return (await playAssetWhy(asset, volume)).ok; }
async function playAssetWhy(asset, volume) {
  try {
    if (typeof Audio === "function") { const a = new Audio(chrome.runtime.getURL(`assets/${asset}`)); a.volume = volume; await a.play(); return { ok: true }; }
    if (!chrome.offscreen) return { ok: false, why: "sem documento invisível" };
    const has = chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : false;
    let made = null;
    if (!has) made = await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["AUDIO_PLAYBACK"], justification: "Tocar o aviso de pesca e de evento quando a Twitch não está visível." }).then(() => null, (e) => String(e?.message || e));
    const res = await chrome.runtime.sendMessage({ type: "timoneiro-play", asset, volume }).catch((e) => ({ err: String(e?.message || e) }));
    if (res === true) return { ok: true };
    return { ok: false, why: res?.err || made || (res === false ? "o navegador bloqueou o áudio" : "o documento invisível não respondeu") };
  } catch (e) { return { ok: false, why: String(e?.message || e) }; }
}
// Últimas tentativas de som (Guia → Diagnóstico): mostra onde um aviso ficou mudo.
async function soundLog(e) {
  try {
    const L = globalThis.TimoneiroSoundLock;
    const r = await chrome.storage.local.get(L.LOG);
    await chrome.storage.local.set({ [L.LOG]: L.log(r[L.LOG], { at: Date.now(), who: "fundo", ...e }) });
  } catch (_) {}
}

async function notify(id, title, message, { desktop = true, sound = null } = {}) {
  if (sound) playSound(...sound).catch(() => {});
  if (desktop) {
    try {
      await chrome.notifications.create(`${id}-${Date.now()}`, { type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), title, message, silent: true });
    } catch (error) { console.warn("Timoneiro: não foi possível mostrar a notificação.", error); }
    toTwitchTabs({ type: "timoneiro-notice", id, title, message, key: TimoneiroNotices.noticeKey(sound) }).catch(() => {});
  }
  await postDiscord(id, title, message);
}

// Com a Twitch na tela, o aviso aparece também na página (chat/alerts.js). Alguns sistemas não mostram
// a notificação do navegador em foco, e no Windows ela some de vez com as notificações desligadas.
async function toTwitchTabs(msg) {
  const tabs = await chrome.tabs.query({ url: ["https://www.twitch.tv/*"] });
  await Promise.all(tabs.filter((t) => t.id && !t.discarded).map((t) => chrome.tabs.sendMessage(t.id, msg).catch(() => {})));
}

// ---------- Discord (opcional) ----------
async function postDiscord(id, title, message, { test = false } = {}) {
  const cfg = (await chrome.storage.local.get(DISCORD_KEY))[DISCORD_KEY];
  const url = String(cfg?.url || "").trim();
  if (!WEBHOOK_RE.test(url)) return test ? { ok: false, error: "URL de webhook inválida." } : null;
  // Desde a 2.0 o Discord é permissão opcional: sem ela, não envia (quem vem da 1.x precisa permitir em Opções).
  const allowed = await chrome.permissions.contains({ origins: ["https://discord.com/api/webhooks/*", "https://discordapp.com/api/webhooks/*"] }).catch(() => false);
  if (!allowed) return test ? { ok: false, error: "Falta permitir o Discord: abra Opções do Timoneiro e clique em Salvar." } : null;
  const cat = CATEGORY[id] || "alerts";
  if (!test && cfg[cat] !== true) return null;
  const body = JSON.stringify({ username: "Timoneiro", content: `**${title}**\n${message}`.slice(0, 1900), allowed_mentions: { parse: [] } });
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body, signal: AbortSignal.timeout(10000) });
      if (r.ok) return { ok: true };
      if (r.status === 429 && attempt === 0) { await new Promise((ok) => setTimeout(ok, Math.min(15, Number(r.headers.get("Retry-After")) || 3) * 1000)); continue; }
      return { ok: false, error: r.status === 404 || r.status === 401 ? "O Discord não reconheceu esse webhook (apagado ou copiado pela metade)." : `O Discord respondeu ${r.status}.` };
    } catch (_) { return { ok: false, error: "Sem resposta do Discord." }; }
  }
  return { ok: false, error: "O Discord pediu para esperar. Tente de novo." };
}

// ---------- avisos (as regras estão em core/notices.js) ----------
// Aqui ficam só os efeitos: ler e gravar o memo (uma vez), alarmes, registro do som e notificar.
async function onStoredChange(changes, area) {
  if (area !== "local") return;
  if (!changes[FISHING_KEY] && !changes[CHALLENGE_KEY] && !changes[EVENTS_KEY] && !changes[GUIDE_KEY] && !changes[MARKET_HITS_KEY] && !changes[SEA_KEY]) return;
  const prefs = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  const discord = (await chrome.storage.local.get(DISCORD_KEY))[DISCORD_KEY] || {};
  const m = await memo();
  const now = Date.now();
  const notices = [];
  const N = TimoneiroNotices;

  const read = N.fishingRead(changes[FISHING_KEY]?.newValue, m.fishing, now);
  if (read.type === "cooldown") {
    if (read.arm) { try { await chrome.alarms.create(FISH_ALARM, { when: read.alarmAt }); } catch (_) {} }
    m.fishing = read.next;
  } else if (read.type === "ready") {
    // Só aqui lê o que segura o aviso (gelo, verificação), como sempre.
    const hold = await holdUntil(now);
    if (hold) await deferForIce(m, read.boat, hold);
    else {
      const f = N.fishingNotice(m.keys, read.boat, read.readyAt, prefs, now);
      if (f.send) notices.push(f.notice);
      m.fishing = read.next;
    }
  } else if (read.type === "available") m.fishing = read.next;
  // "frozen": lago congelado, o aviso já está marcado para o degelo.

  const ch = changes[CHALLENGE_KEY]?.newValue;
  if (ch) {
    const until = globalThis.TimoneiroStatus?.challengeHold(ch, now);
    const step = N.challengeStep(ch, until, m.fishing, m.keys, prefs, now);
    if (step.notice) notices.push(step.notice);
    if (step.defer) await deferForIce(m, m.fishing.boat, step.defer);
    if (step.release) {
      m.fishing.readyAt = step.release.readyAt;
      try { await chrome.alarms.create(FISH_ALARM, { when: step.release.alarmAt }); } catch (_) {}
    }
  }

  const events = changes[EVENTS_KEY]?.newValue;
  if (N.freshEvents(events, now)) notices.push(...N.events(events.list, events.boat, m, prefs, now));

  // Torneio, Frota e sala: da aba do Twish (Guia) ou do fundo. A chave é a mesma: avisa uma vez só.
  notices.push(...N.seaNotices(changes[GUIDE_KEY]?.newValue?.alerts, changes[SEA_KEY]?.newValue, m.keys, prefs, now));

  const market = changes[MARKET_HITS_KEY]?.newValue;
  if (market?.hits) notices.push(...N.marketNotices(market.hits, m.keys, prefs, now));

  await chrome.storage.local.set({ [MEMO_KEY]: m });
  for (const [id, title, message, opts] of notices) await notify(id, title, message, opts);
}

// Lago congelado (Barco Misterioso com Bergelmir pago): ninguém pesca até o efeito acabar. O aviso de
// pesca fica marcado para o degelo, em vez de tocar no meio do gelo.
async function frozenUntil(now = Date.now()) {
  const ev = (await chrome.storage.local.get(EVENTS_KEY))[EVENTS_KEY];
  return globalThis.TimoneiroEvents?.frozenUntil(ev?.list || [], now) || null;
}
// Verificação anti-robô pendente ou pesca bloqueada: $pescar não pesca e insistir custa twishcoins.
async function challengeUntil(now = Date.now()) {
  const ch = (await chrome.storage.local.get(CHALLENGE_KEY))[CHALLENGE_KEY];
  return globalThis.TimoneiroStatus?.challengeHold(ch, now) || null;
}
// O que segura o aviso de pesca agora (o que durar mais): {until, why} ou null.
async function holdUntil(now = Date.now()) {
  const ice = await frozenUntil(now), ch = await challengeUntil(now);
  return TimoneiroNotices.pickHold(ice, ch);
}
async function deferForIce(m, boat, hold) {
  const d = TimoneiroNotices.deferFishing(m.fishing, boat, hold, Date.now());
  m.fishing = d.fishing;
  try { await chrome.alarms.create(FISH_ALARM, { when: d.alarmAt }); } catch (_) {}
  const hhmm = new Date(hold.until).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  await soundLog({ kind: "fishing", result: "adiado", why: `${d.why} até ${hhmm}` });
}

// Alarme na hora em que o cooldown acaba.
async function onFishAlarm() {
  const r = await chrome.storage.local.get([FISHING_KEY, PREFS_KEY, DISCORD_KEY]);
  const prefs = r[PREFS_KEY] || {};
  const st = r[FISHING_KEY];
  const m = await memo();
  // o cooldown ainda é o mesmo que armou o alarme e já venceu?
  const check = TimoneiroNotices.alarmCheck(m.fishing, st, Date.now());
  if (!check.ok) {
    if (check.log) await soundLog({ kind: "fishing", result: "alarme ignorado", why: check.log });
    return;
  }
  const hold = await holdUntil(Date.now());
  if (hold) { await deferForIce(m, m.fishing.boat, hold); await chrome.storage.local.set({ [MEMO_KEY]: m }); return; }
  const f = TimoneiroNotices.fishingNotice(m.keys, m.fishing.boat, check.ready, prefs, Date.now());
  await chrome.storage.local.set({ [MEMO_KEY]: m });
  if (!f.send) await soundLog({ kind: "fishing", key: f.key, result: "alarme: já avisado" });
  if (f.send) await notify(...f.notice);
}
chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name !== FISH_ALARM) return;
  noticeChain = noticeChain.then(onFishAlarm).catch((e) => console.warn("Timoneiro: alarme de pesca.", e));
});

chrome.storage.onChanged.addListener((changes, area) => {
  noticeChain = noticeChain.then(() => onStoredChange(changes, area)).catch(error => {
    console.warn("Timoneiro: falha ao acompanhar notificações.", error);
  });
});

// ---------- clique na notificação: abre o chat e preenche o comando ----------
async function openChat(fill) {
  const r = await chrome.storage.local.get(BOAT_KEY);
  const channel = r[BOAT_KEY]?.boat || null;
  // Ainda sem barco (pessoa nova): abre o Twish para escolher um.
  if (!channel) { await chrome.tabs.create({ url: "https://twish.com.br/" }); return null; }
  const tabs = await chrome.tabs.query({ url: ["https://www.twitch.tv/*"] });
  const re = new RegExp(`^https://www\\.twitch\\.tv/(?:popout/|moderator/)?${channel.replace(/[^a-z0-9_]/gi, "")}(?:[/?#]|$)`, "i");
  let tab = tabs.find((t) => re.test(t.url || ""));
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    tab = await chrome.tabs.create({ url: `https://www.twitch.tv/${channel}` });
  }
  if (!fill) return tab;
  // A página nova leva alguns segundos para montar o chat; tenta algumas vezes.
  for (let i = 0; i < 8; i++) {
    try { const ok = await chrome.tabs.sendMessage(tab.id, { type: "timoneiro-fill", command: fill }); if (ok) return tab; } catch (_) {}
    await new Promise((ok) => setTimeout(ok, 1500));
  }
}
// ---------- versão nova: selo "!" no ícone e uma notificação por versão ----------
// O aviso guardado só vale se a versão for maior que a instalada agora: depois de atualizar, some sozinho.
const UPDATE_KEY = "timoneiro.update.v1", UPDATE_NOTIFIED = "timoneiro.updateNotified.v1";
async function updateSignals() {
  const r = await chrome.storage.local.get([UPDATE_KEY, UPDATE_NOTIFIED]);
  const s = TimoneiroUpdate.signals(r[UPDATE_KEY], chrome.runtime.getManifest().version, r[UPDATE_NOTIFIED]);
  const action = chrome.action || chrome.browserAction;
  if (action) {
    try {
      await action.setBadgeText({ text: s.badge });
      if (s.badge) { await action.setBadgeBackgroundColor({ color: "#d93a4a" }); await action.setBadgeTextColor?.({ color: "#ffffff" }); }
      await action.setTitle({ title: s.title });
    } catch (_) {}
  }
  if (!s.notify) return;
  await chrome.storage.local.set({ [UPDATE_NOTIFIED]: s.markNotified });
  await chrome.notifications.create(s.notify.id, {
    type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), requireInteraction: true,
    title: s.notify.title,
    message: s.notify.message,
  }).catch(() => {});
}
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes[UPDATE_KEY]) updateSignals().catch(() => {}); });
chrome.runtime.onStartup?.addListener(() => updateSignals().catch(() => {}));
chrome.runtime.onInstalled.addListener(() => updateSignals().catch(() => {}));
updateSignals().catch(() => {});

// Abrir a página de atualização (pedido da barra, do menu e do Guia na Twitch).
function openUpdatePage() { return chrome.tabs.create({ url: chrome.runtime.getURL("pages/update.html") }); }
chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith("timoneiro-update-")) { chrome.notifications.clear(notificationId); chrome.tabs.create({ url: chrome.runtime.getURL("pages/update.html") }); return; }
  const id = Object.keys(CATEGORY).find((k) => notificationId.startsWith(`${k}-`));
  if (!id) return;
  chrome.notifications.clear(notificationId);
  if (id === "timoneiro-challenge") { chrome.tabs.create({ url: "https://twish.com.br/verificacao" }); return; }
  if (id === "timoneiro-market") { chrome.storage.local.get(BOAT_KEY).then((r) => chrome.tabs.create({ url: r[BOAT_KEY]?.boat ? `https://twish.com.br/c/${encodeURIComponent(r[BOAT_KEY].boat)}/market` : "https://twish.com.br/" })); return; }
  openChat(CLICK_FILL[id]).catch((e) => console.warn("Timoneiro: não foi possível abrir o chat.", e));
});

// ---------- mensagens das abas ----------
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  // Só mensagens do próprio Timoneiro (abas com os content scripts e páginas da extensão).
  if (_sender?.id !== chrome.runtime.id) return false;
  if (msg?.type === "timoneiro-cast") { TimoneiroSync.afterCast(); return false; }
  if (msg?.type === "timoneiro-sync-now") {
    // Pedido da Twitch (aba voltou a ficar visível, Guia aberto): no máximo 1 leitura completa a cada 15 s.
    if (Date.now() - lastForcedSync < 15000) { reply({ ok: true, skipped: true }); return false; }
    lastForcedSync = Date.now();
    TimoneiroSync.syncOnce({ force: true }).then(() => reply({ ok: true }), () => reply({ ok: false })); return true;
  }
  if (msg?.type === "timoneiro-check-update") { TimoneiroSync.checkUpdate({ force: true }).then(reply, () => reply(null)); return true; }
  if (msg?.type === "timoneiro-open-options") { chrome.runtime.openOptionsPage().catch(() => {}); return false; }
  if (msg?.type === "timoneiro-open-update") { openUpdatePage().catch(() => {}); return false; }
  if (msg?.type === "timoneiro-open-chat") { openChat(null).then(() => reply({ ok: true }), () => reply({ ok: false })); return true; }
  if (msg?.type === "timoneiro-open-guide") {
    // Popup: foca a live do barco e abre o Guia nela.
    (async () => {
      const tab = await openChat(null);
      for (let i = 0; tab && i < 8; i++) {
        try { if (await chrome.tabs.sendMessage(tab.id, { type: "timoneiro-open-guide" })) break; } catch (_) {}
        await new Promise((ok) => setTimeout(ok, 1500));
      }
      reply({ ok: !!tab });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-sync-events") { TimoneiroSync.syncOnce(); return false; }
  if (msg?.type === "timoneiro-channels-refresh") {
    // A aba da Twitch abriu um canal que não está na lista guardada: confere a lista pública.
    TimoneiroSync.refreshChannels({ channel: TimoneiroBoats.slug(msg.channel) || null }).then(() => reply({ ok: true }), () => reply({ ok: false })); return true;
  }
  if (msg?.type === "timoneiro-keep-tab" && _sender?.tab?.id != null) {
    // A aba que ouve o tempo real não pode ser descarregada pela economia de memória do navegador.
    chrome.tabs.update(_sender.tab.id, { autoDiscardable: !msg.on }).catch(() => {});
    return false;
  }
  if (msg?.type === "timoneiro-diagnostics") {
    (async () => {
      const level = chrome.notifications.getPermissionLevel ? await new Promise((ok) => chrome.notifications.getPermissionLevel(ok)) : "granted";
      const alarms = await chrome.alarms.getAll();
      reply({ notifications: level, alarms: alarms.map((a) => ({ name: a.name, period: a.periodInMinutes || null, next: a.scheduledTime })), offscreen: !!chrome.offscreen, audio: typeof Audio === "function", version: chrome.runtime.getManifest().version, ua: navigator.userAgent });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-test-alert") {
    (async () => {
      await chrome.notifications.create(`timoneiro-test-${Date.now()}`, { type: "basic", iconUrl: chrome.runtime.getURL("assets/timoneiro-logo.png"), title: "Teste do Timoneiro", message: "Se você viu esta notificação e ouviu o som, os avisos funcionam em outra aba.", silent: true }).catch(() => {});
      const r = (await chrome.storage.local.get(SOUND_KEY))[SOUND_KEY] || {};
      const played = await playAsset("sounds/pesca.wav", ((r.fishingAlert?.volume) || 7) / 10);
      reply({ ok: true, played });
    })();
    return true;
  }
  if (msg?.type === "timoneiro-discord-test") { postDiscord("timoneiro-event", "Teste do Timoneiro", "Se você está lendo isto, os avisos vão chegar aqui.", { test: true }).then(reply); return true; }
  return false;
});

// ---------- primeira instalação: página de boas-vindas ----------
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("pages/welcome.html") }).catch(() => {}); });

// ---------- instalou ou atualizou: os scripts entram nas abas já abertas ----------
// O navegador não põe os scripts novos em abas que já estavam abertas, e os antigos param (core/alive.js
// tira a barra velha). Aqui a versão nova entra na hora, sem precisar recarregar a Twitch e o Twish.
async function injectOpenTabs() {
  for (const cs of chrome.runtime.getManifest().content_scripts || []) {
    let tabs = [];
    try { tabs = await chrome.tabs.query({ url: cs.matches }); } catch (_) { continue; }
    for (const t of tabs) {
      if (t.discarded || !t.id) continue;
      const target = { tabId: t.id, allFrames: !!cs.all_frames };
      try {
        if (cs.css?.length) await chrome.scripting.insertCSS({ target, files: cs.css });
        await chrome.scripting.executeScript({ target, files: cs.js });
      } catch (_) { /* aba carregando ou sem acesso: ela recebe os scripts ao recarregar */ }
    }
  }
}
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "install" || d.reason === "update") injectOpenTabs(); });

// ---------- pasta descompactada: arquivos novos no disco → recarrega sozinho ----------
// Quem atualiza extraindo o zip por cima da pasta (ou pelo ajudante) não precisa clicar em
// Recarregar: o fundo lê o manifest.json do disco e, se a versão for maior e o arquivo estiver
// inteiro, recarrega a extensão. Confere a cada 5 min, e a cada 1 min com a página de atualização aberta.
var TimoneiroFiles = (() => {
  const ALARM = "timoneiro-files", WATCH = "timoneiro.watchFiles.v1", PENDING = "timoneiro.filesPending.v1";
  async function unpacked() {
    try { return (await chrome.management.getSelf()).installType === "development"; } catch (_) { return !("update_url" in chrome.runtime.getManifest()); }
  }
  async function check() {
    if (!(await unpacked())) return "loja";
    let disk = null;
    try { disk = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json(); } catch (_) { return "incompleto"; }
    if (!disk || !/^\d+(\.\d+){1,3}$/.test(disk.version || "") || !disk.background) return "incompleto";
    if (TimoneiroUpdate.compare(disk.version, chrome.runtime.getManifest().version) <= 0) return "igual";
    // Quem extrai o zip por cima pode ter o manifest novo antes dos outros arquivos: só recarrega
    // quando a mesma versão nova continua lá pelo menos 15 s depois (confere de novo em 30 s).
    const p = (await chrome.storage.local.get(PENDING))[PENDING];
    if (!p || p.version !== disk.version) {
      await chrome.storage.local.set({ [PENDING]: { version: disk.version, at: Date.now() } });
      chrome.alarms.create(ALARM + "-confirmar", { delayInMinutes: 0.5 });
      return "conferindo";
    }
    if (Date.now() - p.at < 15e3) return "conferindo";
    await chrome.storage.local.remove(PENDING);
    chrome.runtime.reload();
    return "recarregando";
  }
  async function schedule() {
    const w = (await chrome.storage.local.get(WATCH))[WATCH] || 0;
    const fast = Date.now() < w;
    const a = await chrome.alarms.get(ALARM);
    const period = fast ? 1 : 5;
    if (!a || a.periodInMinutes !== period) await chrome.alarms.create(ALARM, { delayInMinutes: period, periodInMinutes: period });
  }
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM || a.name === ALARM + "-confirmar") check().then(schedule).catch(() => {}); });
  chrome.runtime.onMessage.addListener((msg, sender) => {
    if (sender?.id !== chrome.runtime.id || msg?.type !== "timoneiro-watch-files") return false;
    chrome.storage.local.set({ [WATCH]: msg.on ? Date.now() + 30 * 60e3 : 0 }).then(schedule);
    return false;
  });
  schedule();
  return { check, schedule };
})();
