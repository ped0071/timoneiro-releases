// Timoneiro — leitura na aba do Twish. Só a aba líder (tab-leader.js) lê e publica.
// Publica no chrome.storage: pesca (cooldown com a hora em que libera), evento ativo, histórico
// do dia e os dados da conta para o Guia e os seletores. Só GET, com a sessão do próprio site.
(() => {
  "use strict";
  const St = globalThis.TimoneiroStatus;
  const Boat = globalThis.TimoneiroBoat;
  const Leader = globalThis.TimoneiroLeader;
  const Read = globalThis.TimoneiroTwishRead;
  if (!St || !Boat || !Leader || !Read || !chrome?.storage?.local) return;

  const KEY = {
    fishing: "timoneiro.fishingStatus.v1",
    event: "timoneiro.eventStatus.v1",
    smart: "timoneiro.smartData.v1",
    history: "timoneiro.eventHistory.v1",
    sync: "timoneiro.syncStatus.v1",
    syncReq: "timoneiro.syncRequest.v1",
    challenge: "timoneiro.challenge.v1",
  };
  const leading = () => Leader.isLeader();
  const save = (obj) => chrome.storage.local.set(obj).catch(() => {});

  async function getJson(path, timeout) {
    const base = Boat.apiBase();
    if (!base) throw Object.assign(new Error("sem barco"), { status: 0 });
    const r = await fetch(base + path, { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(timeout) });
    if (!r.ok) throw Object.assign(new Error(`${path} ${r.status}`), { status: r.status });
    return r.json();
  }

  // ---------- pesca ----------
  // Fonte principal: /me. O título da aba ("(4:59) ...") percebe na hora quando você pescou:
  // se ele muda de estado, relê /me. O título só manda quando /me está velho ou desatualizado.
  const fish = { api: null, apiAt: 0, busy: false, titleState: null, titleAt: 0, refetchAt: 0, readyAt: null, sig: "", publishedAt: 0 };

  async function readFishing() {
    if (!leading() || fish.busy) return;
    fish.busy = true;
    const at = Date.now();
    try {
      const hit = Read.cooldownIn(await getJson("/me", 8000), Date.now());
      if (hit) { fish.api = hit; fish.apiAt = at; pushFishing(); }
    } catch (_) { /* tenta de novo no próximo ciclo */ } finally { fish.busy = false; }
  }

  function pushFishing(force = false) {
    if (!leading()) return;
    const now = Date.now();
    const r = Read.fishingStep(fish, { title: document.title, api: fish.api, apiAt: fish.apiAt, now, force });
    Object.assign(fish, r.state);
    if (r.refetch) setTimeout(readFishing, 300);
    if (r.publish) save({ [KEY.fishing]: { ...r.publish, source: "twish", boat: Boat.get(), updatedAt: now } });
  }

  // ---------- evento ----------
  const ev = { data: null, at: 0, busy: false, last: null, lastAt: 0, emptyReads: 0, emptyReadAt: 0, endsAt: null, sig: "", publishedAt: 0 };

  async function readEvents() {
    if (!leading() || ev.busy) return;
    ev.busy = true;
    const at = Date.now();
    try {
      const data = await getJson("/events/active", 10000);
      if (St.eventFromApi(data, at) === null) return;
      const seen = Read.eventsSeen(data, at);
      const saved = (await chrome.storage.local.get(KEY.history))[KEY.history];
      await save({ [KEY.history]: St.historyUpdate(saved, seen, at) });
      ev.data = data; ev.at = at;
      pushEvent(true);
    } catch (_) { /* sem leitura nova: o último estado continua até vencer */ } finally { ev.busy = false; }
  }

  function pushEvent(force = false) {
    if (!leading() || !ev.at) return;
    const now = Date.now();
    const r = Read.eventStep(ev, { data: ev.data, at: ev.at, now, force });
    Object.assign(ev, r.state);
    if (r.publish) save({ [KEY.event]: { ...r.publish, boat: Boat.get(), updatedAt: now } });
  }

  // ---------- dados da conta (Guia e seletores) ----------
  const acct = { busy: false, pausedUntil: 0 };
  async function readAccount() {
    if (acct.busy || Date.now() < acct.pausedUntil || !leading()) return;
    acct.busy = true;
    const boat = Boat.get();
    try {
      const parts = { me: "/me", inventory: "/me/inventory", shop: "/shop", titles: "/titles" };
      const got = await Promise.all(Object.entries(parts).map(async ([k, p]) => [k, await getJson(p, 10000)]));
      if (Boat.get() !== boat) return; // trocou de barco no meio
      await save({ [KEY.smart]: Read.smartRecord(boat, got, Date.now()) });
      await save({ [KEY.sync]: { state: "ok", boat, at: Date.now() } });
    } catch (e) {
      const f = Read.accountFailure(e && e.status, boat, Date.now(), acct.pausedUntil);
      acct.pausedUntil = f.pausedUntil;
      await save({ [KEY.sync]: f.record });
    } finally { acct.busy = false; }
  }

  // ---------- verificação anti-robô ----------
  // /api/me/challenge é da conta (não do barco). O site lê no máximo 1 vez por minuto; o aviso
  // challenge_changed do tempo real dá o prazo na hora. Enquanto durar, o fundo segura o "pode pescar".
  const chal = { busy: false, at: 0, last: null, timer: null };
  function saveChallenge(c) {
    const same = Read.sameChallenge(chal.last, c);
    chal.last = c;
    if (!same) save({ [KEY.challenge]: c });
  }
  async function readChallenge(force = false) {
    if (!leading() || chal.busy) return;
    const now = Date.now();
    const gate = Read.challengeGate(chal.at, now, force);
    if (!gate.go) { if (gate.retryIn != null && !chal.timer) chal.timer = setTimeout(() => { chal.timer = null; readChallenge(true); }, gate.retryIn); return; }
    chal.busy = true; chal.at = now;
    try {
      const r = await fetch(new URL("/api/me/challenge", location.origin), { credentials: "same-origin", cache: "no-store", signal: AbortSignal.timeout(8000) });
      if (r.ok) saveChallenge(St.challengeFrom(await r.json(), Date.now()));
    } catch (_) { /* tenta de novo no próximo minuto */ } finally { chal.busy = false; }
  }

  const readAll = () => { readAccount(); readEvents(); readFishing(); readChallenge(); };

  // Tempo real (twish-realtime.js): o servidor avisa e a aba relê ou publica na hora.
  globalThis.TimoneiroTwish = {
    refetchFishing: readFishing,
    refetchEvents: readEvents,
    refetchAccount: readAccount,
    // challenge_changed{seconds_left}: o prazo chega na hora; a leitura confirma o estado (e o bloqueio).
    setChallenge(secondsLeft, at = Date.now()) {
      if (!leading()) return;
      if (Number.isFinite(secondsLeft) && secondsLeft > 0) saveChallenge(St.challengeFrom({ state: "pending", seconds_left: secondsLeft }, at));
      readChallenge(true);
    },
    setCooldown(remaining, at = Date.now()) {
      if (!leading() || !Number.isFinite(remaining)) return;
      fish.api = { cooldown_remaining: Math.max(0, remaining) }; fish.apiAt = at; fish.sig = "";
      pushFishing(true);
    },
  };

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY.syncReq]) { readAccount(); readEvents(); }
  });
  Boat.onChange(() => {
    chrome.storage.local.remove([KEY.smart, KEY.event]).catch(() => {});
    Object.assign(ev, Read.eventBoatReset(ev));
    readAccount(); readEvents();
  });
  Leader.onChange((on) => { if (on) readAll(); });

  Boat.ready.then(() => Boat.adoptFromUrl(location.pathname)).then(() => Leader.ready).then(() => {
    pushFishing(true); pushEvent(true);
    readAll();
  });

  const titleEl = document.querySelector("title");
  if (titleEl) new MutationObserver(() => pushFishing()).observe(titleEl, { childList: true, characterData: true, subtree: true });

  setInterval(() => { pushFishing(true); pushEvent(true); }, 1000);
  setInterval(readAccount, 30e3);
  // Comprador do Porto no ar: vender pelo chat não gera aviso do tempo real, então o inventário é relido a
  // cada 8 s enquanto ele durar (o 429 segue pausando).
  setInterval(() => { if (ev.data?.event?.kind === "species_buyer" && Date.now() - ev.at < 120e3) readAccount(); }, 8e3);
  setInterval(readEvents, 15e3);
  setInterval(readFishing, 20e3);
  setInterval(readChallenge, 60e3);
  addEventListener("pagehide", () => { if (leading()) chrome.storage.local.remove([KEY.fishing, KEY.event]).catch(() => {}); }, { once: true });
})();
