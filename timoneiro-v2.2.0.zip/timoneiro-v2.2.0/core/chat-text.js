// Timoneiro — regras do texto do chat: conferir o que está escrito e o registro do Arremesso.
// Puro: sem DOM, chrome.* nem relógio. Usado por chat/insert.js e chat/menu.js (e pelo Almirante via require).
// Escrever no campo e enviar ficam em chat/insert.js.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroChatText = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  // O editor da Twitch (Slate) põe caracteres invisíveis e espaço duro no texto.
  // Diferente da busca de comandos: aqui letra maiúscula e acento continuam como estão.
  const INVISIBLE = /[​-‍﻿]/g, HARD_SPACE = / /g;
  const clean = (t) => String(t || "").replace(INVISIBLE, "").replace(HARD_SPACE, " ").trim();
  const matches = (current, cmd) => clean(current) === cmd.trim();

  // Comando que o fundo pode pedir para escrever: uma palavra só, como "$pescar".
  const isFillable = (cmd) => typeof cmd === "string" && /^\$[a-z]+$/i.test(cmd);
  // O texto do chat é um $pescar (só observa o envio; não envia nada).
  const isCast = (text) => /^\s*\$pescar\b/i.test(text);

  // ---------- registro dos cliques no 🎣 (diagnóstico do Arremesso) ----------
  const CAST_LOG = "timoneiro.castLog.v1", LOG_MAX = 12;
  const LABELS = {
    sent: "enviado", off: "Arremesso desligado", busy: "já estava enviando",
    recent: "esperando o Twish confirmar a pescaria anterior (10 s)", "no-editor": "campo do chat não encontrado",
    changed: "o texto do chat mudou antes de enviar", "no-send": "a Twitch não aceitou o envio (o $pescar ficou no chat)",
    cooldown: "a pesca ainda não liberou", unknown: "tempo da pesca desconhecido (abra o Twish neste navegador)",
    error: "erro ao enviar",
  };
  const DETAILS = ["fish", "left", "how", "error"], DETAIL_MAX = 80;

  function castEntry(result, info = {}, now) {
    const entry = { at: now, result };
    const extra = info || {};
    DETAILS.forEach((k) => { if (extra[k] != null) entry[k] = String(extra[k]).slice(0, DETAIL_MAX); });
    return entry;
  }
  const pushLog = (prev, entry, max = LOG_MAX) => [entry].concat(Array.isArray(prev) ? prev : []).slice(0, max);

  const resultLabel = (r) => LABELS[r] || r;
  function castLabel(e) {
    let out = resultLabel(e.result);
    if (e.result === "cooldown" && e.left) out += ` (falta ${e.left})`;
    if (e.how) out += ` · ${e.how}`;
    return out;
  }

  return { clean, matches, isFillable, isCast, CAST_LOG, LOG_MAX, LABELS, castEntry, pushLog, castLabel, resultLabel };
});
