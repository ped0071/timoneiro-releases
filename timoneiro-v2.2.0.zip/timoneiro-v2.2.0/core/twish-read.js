// Timoneiro — leitura da aba do Twish: as decisões de twish-status.js como funções puras.
// O estado (pesca, evento) entra e sai como objeto simples; o tempo entra como `now`.
// Quem chama guarda o estado, aplica o que voltou e faz os efeitos (timers, storage, barco).
// Depende de core/status.js (TimoneiroStatus), que carrega antes.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroTwishRead = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const REPUBLISH_MS = 10e3; // o mesmo estado só é regravado a cada 10 s (validade de 30 s)
  const status = () => globalThis.TimoneiroStatus || require("./status.js");

  const COUNT_KEYS = ["cooldown_remaining", "cooldown_seconds", "fishing_cooldown_remaining", "cast_cooldown_remaining"];
  const TIME_KEYS = ["next_cast_at", "cooldown_until", "can_fish_at"];

  // Cooldown dentro da resposta de /me: o nome do campo já mudou algumas vezes no Twish.
  function cooldownIn(data, now, depth = 0) {
    if (!data || typeof data !== "object" || depth > 3) return null;
    for (const k of COUNT_KEYS) {
      if (Number.isFinite(data[k])) return { cooldown_remaining: data[k] };
    }
    for (const k of TIME_KEYS) {
      const v = data[k];
      const when = typeof v === "number" ? (v > 1e12 ? v : v * 1000) : typeof v === "string" ? Date.parse(v) : NaN;
      if (Number.isFinite(when)) return { cooldown_remaining: Math.max(0, (when - now) / 1000) };
    }
    for (const v of Object.values(data)) {
      if (v && typeof v === "object" && !Array.isArray(v)) {
        const found = cooldownIn(v, now, depth + 1);
        if (found) return found;
      }
    }
    return null;
  }

  // Pesca: junta /me e o título da aba. Devolve o estado novo inteiro, se precisa reler /me
  // e o que publicar (ou null).
  function fishingStep(prev, { title, api, apiAt, now, force = false }) {
    const St = status();
    const state = { ...prev };
    const byTitle = St.fishingFromTitle(title, now);
    const byApi = St.fishingFromApi(api, apiAt, now);
    const apiRecent = !!byApi && now - apiAt < 60e3;
    let refetch = false;

    if (byTitle.status !== state.titleState) {
      if (state.titleState !== null && now - state.refetchAt > 4000) { state.refetchAt = now; refetch = true; }
      state.titleState = byTitle.status;
      state.titleAt = now;
    }

    let pick = null;
    if (apiRecent) pick = { ...byApi, via: "api" };
    else if (byTitle.status !== "unknown") pick = { ...byTitle, via: "title" };
    else if (byApi) pick = { ...byApi, via: "api" };
    if (!pick) return { state, refetch, publish: null };
    // Pescou depois da última leitura: /me ainda diz liberado, mas o título já conta.
    if (apiRecent && byApi.status === "available" && byTitle.status === "cooldown" && apiAt < state.titleAt) pick = { ...byTitle, via: "title" };
    if (pick.status === "available") pick.readyAt = byApi && byApi.status === "available" ? Math.min(byApi.readyAt, now) : now;
    // O título tem só segundos inteiros: a hora de liberar não balança.
    if (pick.status === "cooldown" && state.readyAt && Math.abs(pick.readyAt - state.readyAt) < 2500) pick.readyAt = state.readyAt;

    const sig = pick.status + "|" + (pick.status === "cooldown" ? Math.round(pick.readyAt / 1000) : "");
    if (sig === state.sig && !(force && now - state.publishedAt >= REPUBLISH_MS)) return { state, refetch, publish: null };
    state.sig = sig;
    state.publishedAt = now;
    state.readyAt = pick.status === "cooldown" ? pick.readyAt : null;
    return { state, refetch, publish: { status: pick.status, cooldown: pick.cooldown || null, readyAt: pick.readyAt, via: pick.via } };
  }

  function eventSig(cur, endsAt) {
    if (!cur.active) return "off";
    const also = (cur.also || []).map((a) => [a.name, a.description, Math.round((a.endsAt || 0) / 3000), a.progressCount, a.health?.left]);
    return [cur.name, cur.description, endsAt ?? cur.remaining, cur.kind, cur.apiKind, cur.progressCount, cur.progressTarget, cur.health?.left, JSON.stringify(also)].join("|");
  }

  // Evento, com o anti-pisca: "sem evento" no meio de um evento só vale na 2ª leitura seguida, e
  // leitura que falhou nunca vira "sem evento". Devolve o estado novo inteiro e o que publicar.
  function eventStep(prev, { data, at, now, force = false }) {
    if (!at) return { state: prev, publish: null };
    const St = status();
    const state = { ...prev };
    let cur = St.eventFromApi(data, at, now);
    const last = state.last;
    const stillRunning = last && last.active && Number.isFinite(last.endsAt) && last.endsAt > now + 5000;
    if (cur && !cur.active && stillRunning) {
      // conta uma vez por leitura: o tick de 1 s repete o mesmo `at`
      if (state.emptyReadAt !== at) { state.emptyReads++; state.emptyReadAt = at; }
      if (state.emptyReads < 2) cur = last;
    } else if (cur && cur.active) state.emptyReads = 0;

    if (cur) { state.last = cur; state.lastAt = now; }
    else if (last && now - state.lastAt < 60e3) cur = last.active && Number.isFinite(last.endsAt) && last.endsAt <= now ? { active: false } : last;
    else return { state, publish: null };

    // A API manda segundos inteiros: até 3 s de diferença é o mesmo fim.
    if (Number.isFinite(cur.endsAt) && Number.isFinite(state.endsAt) && Math.abs(cur.endsAt - state.endsAt) < 3000) cur = { ...cur, endsAt: state.endsAt };
    state.endsAt = Number.isFinite(cur.endsAt) ? cur.endsAt : null;
    const sig = eventSig(cur, state.endsAt);
    if (sig === state.sig && !(force && now - state.publishedAt >= REPUBLISH_MS)) return { state, publish: null };
    state.sig = sig;
    state.publishedAt = now;
    return { state, publish: cur };
  }

  // Troca de barco: esquece só a leitura. (Pendência: `last` continua, ver os testes.)
  const eventBoatReset = (evState) => ({ ...evState, data: null, at: 0 });

  // Estado da sincronização a partir do status HTTP da falha.
  function syncState(code) {
    if (code === 401 || code === 403) return "login";
    if (code === 404) return "boat";
    if (code === 429) return "rate";
    return "error";
  }
  function accountFailure(code, boat, now, pausedUntil) {
    return {
      pausedUntil: code === 429 ? now + 120e3 : pausedUntil,
      record: { state: syncState(code), boat, status: code || null, at: now },
    };
  }

  // Registro dos dados da conta (me, inventory, shop, titles), todos lidos no mesmo instante.
  function smartRecord(boat, entries, now) {
    return { boat, data: Object.fromEntries(entries), fetchedAt: Object.fromEntries(entries.map(([k]) => [k, now])), updatedAt: now };
  }

  // Eventos vistos nesta leitura, para o histórico do dia (o regular primeiro).
  function eventsSeen(data, at) {
    const slots = [["regular", data.event], ["grand", data.grande_evento]];
    return slots.filter(([, e]) => e).map(([kind, e]) => ({ name: e.name, endsAt: at + e.seconds_remaining * 1000, kind }));
  }

  // Verificação anti-robô: mesmo estado e prazo a menos de 3 s é a mesma.
  function sameChallenge(prev, next) {
    return !!prev && prev.state === next.state && Math.abs((prev.until || 0) - (next.until || 0)) < 3000;
  }
  // Pode ler /me/challenge agora? Com `force` o intervalo é 2 s e diz quando tentar de novo.
  function challengeGate(lastAt, now, force) {
    const gap = now - lastAt;
    if (gap < (force ? 2e3 : 60e3)) return { go: false, retryIn: force ? 2e3 - gap : null };
    return { go: true };
  }

  return { REPUBLISH_MS, cooldownIn, fishingStep, eventStep, eventBoatReset, syncState, accountFailure, smartRecord, eventsSeen, sameChallenge, challengeGate };
});
