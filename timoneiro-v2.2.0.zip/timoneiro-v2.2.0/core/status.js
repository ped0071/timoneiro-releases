// Timoneiro — núcleo de status: pesca, evento e histórico do dia, a partir das respostas do Twish.
// Funções puras (sem chrome.*), usadas pela aba do Twish, pelo fundo e pela barra da Twitch.
(function (root) {
  "use strict";

  const TTL = { state: 30e3, background: 90e3, smart: 150e3, api: 120e3, readyTrust: 15 * 60e3 };
  const REGULAR = ["Coins em Dobro", "Desconto na Loja", "Maré Turbo", "Sorte Rara", "Venda Turbinada", "XP em Dobro"];
  const GRAND = ["Invasão Pirata", "Julgamento de Njord", "Barco Misterioso"];
  const UNKNOWN_COUNT = Object.freeze({ mode: "unknown", cooldown: null, seconds: null });

  const isNum = Number.isFinite;
  const mmss = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const secondsUntil = (t, now) => Math.ceil((t - now) / 1000);

  // Leitura feita em `at` ainda vale em `now`? (nunca no futuro)
  function fresh(at, now, ttl = TTL.state) {
    if (!isNum(at) || now < at) return false;
    return now - at <= ttl;
  }
  // Estado publicado: o do fundo é renovado mais devagar, então vale mais tempo.
  function stateFresh(state, now = Date.now()) {
    if (!state) return false;
    return fresh(state.updatedAt, now, state.source === "background" ? TTL.background : TTL.state);
  }

  // Dados da conta (me, inventory, shop, titles) só se todas as partes pedidas estão recentes.
  function smartData(state, keys, now = Date.now()) {
    const d = state && state.data;
    if (!d) return null;
    for (const k of keys) if (!d[k] || !fresh(state.fetchedAt && state.fetchedAt[k], now, TTL.smart)) return null;
    return d;
  }

  // /api/<barco>/me: cooldown_remaining é do momento da leitura; devolve a hora em que libera.
  function fishingFromApi(data, fetchedAt, now = Date.now()) {
    const left = data && data.cooldown_remaining;
    if (!fresh(fetchedAt, now, TTL.api) || !isNum(left) || left < 0) return null;
    const readyAt = fetchedAt + left * 1000;
    const rest = (readyAt - now) / 1000;
    if (rest <= 0) return { status: "available", readyAt, cooldown: null };
    return { status: "cooldown", readyAt, cooldown: mmss(Math.ceil(rest)) };
  }

  // Título da aba do Twish: "(4:59) ..." contando, ou 🎣 quando dá para pescar.
  function fishingFromTitle(title, now = Date.now()) {
    const text = title == null ? "" : String(title);
    const clock = /\((\d{1,2}):(\d{2})\)/.exec(text);
    if (clock) {
      const [, m, s] = clock;
      return { status: "cooldown", cooldown: `${m}:${s}`, readyAt: now + (Number(m) * 60 + Number(s)) * 1000 };
    }
    return text.includes("🎣") ? { status: "available", cooldown: null } : { status: "unknown", cooldown: null };
  }

  // Contagem para mostrar agora, a partir do estado salvo (readyAt manda; senão o texto recente).
  function countdown(state, now = Date.now()) {
    if (!state || !isNum(state.updatedAt) || now < state.updatedAt - 5000) return { ...UNKNOWN_COUNT };
    const age = now - state.updatedAt;
    if (isNum(state.readyAt) && age <= TTL.readyTrust) {
      const s = secondsUntil(state.readyAt, now);
      return s > 0 ? { mode: "cooldown", cooldown: mmss(s), seconds: s } : { mode: "available", cooldown: null, seconds: 0 };
    }
    if (age > TTL.state) return { ...UNKNOWN_COUNT };
    if (state.status === "available") return { mode: "available", cooldown: null, seconds: 0 };
    const clock = state.status === "cooldown" ? /^(\d{1,2}):(\d{2})$/.exec(String(state.cooldown || "")) : null;
    if (clock) {
      const s = Number(clock[1]) * 60 + Number(clock[2]) - Math.floor(age / 1000);
      if (s > 0) return { mode: "cooldown", cooldown: mmss(s), seconds: s };
    }
    return { ...UNKNOWN_COUNT };
  }

  // Texto do botão de pesca.
  function fishingUi(state, now = Date.now()) {
    const wait = { mode: "unknown", tooltip: "Aguardando sincronização com o Twish" };
    if (!stateFresh(state, now)) return wait;
    if (state.status === "available") return { tooltip: "Pesca disponível!", mode: "available" };
    if (state.status !== "cooldown") return wait;
    if (isNum(state.readyAt)) {
      const s = secondsUntil(state.readyAt, now);
      return s > 0 ? { mode: "cooldown", tooltip: `Próxima pesca em ${mmss(s)}` } : wait;
    }
    return state.cooldown ? { mode: "cooldown", tooltip: `Próxima pesca em ${state.cooldown}` } : wait;
  }

  // /api/<barco>/events/active -> evento ativo, ou null se a resposta é velha ou não tem o formato
  // esperado. O grande evento vem na frente; o evento da hora rodando junto vai em "also" (o site
  // mostra os dois).
  function validEvent(e) { return typeof e === "object" && typeof e.name === "string" && isNum(e.seconds_remaining) && e.seconds_remaining >= 0; }
  function slotEvent(e, kind, fetchedAt, now) {
    const left = Math.max(0, Math.ceil(e.seconds_remaining - (now - fetchedAt) / 1000));
    if (!left) return null;
    const out = {
      name: e.name,
      description: typeof e.message === "string" ? e.message : "",
      remaining: mmss(left),
      endsAt: fetchedAt + e.seconds_remaining * 1000,
      kind,
      apiKind: typeof e.kind === "string" ? e.kind : null,
    };
    // O Kraken: barra de vida. Senão, a barra de meta como no site: só em "open" e sem vida,
    // receita ou resgate (Barco Misterioso em twishcoins, Njord em peixes).
    const h = e.health;
    if (h && typeof h === "object" && isNum(h.total) && h.total > 0 && isNum(h.left) && h.left >= 0) out.health = { left: h.left, total: h.total };
    const hasProgress = isNum(e.progress_count) && e.progress_count >= 0 && isNum(e.progress_target) && e.progress_target > 0;
    const goalBar = e.name === "Barco Misterioso" || e.name === "Julgamento de Njord" || e.contribution === "twishcoins" || e.contribution === "catch";
    if (!out.health && e.phase === "open" && hasProgress && goalBar && !e.recipe && !e.ransom) Object.assign(out, { progressCount: e.progress_count, progressTarget: e.progress_target });
    if (typeof e.contribution === "string") out.contribution = e.contribution;
    return out;
  }
  function eventFromApi(data, fetchedAt, now = Date.now()) {
    const hasSlots = !!data && ("event" in data || "grande_evento" in data);
    if (!hasSlots || !fresh(fetchedAt, now)) return null;
    const slots = [["grand", data.grande_evento], ["regular", data.event]];
    if (slots.some(([, e]) => e != null && !validEvent(e))) return null;
    const list = slots.map(([kind, e]) => (e ? slotEvent(e, kind, fetchedAt, now) : null)).filter(Boolean);
    if (!list.length) return { active: false }; // nenhum evento rolando
    const [main, ...also] = list;
    return { active: true, ...main, ...(also.length ? { also } : {}) };
  }

  // "3/10" (meta) ou "vida 250/400" (Kraken); vazio quando não há barra.
  function eventProgress(ev) {
    if (!ev) return "";
    if (ev.health && isNum(ev.health.left) && ev.health.total > 0) return `vida ${ev.health.left}/${ev.health.total}`;
    if (isNum(ev.progressCount) && ev.progressTarget > 0) return `${ev.progressCount}/${ev.progressTarget}`;
    return "";
  }

  // Texto do botão de evento (o principal e, em "also", o outro que roda junto).
  function eventUi(state, now = Date.now()) {
    const ended = isNum(state && state.endsAt) && state.endsAt <= now;
    const live = !!state && !!state.active && stateFresh(state, now);
    const left = (e) => (isNum(e.endsAt) ? mmss(secondsUntil(e.endsAt, now)) : e.remaining);
    const tip = (list) => list.map((e) => `${e.name} • ${e.remaining}`).join(" · ");
    const also = live && Array.isArray(state.also)
      ? state.also.filter((e) => e && typeof e.name === "string" && !(isNum(e.endsAt) && e.endsAt <= now)).map((e) => ({ name: e.name, description: e.description || "", remaining: left(e), endsAt: e.endsAt, kind: e.kind, apiKind: e.apiKind || null, progressCount: e.progressCount, progressTarget: e.progressTarget, health: e.health, contribution: e.contribution }))
      : [];
    if (!live || ended) {
      // O principal acabou, mas o outro continua: ele passa para a frente.
      if (live && also.length) { const [m, ...rest] = also; return { active: true, ...m, also: rest, tooltip: tip(also) }; }
      return { active: false, tooltip: "$evento" };
    }
    const remaining = left(state);
    const { name, description, kind, progressCount, progressTarget, health, contribution } = state;
    const out = { active: true, name, description, remaining, kind, progressCount, progressTarget, health, contribution, tooltip: tip([{ name, remaining }, ...also]) };
    if (Array.isArray(state.also)) out.also = also;
    return out;
  }

  // ---------- verificação anti-robô (/api/me/challenge e o aviso challenge_changed) ----------
  // Enquanto a verificação está pendente (prazo para resolver) ou a pesca está bloqueada depois de
  // expirar, mandar $pescar não pesca e insistir custa twishcoins: o aviso "pode pescar" espera.
  function challengeFrom(data, at = Date.now()) {
    const st = data && typeof data.state === "string" ? data.state : null;
    const blocked = isNum(data && data.blocked_seconds_left) ? data.blocked_seconds_left : 0;
    const left = isNum(data && data.seconds_left) ? data.seconds_left : 0;
    if (blocked > 0) return { state: "blocked", until: at + blocked * 1000, at };
    if (st === "pending" && left > 0) return { state: "pending", until: at + left * 1000, at };
    return { state: "none", until: null, at };
  }
  // Até quando segurar o aviso de pesca (null = não segura).
  function challengeHold(ch, now = Date.now()) {
    if (!ch || (ch.state !== "pending" && ch.state !== "blocked") || !isNum(ch.until)) return null;
    return ch.until > now ? ch.until : null;
  }

  // ---------- histórico de eventos do dia (fuso de Brasília) ----------
  const dayFmt = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" });
  const day = (at) => dayFmt.format(new Date(at));

  // Junta a leitura `events` (nome, fim, tipo) ao histórico: o mesmo evento visto de novo atualiza
  // a linha dele; o que sumiu da leitura é marcado como encerrado.
  function historyUpdate(saved, events, at) {
    if (!Array.isArray(events) || !isNum(at)) return saved;
    if (saved && isNum(saved.updatedAt) && at < saved.updatedAt) return saved;
    const today = day(at);
    const rows = saved && saved.day === today && Array.isArray(saved.entries) ? saved.entries.map((r) => ({ ...r })) : [];
    const touched = new Set();
    for (const e of events) {
      if (!e || typeof e.name !== "string" || !e.name || !isNum(e.endsAt) || e.endsAt < at) continue;
      const kind = e.kind === "grand" ? "grand" : "regular";
      const sameEvent = (r) => r.status !== "ended" && r.name === e.name && r.kind === kind && !touched.has(r.id) && (r.endsAt > at || Math.abs(r.endsAt - e.endsAt) <= 30e3);
      let row = rows.find(sameEvent);
      if (!row) { row = { id: `${at}:${kind}:${e.name}:${rows.length}`, name: e.name, kind, detectedAt: at }; rows.push(row); }
      row.endsAt = e.endsAt; row.lastSeenAt = at; row.status = "active"; row.source = e.source;
      touched.add(row.id);
    }
    for (const r of rows) if (r.status !== "ended" && !touched.has(r.id)) { r.status = "ended"; r.confirmedEndedAt = at; }
    return { day: today, updatedAt: at, entries: rows };
  }

  // Histórico para mostrar agora: ativo só se foi visto há pouco e ainda não venceu.
  function historyView(saved, now = Date.now()) {
    const today = day(now);
    if (!saved || saved.day !== today || !Array.isArray(saved.entries)) return { day: today, entries: [] };
    const seenRecently = (r) => isNum(r.lastSeenAt) && now >= r.lastSeenAt && now - r.lastSeenAt <= (r.source === "background" ? TTL.background : TTL.state);
    const entries = saved.entries.map((r) => ({ ...r, status: r.status === "ended" ? "ended" : seenRecently(r) && r.endsAt > now ? "active" : "unconfirmed" }));
    entries.sort((a, b) => b.detectedAt - a.detectedAt || a.name.localeCompare(b.name));
    return { day: today, entries };
  }

  const api = { TTL, REGULAR, GRAND, mmss, fresh, stateFresh, smartData, fishingFromApi, fishingFromTitle, countdown, fishingUi, eventFromApi, eventUi, eventProgress, challengeFrom, challengeHold, day, historyUpdate, historyView };
  root.TimoneiroStatus = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
