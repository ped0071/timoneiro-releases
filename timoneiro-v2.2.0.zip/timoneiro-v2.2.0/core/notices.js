// Timoneiro — regras de aviso: quando avisar pesca, evento, verificação anti-robô, Torneio, Frota,
// sala e mercado, e com que chave (anti-repetição e som). Puro: sem chrome.*, sem relógio, sem timer.
// O fundo (notification-worker.js) lê e grava o memo e mostra os avisos; aqui só ficam as decisões.
// As funções mudam o memo (ou o mapa de chaves) recebido, como o fundo sempre fez.
// Aviso = [id, título, mensagem, { desktop, sound?: [tipo, chave] }].
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroNotices = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  // core/events.js resolvido só na hora de usar: a ordem de carga dos arquivos não importa.
  const Ev = () => globalThis.TimoneiroEvents || require("./events.js");
  // Notificações vêm ligadas por padrão: só ficam desligadas se você desligou em Ajustes.
  const on = (v) => v !== false;
  const MEMO_TTL = 3 * 3600e3;

  const FISH_NOTICE = ["timoneiro-fishing", "Pesca disponível!", "Seu cooldown no Twish acabou. Clique para abrir o chat com $pescar."];

  // ---------- chaves ----------
  const fishKey = (boat, readyAt) => `fish|${boat || ""}|${Math.round(readyAt / 10000)}`;
  // Sem "|| ''": sem barco a chave do som leva "undefined", e a página usa a mesma conta.
  const fishSound = (boat, readyAt) => `${boat}|${Math.round(readyAt / 10000)}`;
  const eventSound = (boat, e) => `${boat}|${e.name}|${Number.isFinite(e.endsAt) ? Math.round(e.endsAt / 60000) : "x"}`;
  const eventKey = (boat, e) => `${boat}|${e.slot === "grand" ? "grand" : "regular"}|${e.name}`;
  const challengeKey = (state, until) => `ch|${state}|${Math.round(until / 60000)}`;
  const seaKey = (a) => `al|${a.key}`;
  const marketKey = (h) => `mk|${h.key}`;
  const noticeKey = (sound) => (sound ? `${sound[0]}|${sound[1]}` : null);

  // ---------- memo ----------
  function pruneMemo(raw, now) {
    const m = raw || { keys: {}, fishing: null };
    m.events = m.events || {};
    const cutoff = now - MEMO_TTL;
    for (const [k, t] of Object.entries(m.keys)) if (t < cutoff) delete m.keys[k];
    for (const [k, e] of Object.entries(m.events)) if ((e.at || 0) < cutoff) delete m.events[k];
    return m;
  }

  // ---------- eventos ----------
  const freshEvents = (ev, now) => !!ev && Array.isArray(ev.list) && Number.isFinite(ev.at) && now - ev.at < 60000;

  function events(list, boat, m, prefs, now) {
    const E = Ev();
    const out = [];
    const minRank = E.LEVEL_RANK[prefs.eventLevel === "alta" ? "alta" : prefs.eventLevel === "media" ? "media" : "desconhecida"];
    const seen = new Set();
    for (const e of list) {
      if (Number.isFinite(e.endsAt) && e.endsAt <= now) continue;
      const key = eventKey(boat, e);
      seen.add(key);
      const prev = m.events[key];
      const isNew = !prev || (Number.isFinite(prev.endsAt) && now > prev.endsAt + 60000);
      const passes = E.LEVEL_RANK[e.relevance] >= minRank;
      const head = `${e.emoji ? `${e.emoji} ` : ""}${e.name}`;
      const ends = Number.isFinite(e.endsAt) ? ` (termina ${new Date(e.endsAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })})` : "";
      const detail = `${e.message || e.relevanceWhy}${ends}\nRelevância: ${E.LEVEL_LABEL[e.relevance]}.`;
      if (isNew) {
        if (passes) out.push(["timoneiro-event", `Evento: ${head}`, detail, { desktop: on(prefs.event), sound: ["event", eventSound(boat, e)] }]);
        m.events[key] = { fp: e.fingerprint, endsAt: e.endsAt, at: now, notified: passes, misses: 0 };
      } else {
        if (prev.fp !== e.fingerprint && prev.notified && e.relevance === "alta") out.push(["timoneiro-event", `Evento mudou: ${head}`, detail, { desktop: on(prefs.event) }]);
        Object.assign(prev, { fp: e.fingerprint, endsAt: e.endsAt ?? prev.endsAt, at: now, misses: 0 });
      }
    }
    // Fim: sumiu em duas leituras seguidas (a API às vezes "pisca") ou já passou da hora de acabar.
    // A entrada sai do memo mesmo quando o aviso de fim está desligado.
    for (const [key, prev] of Object.entries(m.events)) {
      if (!key.startsWith(`${boat}|`) || seen.has(key)) continue;
      prev.misses = (prev.misses || 0) + 1;
      if (prev.misses < 2 && !(Number.isFinite(prev.endsAt) && now >= prev.endsAt)) continue;
      if (prev.notified && prefs.eventEnd === true) out.push(["timoneiro-event-end", `Evento terminou: ${key.split("|")[2]}`, "Volte ao ritmo normal do Guia.", { desktop: on(prefs.event) }]);
      delete m.events[key];
    }
    return out;
  }

  // ---------- pesca ----------
  // O que uma leitura nova do cooldown significa. "ready" = acabou de liberar o cooldown que estava
  // guardado: quem chama confere se algo segura o aviso (gelo, verificação) antes de avisar.
  function fishingRead(fishing, prev, now) {
    if (!fishing || !Number.isFinite(fishing.updatedAt) || !(now - fishing.updatedAt < 30000)) return { type: "ignore" };
    if (fishing.status === "cooldown" && Number.isFinite(fishing.readyAt) && fishing.readyAt > now) {
      return { type: "cooldown", arm: prev?.readyAt !== fishing.readyAt, alarmAt: fishing.readyAt + 500, next: { status: "cooldown", boat: fishing.boat, readyAt: fishing.readyAt, at: now } };
    }
    if (fishing.status !== "available") return { type: "ignore" };
    if (prev?.frozen && now < prev.readyAt) return { type: "frozen" };
    const next = { status: "available", boat: fishing.boat, at: now };
    if (prev?.status === "cooldown" && prev.boat === fishing.boat && now - prev.at < 15 * 60000 && prev.readyAt && now >= prev.readyAt - 3000 && now - prev.readyAt < 120000) {
      return { type: "ready", boat: prev.boat, readyAt: prev.readyAt, next };
    }
    return { type: "available", next };
  }

  function fishingNotice(keys, boat, readyAt, prefs, now) {
    const key = fishKey(boat, readyAt);
    const send = !keys[key];
    keys[key] = keys[key] || now;
    return { key, send, notice: send ? [...FISH_NOTICE, { desktop: on(prefs.fishing), sound: ["fishing", fishSound(boat, readyAt)] }] : null };
  }

  // O alarme da pesca ainda vale? (o cooldown guardado é o mesmo que armou o alarme e já venceu)
  function alarmCheck(memoFishing, stored, now) {
    const ready = memoFishing?.status === "cooldown" ? memoFishing.readyAt : null;
    const changed = stored?.status === "cooldown" && Number.isFinite(stored.readyAt) && Math.abs(stored.readyAt - ready) > 3000;
    if (ready && !(now < ready - 1000) && !changed) return { ok: true, ready };
    // A leitura "liberado" chegou antes do alarme e já avisou: normal, não entra no registro.
    if (memoFishing?.status === "available") return { ok: false, log: null };
    return { ok: false, log: !ready ? "sem cooldown guardado" : now < ready - 1000 ? "alarme adiantado" : "cooldown mudou" };
  }

  // O que segura o aviso de pesca (o que durar mais; empate fica com a verificação).
  function pickHold(iceUntil, challengeUntil) {
    if (!iceUntil && !challengeUntil) return null;
    return (challengeUntil || 0) >= (iceUntil || 0) ? { until: challengeUntil, why: "challenge" } : { until: iceUntil, why: "ice" };
  }

  // Aviso de pesca adiado para o fim do gelo ou da verificação. cooldownEnd guarda a hora em que o
  // cooldown de verdade acaba: se a verificação for resolvida antes, o aviso não sai adiantado.
  function deferFishing(prev, boat, hold, now) {
    const { until, why } = hold;
    const cooldownEnd = prev?.frozen ? prev.cooldownEnd ?? null : prev?.status === "cooldown" ? prev.readyAt : null;
    return {
      fishing: { status: "cooldown", boat, readyAt: until, at: now, frozen: true, heldBy: why, cooldownEnd },
      alarmAt: until + 1500,
      why: why === "challenge" ? "verificação anti-robô" : "lago congelado",
    };
  }

  // ---------- verificação anti-robô ----------
  function challengeStep(ch, until, memoFishing, keys, prefs, now) {
    let notice = null, defer = null, release = null;
    if (until) {
      const key = challengeKey(ch.state, until);
      if (!keys[key]) {
        const mins = Math.max(1, Math.ceil((until - now) / 60000));
        notice = ["timoneiro-challenge", "Verificação anti-robô do Twish", ch.state === "pending"
          ? `Resolva em twish.com.br/verificacao (prazo de ~${mins} min). Até lá não mande $pescar: o Timoneiro segura o aviso de pesca.`
          : `A pesca no chat está bloqueada por ~${mins} min. Não mande $pescar agora: insistir custa twishcoins. O Timoneiro avisa quando liberar.`, { desktop: on(prefs.fishing) }];
        keys[key] = now;
      }
      // Um aviso de pesca que já estava marcado espera o fim da verificação.
      if (memoFishing?.status === "cooldown" && Number.isFinite(memoFishing.readyAt) && memoFishing.readyAt < until) defer = { until, why: "challenge" };
    } else if (memoFishing?.frozen && memoFishing.heldBy === "challenge" && memoFishing.readyAt > now) {
      // Verificação resolvida: o aviso segurado sai agora (o alarme confere o resto).
      const at = Math.max(now, memoFishing.cooldownEnd || 0);
      release = { readyAt: at, alarmAt: at + 1000 };
    }
    return { notice, defer, release };
  }

  // ---------- Torneio, Frota e sala (Guia ou fundo, mesma chave: avisa uma vez) ----------
  function seaNotices(guideAlerts, fromSea, keys, prefs, now) {
    const out = [];
    const all = [...(guideAlerts || []), ...(fromSea && now - (fromSea.at || 0) < 120000 ? fromSea.alerts || [] : [])];
    for (const a of all) {
      const key = seaKey(a);
      if (keys[key]) continue;
      keys[key] = now;
      out.push([`timoneiro-${a.type}`, a.title, a.message, { desktop: on(prefs.event), sound: a.type === "tournament" || a.type === "fleet" ? ["event", a.key] : null }]);
    }
    return out;
  }

  // ---------- mercado ----------
  function marketNotices(hits, keys, prefs, now) {
    const out = [];
    for (const h of hits) {
      const key = marketKey(h);
      if (keys[key]) continue;
      keys[key] = now;
      out.push(["timoneiro-market", `Mercado: ${h.name} por ${h.price}`, `${h.seller ? `Anunciado por ${h.seller}. ` : ""}Abaixo do seu limite. Clique para abrir o Mercado.`, { desktop: on(prefs.market) }]);
    }
    return out;
  }

  return {
    fishKey, fishSound, eventSound, eventKey, challengeKey, seaKey, marketKey, noticeKey, FISH_NOTICE,
    pruneMemo, events, freshEvents, fishingRead, fishingNotice, alarmCheck, pickHold, deferFishing,
    challengeStep, seaNotices, marketNotices,
  };
});
