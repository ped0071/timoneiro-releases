// Timoneiro — trava do som: cada aviso toca uma vez no navegador todo (aba da Twitch ou fundo).
// Puro: sem chrome.*. Usado por chat/alerts.js e por notification-worker.js.
// Até a 2.0.15 qualquer som de evento calava os outros por 12 min: Torneio, Frota e o evento seguinte
// ficavam mudos. Agora só cala o mesmo aviso; avisos diferentes ficam mudos só por alguns segundos,
// o tempo de a página e o fundo lerem o mesmo acontecimento com chaves um pouco diferentes.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroSoundLock = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const SAME = { fishing: 10 * 60e3, event: 30 * 60e3 };
  const GAP = { fishing: 60e3, event: 45e3 };

  function canPlay(lock, kind, key, now = Date.now()) {
    const at = (lock && lock[`${kind}At`]) || 0;
    if (lock && lock[kind] === key && now - at < (SAME[kind] || SAME.event)) return false;
    return now - at >= (GAP[kind] || GAP.event);
  }
  const take = (lock, kind, key, now = Date.now()) => ({ ...(lock || {}), [kind]: key, [`${kind}At`]: now });
  // O som falhou (navegador bloqueou o áudio): volta a trava como estava, para o fundo tocar.
  function release(lock, kind, key, before) {
    if (!lock || lock[kind] !== key) return lock;
    return { ...lock, [kind]: (before || {})[kind] ?? null, [`${kind}At`]: (before || {})[`${kind}At`] || 0 };
  }
  // Registro das últimas tentativas de som (mais recente primeiro), para o diagnóstico do Guia.
  const LOG = "timoneiro.soundLog.v1";
  const log = (list, entry, max = 40) => [entry, ...(Array.isArray(list) ? list : [])].slice(0, max);
  // O que fazer com um pedido de som: tocar (com a trava nova, o arquivo e o volume) ou registrar por
  // que não tocou. A trava é conferida antes do ajuste de som, como o fundo sempre fez.
  function plan(lock, sounds, kind, key, now) {
    if (!canPlay(lock, kind, key, now)) return { play: false, log: { result: "já tocou", by: (lock && lock[kind]) || null } };
    const pref = (sounds || {})[kind === "fishing" ? "fishingAlert" : "eventAlert"] || { enabled: true, volume: 7 };
    if (pref.enabled === false || !pref.volume) return { play: false, log: { result: "som desligado" } };
    return { play: true, lock: take(lock, kind, key, now), asset: kind === "fishing" ? "sounds/pesca.wav" : "sounds/evento.wav", volume: pref.volume / 10 };
  }
  return { canPlay, take, release, log, LOG, plan };
});
