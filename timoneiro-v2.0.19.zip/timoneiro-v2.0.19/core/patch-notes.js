// Timoneiro — notas de atualização do Twish, lidas do próprio bundle do site.
// O site guarda o histórico como JSON dentro de JSON.parse('[{"postedAt"...]') (até 03/11) ou de
// JSON.parse(`[{"postedAt"...]`) (desde 13/11, com a versão em inglês junto). Lê os dois.
// Puro: sem DOM e sem rede. Usado pela aba do Twish (guide-sync.js).
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroPatchNotes = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const QUOTES = ["'", "`"];

  // Desfaz o escape da string do JavaScript (o que sobra é o texto JSON).
  const cook = (raw) => raw.replace(/\\(u[0-9a-fA-F]{4}|[\s\S])/g, (_, c) =>
    c.length === 5 ? String.fromCharCode(parseInt(c.slice(1), 16)) : c === "n" ? "\n" : c === "t" ? "\t" : c === "r" ? "\r" : c);

  function fromBundle(text) {
    const src = String(text || "");
    for (const q of QUOTES) {
      const marker = `JSON.parse(${q}[{"postedAt"`;
      const i = src.indexOf(marker);
      if (i < 0) continue;
      const start = i + "JSON.parse(".length + 1;
      // Fim: a mesma aspa sem barra antes, seguida de ")".
      let end = start;
      for (;;) {
        end = src.indexOf(`${q})`, end);
        if (end < 0) return null;
        let bs = 0;
        for (let k = end - 1; src[k] === "\\"; k--) bs++;
        if (bs % 2 === 0) break;
        end++;
      }
      const raw = src.slice(start, end);
      if (q === "`" && raw.includes("${")) return null;
      try {
        const notes = JSON.parse(cook(raw));
        return Array.isArray(notes) ? notes : null;
      } catch (_) { return null; }
    }
    return null;
  }

  return { fromBundle };
});
