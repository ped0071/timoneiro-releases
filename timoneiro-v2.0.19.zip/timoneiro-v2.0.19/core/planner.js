// Timoneiro — planejador de evolução (puro: sem DOM, sem rede).
// Entrada: dados já lidos do Twish (me, inventory, shop, titles, profile público, manual,
// bestiary, missions, expeditions, tournament) + evento atual.
// Saída: fase, meta de economia, ações "agora", plano em ordem, "não faça agora",
// veredito de expedição e comparação com jogadores do mesmo nível.
(function (root, factory) {
  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TimoneiroPlanner = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  const CAT = () => root.TimoneiroCatalog || {};
  const BENCH = () => root.TimoneiroBenchmark || { bands: [] };
  const TIERS = ["common", "uncommon", "rare", "legendary", "mythic", "secret", "divine"];
  const TIER_LABEL = { common: "Comum", uncommon: "Incomum", rare: "Raro", legendary: "Lendário", mythic: "Mítico", secret: "Secreto", divine: "Divino" };
  const TIER_WEIGHT = { common: 0.587, uncommon: 0.25, rare: 0.12, legendary: 0.03, mythic: 0.01, secret: 0.0025 };
  const AVG_POINTS = { common: 1.6, uncommon: 5.2, rare: 10.8, legendary: 27.7, mythic: 47.9, secret: 125, divine: 200 };
  // Grupo de espécies comuns/incomuns (bestiário de 10/11), para quando o inventário não traz species_group.
  const CATALOG_GROUP = {
    acara: "freshwater", bagre: "freshwater", basa: "freshwater", carpa: "freshwater", cascudo: "freshwater", jundia: "freshwater", lambari: "freshwater", mandi: "freshwater", piau: "freshwater", tilapia: "freshwater", tuvira: "freshwater",
    aji: "saltwater", manjuba: "saltwater", sardinha: "saltwater", corno_marinho: null,
    camarao: "shellfish", mexilhao: "shellfish", siri: "shellfish", caranguejo: "shellfish", ostra: "shellfish", vieira: "shellfish", lagosta: "shellfish", lula: "shellfish", polvo: "shellfish",
    aracu: "freshwater", curimata: "freshwater", jaraqui: "freshwater", koi: "freshwater", matrinxa: "freshwater", piapara: "freshwater", piranha: "freshwater", traira: "freshwater",
    corvina: "saltwater", peixe_mandarim: "saltwater", pescada: "saltwater", robalo_peva: "saltwater", saba: "saltwater", tainha: "saltwater",
  };
  const PRICE_PER_POINT = 1.7; // observado em perfis públicos (preço de venda ÷ pontos da espécie)
  const PRIORITY = { 1: "Agora", 2: "Alta", 3: "Média", 4: "Baixa" };

  const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
  const fold = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const fmt = (n) => (n == null ? "?" : Math.round(n).toLocaleString("pt-BR"));
  const pct = (x) => `${Math.round(x * 100)}%`;

  function findNumber(obj, keys, maxDepth = 3) {
    let level = [obj];
    for (let d = 0; d <= maxDepth && level.length; d++) {
      for (const k of keys) for (const o of level) {
        if (o && typeof o === "object" && !Array.isArray(o) && k in o) { const n = num(o[k]); if (n !== null) return n; }
      }
      level = level.flatMap((o) => (o && typeof o === "object" ? Object.values(o).filter((v) => v && typeof v === "object" && !Array.isArray(v)) : []));
    }
    return null;
  }
  function findString(obj, keys, maxDepth = 3) {
    let level = [obj];
    for (let d = 0; d <= maxDepth && level.length; d++) {
      for (const k of keys) for (const o of level) if (o && typeof o === "object" && !Array.isArray(o) && typeof o[k] === "string") return o[k];
      level = level.flatMap((o) => (o && typeof o === "object" ? Object.values(o).filter((v) => v && typeof v === "object" && !Array.isArray(v)) : []));
    }
    return null;
  }

  // Quantidades possuídas: {id: n} a partir de me.owned (objetos de contagem, arrays de ids).
  function ownedCounts(me) {
    const out = {};
    const add = (k, n = 1) => { if (typeof k === "string" && k) out[k] = (out[k] || 0) + n; };
    const walk = (v, depth) => {
      if (depth > 3 || v == null) return;
      if (typeof v === "string") return add(v);
      if (Array.isArray(v)) return v.forEach((x) => (x && typeof x === "object" ? add(x.id || x.item_id, num(x.quantity ?? x.count) ?? 1) : walk(x, depth + 1)));
      if (typeof v === "object") for (const [k, x] of Object.entries(v)) {
        if (x === true) add(k);
        else if ((num(x) ?? 0) > 0) add(k, num(x));
        else if (x && typeof x === "object") walk(x, depth + 1);
      }
    };
    walk(me?.owned, 0);
    walk(me?.items, 0);
    return out;
  }

  function catalog(data) {
    const live = data?.manual?.shop ? data.manual : null;
    const c = CAT();
    const shop = data?.shop && Array.isArray(data.shop.rods) ? data.shop : live?.shop || c.shop || {};
    return {
      rods: shop.rods || c.shop?.rods || [],
      hooks: shop.hooks || c.shop?.hooks || [],
      backpacks: shop.backpacks || c.shop?.backpacks || [],
      baits: shop.baits || c.shop?.baits || [],
      boosters: shop.boosters || c.shop?.boosters || [],
      upkeep: shop.upkeep || c.shop?.upkeep || [],
      titles: [...(live?.titles || []), ...(live?.shop_titles || []), ...(live?.pix_titles || []), ...(live?.curse_titles || []), ...(live?.rank_titles || [])],
      seas: c.seas || [],
      tides: c.tides || {},
      featured: c.featured || {},
      fromLiveShop: !!(data?.shop && Array.isArray(data.shop.rods)),
    };
  }

  // cost = preço de tabela; discounted_cost = o que a loja cobra AGORA (já com Desconto na Loja ou
  // oferta do barco). O desconto nunca é aplicado de novo por cima de discounted_cost.
  const price = (item) => num(item?.cost) ?? num(item?.discounted_cost) ?? 0;
  const priceNow = (item) => { const c = num(item?.cost), d = num(item?.discounted_cost); return c != null && d != null ? Math.min(c, d) : d ?? c ?? 0; };
  const rodIndex = (rods, id) => rods.findIndex((r) => r.id === id);

  function normalize(data) {
    const me = data?.me || {};
    const pub = data?.profile || {};
    const cat = catalog(data);
    const owned = ownedCounts(me);
    const eq = me.equipment || {};

    const coins = findNumber(me, ["twishcoins", "coins", "balance", "saldo"]) ?? num(pub.twishcoins);
    const xp = findNumber(me, ["xp", "total_xp"]) ?? num(pub.xp);
    let level = findNumber(me, ["level", "nivel"]) ?? num(pub.level);
    if (level === null && xp !== null) level = Math.min(150, Math.floor(Math.sqrt(xp / 10)));
    const casts = findNumber(me, ["casts"]) ?? num(pub.casts);

    // Vara/anzol/mochila: campo direto, equipamento, perfil público ou o maior item possuído.
    const highest = (list, idKey) => { let best = null; list.forEach((it, i) => { if (owned[it.id]) best = i; }); return best === null ? null : list[best][idKey || "id"]; };
    const rodId = me.rod_id || eq.rod_id || pub.rod_id || highest(cat.rods) || "vara_bambu";
    const hookId = me.hook_id || eq.hook_id || pub.hook_id || highest(cat.hooks) || null;
    const backpackId = me.backpack_id || eq.backpack_id || pub.backpack_id || highest(cat.backpacks) || null;

    const baits = me?.owned?.baits || me.baits || pub.baits || {};
    const baitEquipped = eq.bait_id || me.bait_id || pub.bait_id || null;
    const baitEquippedQty = num(eq.bait_quantity ?? me.bait_quantity ?? pub.bait_quantity) ?? 0;
    const titleIds = me?.owned?.title_ids || me.title_ids || pub.title_ids || [];
    const handle = me.handle || me.login || me.username || pub.handle || null;

    const titleBonus = titleIds.reduce((s, id) => s + (num(cat.titles.find((t) => t.id === id)?.xp_bonus_percent) ?? 0), 0);
    const hasCurse = titleIds.includes("portador_da_maldicao");

    // Inventário: formato do PescaSkills (fish[].instances[]) ou do perfil público (lista de capturas).
    const fish = [];
    if (Array.isArray(data?.inventory?.fish)) {
      for (const f of data.inventory.fish) {
        const inst = Array.isArray(f.instances) && f.instances.length ? f.instances : Array.from({ length: num(f.count) ?? 0 }, () => ({}));
        for (const i of inst) fish.push({ id: f.fish_id || f.id, name: f.name || f.fish_name || f.fish_id, tier: f.tier || i.tier || null, group: f.species_group ?? null, price: num(i.price) ?? 0, weight: num(i.weight), asc: num(i.ascension_level ?? f.ascension_level) ?? 0, listed: !!(i.escrowed || i.listed || i.listing_id || i.on_market), captureId: i.capture_id || null, base: num(i.price) ?? null, maxKg: num(f.max_kg), self: i.caught_by ? fold(i.caught_by) === fold(handle) : true, locked: !!(i.locked || f.protected) });
      }
    } else if (Array.isArray(pub.inventory)) {
      for (const i of pub.inventory) fish.push({ id: i.fish_id || i.id, name: i.fish_name || i.name, tier: i.tier, price: num(i.price) ?? 0, weight: num(i.weight), asc: num(i.ascension_level) ?? 0, listed: false, self: fold(i.caught_by) === fold(handle), locked: false });
    }

    const rodIdx = Math.max(0, rodIndex(cat.rods, rodId));
    const rod = cat.rods[rodIdx] || { id: "vara_bambu", name: "Vara de Bambu", cooldown_multiplier: 1 };
    const hook = cat.hooks.find((h) => h.id === hookId) || null;
    const bpIdx = cat.backpacks.findIndex((b) => b.id === backpackId);
    const capacity = 100 + (bpIdx >= 0 ? num(cat.backpacks[bpIdx].extra_fish_total) ?? 50 * (bpIdx + 1) : 0);

    // Imposto do barco (desde 13/11): 0% a 10% de cada venda à loja neste barco. O streamer não paga
    // nas próprias vendas, e o Mercado não paga. O preço de cada peixe vem bruto; o total da mochila, líquido.
    const taxRaw = num(data?.inventory?.sale_tax_rate) ?? 0;
    const boatName = data?.boat || opts_boat(data);
    const ownBoat = !!(boatName && handle && fold(boatName) === fold(handle));
    const saleTax = ownBoat ? 0 : Math.min(0.5, Math.max(0, taxRaw > 1 ? taxRaw / 100 : taxRaw));
    return { cat, me, pub, owned, coins, xp, level, casts, rodId: rod.id, rod, rodIdx, hook, hookId, backpackId, bpIdx, capacity, baits, baitEquipped, baitEquippedQty, titleIds, titleBonus, hasCurse, handle, fish, saleTax };
  }

  // ---------- economia ----------
  function reachTier(acc) {
    const aco = rodIndex(acc.cat.rods, "vara_aco");
    return acc.rodIdx >= aco && aco >= 0 ? "secret" : "rare"; // Divino só no Abismo com expedições ligadas
  }

  function economy(acc, bestiary) {
    const L = acc.level ?? 0;
    const bite = 0.5 * (1 + 0.4 * (L / 150));
    const tierBoost = 1 + 0.5 * (L / 150);
    const sell = (1 + 0.3 * (L / 150)) * (acc.hasCurse ? 1.25 : 1);
    const avgPts = { ...AVG_POINTS };
    if (Array.isArray(bestiary?.fish)) {
      const g = {};
      for (const f of bestiary.fish) if (num(f.points) != null) (g[f.tier] = g[f.tier] || []).push(num(f.points));
      for (const [t, v] of Object.entries(g)) avgPts[t] = v.reduce((a, c) => a + c, 0) / v.length;
    }
    const cap = TIERS.indexOf(reachTier(acc));
    let w = {}, total = 0;
    for (const t of TIERS.slice(0, cap + 1)) { if (!TIER_WEIGHT[t]) continue; w[t] = TIER_WEIGHT[t] * (t === "common" ? 1 : tierBoost); total += w[t]; }
    let evPts = 0;
    for (const t in w) evPts += (w[t] / total) * avgPts[t];
    const fishValue = evPts * PRICE_PER_POINT * sell;
    const cdMin = (num(acc.rod.cooldown_multiplier) ?? 1) * 10;
    const castsPerHour = 60 / cdMin;
    const fishPerHour = castsPerHour * bite * (num(acc.hook?.num_fish) ?? 1);
    return { bite, tierBoost, sell, cdMin, castsPerHour, fishPerHour, fishValue, coinsPerHour: fishPerHour * fishValue, evPts, avgPts, xpPerHour: fishPerHour * evPts * (1 + acc.titleBonus / 100) };
  }

  // ---------- progressão ----------
  function progression(acc) {
    const r = acc.cat.rods, h = acc.cat.hooks;
    const byId = (list, id) => list.find((x) => x.id === id);
    const order = ["vara_madeira", "vara_fibra", "vara_aco", "vara_carbono", "vara_encantada", "vara_abissal", "vara_lendaria", "vara_njord"].map((id) => byId(r, id)).filter(Boolean);
    order.push(...["anzol_duplo", "anzol_triplo"].map((id) => byId(h, id)).filter(Boolean));
    const why = {
      vara_madeira: "Primeiro corte de cooldown (10 → 9 min).",
      vara_fibra: "Libera a Baía das Lendas e as Encomendas do Porto.",
      vara_aco: "Sem ela o teto é Raro: libera Lendário, Mítico e Secreto no lago.",
      vara_carbono: "Cooldown 7 → 6 min (+17% lançadas). Passo obrigatório para a Encantada.",
      vara_encantada: "Libera o Mar das Sereias (Lendário/Mítico exclusivos, encomendas de 150) e o Divino.",
      vara_abissal: "Libera o Abismo dos Deuses, único lugar com Secreto e Divino exclusivos. Os jogadores fortes chegam no nível 33–46 com ela.",
      vara_lendaria: "Cooldown de 3 min, 10 lançadas por expedição e acesso à Fenda do Fim.",
      vara_njord: "Cooldown de 2 min e 15 lançadas por expedição. No mar só a vara conta, por isso vem antes do anzol.",
      anzol_duplo: "Até 2 peixes por $pescar no lago (não vale no mar).",
      anzol_triplo: "Até 3 peixes por $pescar no lago.",
    };
    const ownedRod = (id) => rodIndex(r, id) <= acc.rodIdx;
    const ownedHook = (id) => id === "anzol_duplo" ? !!acc.hook : id === "anzol_triplo" ? acc.hookId === "anzol_triplo" : false;
    return order.map((it) => ({ ...it, price: price(it), priceNow: priceNow(it), why: why[it.id] || "", owned: it.id.startsWith("vara_") ? ownedRod(it.id) : ownedHook(it.id) }));
  }

  function phaseOf(acc) {
    const i = (id) => rodIndex(acc.cat.rods, id);
    if (acc.rodIdx < i("vara_aco")) return { n: 1, name: "Liberar raridades", text: "Chegar à Vara de Aço. Até lá nada acima de Raro cai no lago." };
    if (acc.rodIdx < i("vara_encantada")) return { n: 2, name: "Rumo à Encantada", text: "Carbono e Encantada: mais lançadas por hora e acesso ao Mar das Sereias." };
    if (acc.rodIdx < i("vara_abissal")) return { n: 3, name: "Abrir o Abismo", text: "Vara Abissal (7.000): é onde caem Secreto e Divino exclusivos." };
    if (acc.rodIdx < i("vara_lendaria")) return { n: 4, name: "Expedições e Lendária", text: "Abismo com seguro quando a maré ajudar, juntando para a Lendária." };
    if (acc.rodIdx < i("vara_njord")) return { n: 5, name: "Njord", text: "A melhor vara do mar: 15 lançadas por expedição." };
    if (!acc.hook) return { n: 6, name: "Anzol Duplo", text: "Dobra os peixes no lago. É o que os jogadores do nível 59+ compram depois da Njord." };
    if (acc.hookId !== "anzol_triplo") return { n: 7, name: "Anzol Triplo", text: "Até 3 peixes por lançada no lago." };
    return { n: 8, name: "Fim de jogo", text: "Ranking global, incubação e ascensão, mercado e Fenda do Fim." };
  }

  // ---------- leitura de dados extras ----------
  function claimableMissions(missions) {
    let n = 0;
    const walk = (v, d) => {
      if (d > 5 || !v) return;
      if (Array.isArray(v)) return v.forEach((x) => walk(x, d + 1));
      if (typeof v !== "object") return;
      const done = v.completed === true || v.complete === true || v.status === "completed" || v.status === "claimable" || v.claimable === true ||
        (num(v.progress) != null && num(v.target ?? v.goal) != null && num(v.progress) >= num(v.target ?? v.goal));
      const claimed = v.claimed === true || v.status === "claimed" || v.claimed_at;
      if (done && !claimed && (v.id || v.mission_id || v.title || v.name)) { n++; return; }
      Object.values(v).forEach((x) => typeof x === "object" && walk(x, d + 1));
    };
    walk(missions, 0);
    return n;
  }

  function tidesOf(expeditions, cat) {
    const out = {};
    const keys = Object.keys(cat.tides);
    const pickTide = (v) => { const f = fold(v); return keys.find((k) => f === k || f.includes(k) || f === fold(cat.tides[k].label)); };
    const walk = (v, d) => {
      if (d > 5 || !v || typeof v !== "object") return;
      if (Array.isArray(v)) return v.forEach((x) => walk(x, d + 1));
      const sea = v.sea || v.sea_id || v.id;
      const tideRaw = v.tide?.name || v.tide?.id || v.tide || v.mare || v.tide_name;
      const tide = typeof tideRaw === "string" ? pickTide(tideRaw) : null;
      if (tide && typeof sea === "string") out[sea] = tide;
      else if (tide && !out._any) out._any = tide;
      Object.values(v).forEach((x) => walk(x, d + 1));
    };
    walk(expeditions, 0);
    return out;
  }

  function tournamentActive(t) {
    if (!t || typeof t !== "object") return null;
    const active = t.active === true || t.status === "running" || t.status === "open" || t.state === "running" || !!(t.tournament && (t.tournament.active || t.tournament.status === "running"));
    if (!active) return null;
    const joined = t.joined === true || t.entered === true || t.you?.joined === true || !!t.me;
    return { joined };
  }

  // ---------- evento atual ----------
  // Raridade-alvo do evento: pela lista de tiers que a API manda; senão, procura o nome na mensagem.
  function tierOfEvent(ev) {
    const list = Array.isArray(ev?.tiers) ? ev.tiers.map(fold) : [];
    const byList = TIERS.find((t) => list.some((x) => x === t || x === fold(TIER_LABEL[t])));
    if (byList) return byList;
    const msg = fold(String(ev?.message || ev?.description || ""));
    return TIERS.find((t) => msg.includes(fold(TIER_LABEL[t])));
  }
  function eventActions(acc, eco, ev, goal, ctx) {
    const out = [];
    if (!ev?.name) return out;
    const name = ev.name, msg = String(ev.message || "");
    const L = (t) => TIER_LABEL[t] || t;
    const reach = reachTier(acc);
    const reaches = (tier) => TIERS.indexOf(tier) <= TIERS.indexOf(reach);
    const milagrosa = num(acc.baits.isca_milagrosa) ?? 0;
    const turbinada = num(acc.baits.isca_turbinada) ?? 0;
    const equipped = acc.baitEquipped;
    const tierInMsg = tierOfEvent(ev);
    const dRate = ctx?.discountRate || 0.2;
    const stockValue = acc.fish.reduce((s, f) => s + (f.locked ? 0 : f.price), 0) * (1 - (acc.saleTax || 0));
    const taxNote = acc.saleTax > 0 ? `, já sem o imposto do barco de ${Math.round(acc.saleTax * 100)}%` : "";
    const sellCmd = acc.fish.length ? "$vender todos" : null;
    const push = (o) => out.push({ tag: "agora", event: name, ...o });
    const sellBlocked = !!ctx?.tournamentActive;

    switch (name) {
      case "Desconto na Loja": {
        if (goal) {
          const disc = goal.priceNow != null && goal.priceNow < goal.price ? goal.priceNow : Math.ceil(goal.price * (1 - dRate));
          if ((acc.coins ?? 0) >= disc) push({ kind: "buy", priority: 1, title: `Compre ${goal.name} agora`, text: `Com ${pct(dRate)} de desconto sai por ${fmt(disc)} e você tem ${fmt(acc.coins)}.`, why: `Economiza ${fmt(goal.price - disc)} moedas na sua meta atual.`, command: `$comprar ${goal.id}` });
          else if ((acc.coins ?? 0) + stockValue * 1 >= disc && stockValue > 0) push({ kind: "buy", priority: 1, title: `Venda o estoque e compre ${goal.name}`, text: `Vendendo tudo (~${fmt(stockValue)}${taxNote}) você chega aos ${fmt(disc)} do desconto.`, why: "O desconto paga mais do que esperar uma Venda Turbinada.", command: "$vender todos" });
          else push({ kind: "skip", priority: 3, title: "Não compre nada neste desconto", text: `Faltam ${fmt(disc - (acc.coins ?? 0))} mesmo com ${pct(dRate)} off para ${goal.name}.`, why: "Itens baratos agora só atrasam a meta. Iscas Turbinadas você ganha em missões e eventos, e tickets de expedição não entram no desconto." });
        }
        break;
      }
      case "Venda Turbinada": {
        if (stockValue > 0 && sellBlocked) push({ kind: "warn", priority: 1, title: "Venda Turbinada, mas há torneio", text: "A venda fica bloqueada até o torneio acabar.", why: "Venda assim que ele terminar, se a Venda Turbinada ainda estiver no ar." });
        else if (stockValue > 0) push({ kind: "sell", priority: 1, title: "Venda o estoque agora", text: `Paga 1,25x${acc.hasCurse ? ", e com o Portador da Maldição ~1,56x no que você pescou" : ""}. Estoque: ~${fmt(stockValue)} moedas${taxNote}.`, why: "É o melhor momento para vender fora do Comprador do Porto. Proteja no site o que quer guardar (Caldeirada, encomendas, aquário).", command: sellCmd });
        else push({ kind: "info", priority: 3, title: "Venda Turbinada sem estoque", text: "Você não tem peixes para vender agora. Pesque: o que cair durante o evento já pode ser vendido com o bônus.", command: "$pescar" });
        break;
      }
      case "Comprador do Porto": {
        const words = new Set(fold(msg.replace(/_/g, "-")).split(" ").concat(msg.toLowerCase().match(/[a-z0-9_]+/g) || []));
        const wanted = acc.fish.filter((f) => f.self && !f.locked && (words.has(String(f.id).toLowerCase()) || (f.name && fold(msg).includes(fold(f.name)))));
        const species = [...new Set(wanted.map((f) => f.id))];
        if (species.length && sellBlocked) push({ kind: "warn", priority: 1, title: "Comprador do Porto, mas há torneio", text: "A venda está bloqueada até o torneio acabar.", why: "Venda as espécies pedidas logo depois." });
        else if (species.length) push({ kind: "sell", priority: 1, title: "Venda para o Comprador do Porto", text: `Você tem ${species.map((id) => acc.fish.find((f) => f.id === id).name).join(", ")}: ele paga 2,5x (até 2 de cada) só pelo $vender.${species.length > 1 ? ` Venda também: ${species.slice(1).map((id) => `$vender ${id} 2`).join(", ")}.` : ""}`, why: "É o maior multiplicador de venda do jogo, e a autovenda não conta.", command: `$vender ${species[0]} 2` });
        else push({ kind: "info", priority: 3, title: "Comprador do Porto", text: "Você não tem as espécies pedidas. Se pescar uma durante o evento, venda com $vender <espécie>.", command: "$pescar" });
        break;
      }
      case "XP em Dobro": {
        const bait = milagrosa ? "isca_milagrosa" : turbinada ? "isca_turbinada" : null;
        push({ kind: "fish", priority: 1, title: "Pesque o máximo agora", text: `Pontos e XP em dobro por 10 min (cooldown já zerado). Seu ritmo: ~${eco.castsPerHour.toFixed(1)} lançadas/h.`, why: "XP em dobro acelera o nível, que aumenta chance de fisgar, raridade e venda.", command: "$pescar" });
        if (bait && equipped !== bait) push({ kind: "bait", priority: 1, title: `Equipe ${bait === "isca_milagrosa" ? "1 Isca Milagrosa" : "Iscas Turbinadas"}`, text: bait === "isca_milagrosa" ? "Garante Raro ou melhor: com XP em dobro, um Raro vale ~20x um Comum." : "Garante a fisgada: nenhuma lançada perdida no evento.", why: "Iscas rendem mais em eventos que multiplicam pontos.", command: `$isca ${bait} ${bait === "isca_milagrosa" ? 1 : Math.min(turbinada, 3)}` });
        // Turbo: o cálculo completo (moedas + XP) está em "Itens"; aqui só o aviso quando não compensa
        const extra = Math.max(0, 15 - 5 / eco.cdMin);
        const coinsT = extra * eco.bite * eco.fishValue, xpT = extra * eco.bite * eco.evPts * 2;
        push({ kind: "skip", priority: 3, tag: "evitar", title: "Turbo de Pesca: veja em Itens", text: `No XP em Dobro rende ~${fmt(coinsT)} moedas e ~${fmt(xpT)} XP por 200.`, why: "O Guia só manda comprar quando moedas + XP passam o custo." });
        break;
      }
      case "Maré Turbo": push({ kind: "fish", priority: 1, title: "Pesque sem parar", text: `Cooldown pela metade: ${(eco.cdMin / 2).toFixed(1)} min por 10 min.`, why: "Dobra suas lançadas sem gastar nada.", command: "$pescar" }); break;
      case "Sorte Rara": {
        const t = tierInMsg && tierInMsg !== "common" ? tierInMsg : null;
        if (t && !reaches(t)) push({ kind: "skip", priority: 2, title: `Sorte Rara de ${L(t)}: sua vara não alcança`, text: "A raridade sorteada está acima do seu teto.", why: "Pesque normalmente; a meta continua sendo a próxima vara.", command: "$pescar" });
        else {
          push({ kind: "fish", priority: 1, title: `Pesque: ${t ? L(t) : "uma raridade"} com 3x de chance`, text: "Cooldown já zerado. Dura 10 min.", why: "Melhor janela para pegar um peixe que sobe você no ranking de melhor captura.", command: "$pescar" });
          if (milagrosa && equipped !== "isca_milagrosa" && (!t || TIERS.indexOf(t) >= TIERS.indexOf("legendary"))) push({ kind: "bait", priority: 1, title: "Use 1 Isca Milagrosa", text: `Você tem ${milagrosa}. Ela garante Raro ou melhor, e a Sorte Rara triplica ${t ? L(t) : "a raridade sorteada"}.`, why: "É o melhor uso possível de uma Milagrosa.", command: "$isca isca_milagrosa 1" });
        }
        break;
      }
      case "Cardume Passageiro": push({ kind: "fish", priority: 1, title: "Pesque: a espécie do cardume morde 10x mais", text: "E paga o dobro do bônus de destaque. Cooldown já zerado.", why: "Se a espécie for Rara ou melhor, use uma Milagrosa.", command: "$pescar" }); break;
      case "Garrafa ao Mar": push({ kind: "fish", priority: 2, title: "Dê uma lançada", text: "A primeira lançada tem 35% de chance de trazer Isca Turbinada, Fertilizante, Incubadora ou Ticket da Baía.", why: "Item grátis por uma lançada.", command: "$pescar" }); break;
      case "Rede Coletiva": push({ kind: "fish", priority: 2, title: "Pesque pelo menos uma vez", text: "30% do valor de cada peixe vai para um pote dividido entre quem pescou, mais uma Isca Turbinada.", why: (acc.casts ?? 99) < 10 ? `O prêmio exige 10 lançadas no barco; você tem ${acc.casts}.` : "Participar já rende.", command: "$pescar" }); break;
      case "Peso Pesado": {
        const heavy = ["isca_de_chumbo", "isca_de_fundo"].find((b) => (num(acc.baits[b]) ?? 0) > 0);
        push({ kind: "fish", priority: 2, title: "Concurso Peso Pesado: vale seu primeiro peixe", text: heavy ? `Equipe ${heavy.replace("isca_de_", "Isca de ")} antes de lançar.` : "Lance uma vez. Prêmio: Incubadora e +1 ascensão no peixe.", why: "Só a primeira captura conta.", command: heavy ? `$isca ${heavy} 1` : "$pescar" });
        break;
      }
      case "Concurso do Menor Peixe": {
        const heavyOn = ["isca_de_chumbo", "isca_de_fundo"].includes(equipped);
        push({ kind: "fish", priority: 2, title: "Concurso do Menor Peixe: lance uma vez", text: heavyOn ? "Você está com isca de peso equipada: ela empurra o peixe para cima, o contrário do que o concurso quer. Troque antes de lançar." : "Vale o primeiro peixe de cada um, o mais perto do peso mínimo da espécie. Prêmio: 5 Iscas Turbinadas.", why: "Custa uma lançada (o cooldown já foi zerado).", command: heavyOn ? "$isca isca_turbinada 1" : "$pescar" });
        break;
      }
      case "Coins em Dobro": push({ kind: "info", priority: 4, title: "Coins em Dobro", text: "Bits e subs rendem o dobro de twishcoins agora.", why: "Só importa se você já ia apoiar a live." }); break;
      case "Invasão Pirata": {
        // Fases do Twish: "open" = valendo (corrida pela raridade-alvo); "active" = afugentados;
        // "failed" = os piratas venceram: levam as próximas capturas do barco (loot.left) e o barco
        // pode pagar o resgate com $pagar (até 100 por pessoa) para os peixes voltarem aos donos.
        if (ev.phase === "failed") {
          const left = num(ev.loot?.left) ?? 0;
          const paid = num(ev.ransom?.paid) ?? 0, target = num(ev.ransom?.target) ?? num(ctx?.manual?.grandes_eventos?.invasao_pirata?.target) ?? 300;
          const capPay = num(ctx?.manual?.grandes_eventos?.invasao_pirata?.cap_per_player) ?? 100;
          const ransomOpen = !!ev.ransom && paid < target;
          if (left > 0) push({ kind: "warn", priority: 1, title: "Os piratas venceram: segure o $pescar", text: `Eles ainda levam ${left === 1 ? "a próxima captura" : `as próximas ${left} capturas`} do barco. Se você pescar agora, o seu peixe pode ir para eles.`, why: ransomOpen ? "Espere o saque acabar (cada pescador perde no máximo 2) ou ajude o resgate: pago, os peixes levados voltam para os donos." : "Espere o saque acabar para voltar a pescar." });
          else push({ kind: "info", priority: 3, title: "Invasão Pirata: os piratas venceram", text: ransomOpen ? "O saque acabou. Dá para pagar o resgate e devolver os peixes levados." : "O saque acabou: pesque normalmente.", why: "A corrida pela raridade-alvo já terminou." });
          const amount = Math.min(capPay, target - paid, Math.floor(acc.coins ?? 0));
          if (ransomOpen && amount > 0) push({ kind: "info", priority: 2, title: `Resgate: ${paid}/${target} twishcoins`, text: `Cada pessoa paga até ${capPay} com $pagar <quantidade>. Com o resgate pago, os peixes levados voltam para os donos.`, why: "Vale se os piratas levaram peixe seu ou da tripulação. Se não, não precisa pagar.", command: `$pagar ${amount}` });
          break;
        }
        if (ev.phase === "active") { push({ kind: "info", priority: 3, title: "Piratas afugentados", text: ev.message || "Alguém fisgou a raridade-alvo a tempo: pesque normalmente.", why: "A corrida já terminou." }); break; }
        const t = tierInMsg;
        if (t && !reaches(t)) push({ kind: "skip", priority: 3, title: `Invasão Pirata (${L(t)}): fora do seu alcance`, text: "Pesque normalmente; se os piratas vencerem, levam as próximas capturas do barco.", why: "Não gaste Milagrosa aqui." });
        else push({ kind: "fish", priority: 1, title: `Invasão Pirata${t ? ` (${L(t)})` : ""}: pesque`, text: "O primeiro a fisgar a raridade-alvo leva 50 moedas.", why: milagrosa && t === "rare" ? "Com alvo Raro, uma Milagrosa praticamente garante." : "Corrida contra o chat.", command: milagrosa && t === "rare" && equipped !== "isca_milagrosa" ? "$isca isca_milagrosa 1" : "$pescar" });
        break;
      }
      case "Julgamento de Njord":
        // "active" = meta batida (Lendário+ para qualquer vara); "failed" = não bateu.
        if (ev.phase === "active") { push({ kind: "fish", priority: 1, title: "Julgamento de Njord: Lendário+ valendo", text: "A meta foi batida: qualquer vara fisga Lendário ou melhor até o tempo acabar.", why: milagrosa ? "Hora de usar a Isca Milagrosa." : "Cada lançada agora vale muito.", command: "$pescar" }); break; }
        if (ev.phase === "failed") { push({ kind: "info", priority: 3, title: "Julgamento de Njord: a meta não foi batida", text: "Pesque normalmente.", why: "O evento acabou sem o bônus." }); break; }
        push({ kind: "fish", priority: 1, title: "Julgamento de Njord: ajude a bater 40 peixes", text: "Batida a meta, qualquer vara fisga Lendário+ por 10 min.", why: reach === "rare" ? "Para você é a chance de pegar Lendário sem Vara de Aço. Guarde Milagrosas para esses 10 min." : "Vale mais para quem tem vara fraca, mas pescar ajuda o barco.", command: "$pescar" }); break;
      case "O Kraken":
        if (ev.phase === "failed") { push({ kind: "info", priority: 3, title: "O Kraken escapou", text: "Não adianta mais pescar para causar dano.", why: "O evento acabou sem derrotar o Kraken." }); break; }
        if (ev.phase === "active") { push({ kind: "info", priority: 3, title: "O Kraken foi derrotado", text: ev.message || "O saque sai para quem ajudou.", why: "Não precisa mais causar dano." }); break; }
        push({ kind: "fish", priority: 2, title: "Kraken: pesque para causar dano", text: "Quem ajuda ganha 2 Iscas Turbinadas; a metade que mais bate ganha Fertilizante; MVP e golpe final ganham Incubadora.", why: (acc.casts ?? 99) < 10 ? `O saque exige 10 lançadas no barco; você tem ${acc.casts}.` : "Peixe com 90% do peso máximo bate em dobro: use Graxa ou Isca de Fundo se tiver.", command: "$pescar" }); break;
      case "Caldeirada": {
        // Fases do Twish (as mesmas que o site usa): "open" = cozinhando, "active" = panela cheia e
        // Banquete valendo, "failed" = o tempo acabou sem encher. Panela cheia também pelo contador.
        const pc = num(ev.progress_count), pt = num(ev.progress_target);
        if (ev.phase === "active" || (pc !== null && pt !== null && pt > 0 && pc >= pt)) {
          push({ kind: "fish", priority: 1, title: "Banquete da Caldeirada: pesque", text: "A panela encheu: fisgada garantida para todo mundo no canal até o tempo acabar.", why: "Toda lançada agora pega peixe. Não precisa mais cozinhar.", command: "$pescar" });
          break;
        }
        if (ev.phase === "failed") {
          push({ kind: "info", priority: 4, title: "Caldeirada: a panela não encheu", text: "O tempo acabou antes de completar a receita. Não há mais o que fazer.", why: "O evento está terminando." });
          break;
        }
        // Receita do manual: 8 comum de ÁGUA DOCE, 4 incomum, 2 marisco (qualquer raridade), 1 raro (só com 3+ pescando).
        // Peixe de água salgada comum (sardinha, aji, manjuba) NÃO entra no espaço dos comuns.
        const def = ctx?.manual?.grandes_eventos?.caldeirada?.recipe || [
          { count: 8, label: "comum de água doce", tier: "common" }, { count: 4, label: "incomum", tier: "uncommon" },
          { count: 2, label: "marisco", tier: null }, { count: 1, label: "raro", tier: "rare", min_active: 3 }];
        const live = Array.isArray(ev.recipe) ? ev.recipe : null; // o site manda {label, count, filled}
        const groupOf = ctx?.groupOf || ((f) => f.group ?? null);
        const slots = def.map((d) => {
          const l = live?.find((x) => fold(x.label) === fold(d.label));
          return { ...d, count: num(l?.count) ?? d.count, filled: num(l?.filled) ?? 0, required: live ? !!l : true };
        }).filter((s) => s.required && s.filled < s.count);
        const fits = (s, f) => {
          const lab = fold(s.label);
          if (/marisco/.test(lab)) return groupOf(f) === "shellfish";
          if (s.tier && f.tier !== s.tier) return false;
          if (/agua doce/.test(lab)) return groupOf(f) === "freshwater";
          if (/agua salgada/.test(lab)) return groupOf(f) === "saltwater";
          return true;
        };
        const pool = acc.fish.filter((f) => !f.locked && !f.listed && f.tier !== "ancient_god" && !(ctx?.reserved || []).includes(f.id));
        const cap = num(ctx?.manual?.grandes_eventos?.caldeirada?.cap_per_player) ?? 5;
        const PRICE_CAP = 15; // o Banquete vale ~2 lançadas garantidas: não entregue peixe caro
        // Mais barato primeiro, em qualquer espaço que ainda falta. Marisco só vai no espaço de marisco
        // (para não gastar ostra/caranguejo no espaço dos incomuns). O raro só quando o site mostra
        // esse espaço na panela (ele só existe com 3+ pescando).
        const left = Object.fromEntries(slots.map((s) => [s.label, s.count - s.filled]));
        const open = slots.filter((s) => s.tier !== "rare" || live);
        const slotFor = (f) => open.find((s) => left[s.label] > 0 && fits(s, f) && (groupOf(f) !== "shellfish" || /marisco/.test(fold(s.label))));
        const picks = [];
        // Nunca mais do que o limite por pessoa nem do que ainda falta na panela.
        const limit = Math.min(cap, pc !== null && pt !== null ? Math.max(0, pt - pc) : cap);
        for (const f of pool.filter((f) => f.price <= (f.tier === "rare" ? 30 : PRICE_CAP)).sort((a, b) => a.price - b.price)) {
          if (picks.length >= limit) break;
          const s = slotFor(f);
          if (!s) continue;
          left[s.label]--; picks.push({ f, slot: s.label });
        }
        const by = {};
        for (const p of picks) (by[p.f.id] = by[p.f.id] || { f: p.f, n: 0, slot: p.slot }).n++;
        const list = Object.values(by);
        const missing = slots.map((s) => `${s.count - s.filled} ${s.label}`).join(", ");
        if (list.length) {
          const cmds = list.flatMap((x) => Array(x.n).fill(`$cozinhar ${x.f.id}`));
          push({ kind: "fish", priority: 2, title: `Caldeirada: cozinhe ${list.map((x) => `${x.n}× ${x.f.name}`).join(", ")}`, text: `${list.map((x) => `${x.f.name} → ${x.slot}`).join("; ")}. Um comando por peixe: ${cmds.join(", ")}.${live ? ` Falta na panela: ${missing}.` : ""}`, why: `Só entram peixes da receita: comum tem de ser de água doce (sardinha, aji e manjuba são de água salgada e não entram); marisco é siri, camarão, mexilhão, ostra, caranguejo... Sai sempre o seu exemplar mais barato da espécie. Cada pessoa entrega no máximo ${cap}: o Twish não mostra quantos você já mandou, então, se já entregou alguns, mande só o que falta para ${cap}.`, command: cmds[0] });
        } else push({ kind: "info", priority: 3, title: "Caldeirada: nada seu entra na receita", text: `${live ? `Falta na panela: ${missing}. ` : ""}Pesque: comum de água doce (bagre, tilápia, lambari...), incomum ou marisco entram na panela.`, why: "Peixe de água salgada comum não entra; peixe protegido ou anunciado no Mercado também não.", command: "$pescar" });
        break;
      }
      case "Tempestade": push({ kind: "warn", priority: 1, title: "Tempestade: proteja antes de pescar", text: "A onda leva 20% das lançadas. Proteja no site as espécies que você quer guardar.", why: reaches("mythic") ? "Mítico e Secreto mordem 2x: vale pescar, protegido." : "Sua vara não alcança Mítico: pescar agora rende pouco.", command: reaches("mythic") ? "$pescar" : null }); break;
      case "Barco Misterioso": {
        // Identidades do manual. Pagar a tempo é melhor em 4 de 5 (só Bergelmir bloqueia o $pescar).
        const blob = fold(JSON.stringify(ev));
        const who = ["bergelmir", "jormungandr", "ran", "thor", "aegir"].find((n) => new RegExp(`\\b${n}\\b`).test(blob.replace(/ö/g, "o").replace(/æ/g, "ae").replace(/á/g, "a")));
        const paid = /pag[ao]u|taxa paga|paid/.test(blob) && !/nao pag|não pag|unpaid/.test(blob);
        const R = {
          bergelmir: paid ? ["warn", "Bergelmir: $pescar bloqueado", "O tributo foi pago e o $pescar fica travado por 5 min.", null] : ["fish", "Bergelmir: Raro, Lendário e Mítico mordem 2x", "Pesque agora (10 min).", "$pescar"],
          jormungandr: paid ? ["fish", "Jörmungandr: toda pescaria garante Raro+", "Pesque agora (5 min). Não gaste Milagrosa: já vem Raro ou melhor.", "$pescar"] : ["warn", "Jörmungandr: cooldown 2x mais longo", "Por 10 min. Use Iscas Turbinadas nas poucas lançadas.", null],
          ran: paid ? ["fish", "Rán: peixes 1,5x mais pesados", "Bom para Peso Pesado e ascensão (5 min).", "$pescar"] : ["warn", "Rán: venda paga 0,5x", "Não venda nada por 10 min (nem autovenda).", null],
          thor: paid ? ["fish", "Thor: toda lançada fisga", "Pesque e guarde as Iscas Turbinadas (5 min).", "$pescar"] : ["warn", "Thor: fisgada cai para 10%", "Por 10 min. Se pescar, use Isca Turbinada (garante a fisgada).", "$isca isca_turbinada 2"],
          aegir: paid ? ["fish", "Ægir: toda fisgada traz um peixe extra", "Pesque agora (5 min).", "$pescar"] : ["warn", "Ægir: fisgada cai para 25%", "Por 10 min. Se pescar, use Isca Turbinada.", "$isca isca_turbinada 2"],
        };
        if (who && R[who]) push({ kind: R[who][0], priority: 1, title: R[who][1], text: R[who][2], why: "Efeito do Barco Misterioso.", command: R[who][3] });
        else push({ kind: "info", priority: 3, title: "Barco Misterioso: pagar costuma valer", text: "Meta coletiva de 500 (máx. 150 por pessoa) em 5 min. Em 4 das 5 identidades pagar é melhor; só Bergelmir trava o $pescar se for pago.", why: goal ? `Contribua pouco (os coins não voltam): sua meta é ${goal.name}.` : "Os coins não voltam.", command: "$pagar 20" });
        break;
      }
      default:
        // Eventos sem regra pelo nome: decide pelo tipo (kind) que a API manda.
        if (ev.kind === "fishing_frozen") { push({ kind: "warn", priority: 1, title: `${name}: o $pescar está bloqueado`, text: msg || "Ninguém pesca até o evento acabar.", why: "Não insista: cada tentativa só gasta mensagem no chat." }); break; }
        if (ev.kind === "bite_factor") { push({ kind: "bait", priority: 2, title: `${name}: fisgada mais difícil`, text: turbinada ? `Se for lançar, equipe Isca Turbinada (você tem ${turbinada}): ela garante a fisgada.` : "Se puder, espere o evento acabar para lançar.", why: "Não compre isca por causa disso; use as que ganhou em missões.", command: turbinada && equipped !== "isca_turbinada" ? "$isca isca_turbinada 1" : null }); break; }
        if (ev.kind === "cooldown_reset") { push({ kind: "fish", priority: 1, title: `${name}: cooldown zerado`, text: "Lance agora, não custa nada.", command: "$pescar" }); break; }
        push({ kind: "info", priority: 3, title: `Evento novo: ${name}`, text: msg || "Use $evento para ver as regras.", why: "O Guia ainda não tem regra para este evento. Veja 📜 Novidades.", command: "$evento" }); break;
    }
    return out;
  }

  // ---------- expedições ----------
  // Salas e Frota abertas no cais (resposta de /api/<barco>/expeditions).
  function harbourOpen(harbour, boat, handle) {
    const rooms = Array.isArray(harbour?.rooms) ? harbour.rooms : [];
    const ownerBoat = (r) => (r.crew || []).find((c) => c.owner)?.boat || r.boat || null;
    const inCrew = (r) => (r.crew || []).some((c) => handle && fold(c.handle) === fold(handle));
    const max = (r) => (r.kind === "fleet" ? harbour?.fleet?.max_crew ?? 16 : harbour?.max_crew ?? 4);
    const lobby = (r) => !r.started && (!r.state || /lobby|open|waiting|forming|boarding/.test(r.state));
    const mine = rooms.filter((r) => lobby(r) && ownerBoat(r) === boat);
    const fleet = mine.find((r) => r.kind === "fleet") || null;
    return {
      fleet: fleet ? { id: fleet.id, crew: (fleet.crew || []).length, max: max(fleet), joined: inCrew(fleet) } : null,
      rooms: mine.filter((r) => r.kind !== "fleet").map((r) => ({ id: r.id, sea: r.sea, crew: (r.crew || []).length, max: max(r), joined: inCrew(r) })),
      fleetInfo: harbour?.fleet ? { available: num(harbour.fleet.available), minCasts: num(harbour.fleet.min_casts), castsHere: num(harbour.casts_here), goal: num(harbour.fleet.goal_centavos), progress: num(harbour.fleet.progress_centavos) } : null,
      onVoyage: (harbour?.voyages || []).some((v) => v.state !== "finished" && v.state !== "closed" && (v.crew || []).some((c) => handle && fold(c.handle) === fold(handle))),
    };
  }

  // A maré vira a cada 6 h: 0h, 6h, 12h e 18h de Brasília (UTC−3, sem horário de verão).
  function tideTurn(now = Date.now()) {
    const SIX = 6 * 3600e3, BRT = 3 * 3600e3;
    const at = (Math.floor((now - BRT) / SIX) + 1) * SIX + BRT;
    const h = new Date(at - BRT).getUTCHours();
    return { at, label: h === 0 ? "à meia-noite" : h === 12 ? "ao meio-dia" : `às ${h}h` };
  }

  function expeditionVerdict(acc, eco, goal, tides, data, nowMs = Date.now()) {
    const turn = tideTurn(nowMs).label;
    const A = root.TimoneiroAdvisors;
    const stockAvg = acc.fish.length ? acc.fish.reduce((x, f) => x + f.price, 0) / acc.fish.length : 10;
    const ctx = { avgPts: eco.avgPts, sellBonus: 1 + 0.3 * ((acc.level ?? 0) / 150), curse: acc.hasCurse ? 1.25 : 1, bite: eco.bite, coins: acc.coins, rodId: acc.rodId,
      avgStockPrice: stockAvg, tides, manual: data?.manual, live: Array.isArray(data?.expeditions?.seas) ? data.expeditions.seas : null, marketRatio: Object.fromEntries(Object.entries(data?.marketStats?.tiers || {}).filter(([, v]) => v.n >= 5).map(([k, v]) => [k, v.ratio])) };
    const ev = A ? A.expeditionPlan(ctx) : { rows: [], breakEven: {} };
    const open = harbourOpen(data?.expeditions, opts_boat(data), acc.handle);
    const actions = [];
    const now = [];
    if (open.fleet && !open.fleet.joined && !open.onVoyage) now.push({ tag: "agora", kind: "sea", priority: 1, title: `Frota do Capitão aberta (${open.fleet.crew}/${open.fleet.max})`, text: "Viagem grátis à Baía. Zarpa em até 10 minutos.", why: "Não custa nada, rende peixes exclusivos e conta para a missão Marujo e o Tridente.", command: "$embarcar" });
    else if (open.fleet?.joined) now.push({ tag: "agora", kind: "sea", priority: 2, title: "Você está na Frota", text: "Ao zarpar, use $pescar no chat: a primeira lançada no mar sai na hora.", why: "No mar só a vara conta; anzol, iscas e eventos não valem." });
    else actions.push({ kind: "sea", priority: 2, tag: "plano", title: "Frota do Capitão: sempre embarque", text: "Quando a streamer abrir $frota, digite $embarcar.", why: "Viagem grátis à Baía das Lendas, com qualquer vara, e conta para a missão Marujo.", command: "$embarcar" });

    const rows = ev.rows.filter((r) => !r.locked);
    // "Faça agora" e "Não faça" conversam: uma recomendação só por mar. Para decidir, os mesmos mares
    // com a maré normal (sem a de hoje) e pagando o ticket (como se você não tivesse um).
    const strip = (live) => (Array.isArray(live) ? live.map(({ tide, ...x }) => x) : live);
    const normal = A ? A.expeditionPlan({ ...ctx, tides: {}, live: strip(ctx.live) }).rows.filter((r) => !r.locked) : rows;
    const paid = A ? A.expeditionPlan({ ...ctx, live: Array.isArray(ctx.live) ? ctx.live.map((x) => ({ ...x, entry_owned: 0 })) : ctx.live }).rows.filter((r) => !r.locked) : rows;
    const netOf = (list, sea) => { const n = list.find((x) => x.sea === sea)?.net; return Number.isFinite(n) ? n : null; };
    const tideOf = (r) => tides[r.sea] || tides._any || null;
    const guarded = new Set(), decided = new Set();
    for (const r of rows.filter((x) => x.ticketOwned)) {
      const turvas = tideOf(r) === "turvas";
      const later = turvas ? netOf(normal, r.sea) : null, paidToday = netOf(paid, r.sea);
      // Águas Turvas e a viagem só vale por causa do ticket: com a maré normal ele rende mais.
      if (turvas && later != null && later > r.net && !(paidToday > 0)) {
        guarded.add(r.sea); decided.add(r.sea);
        actions.push({ tag: "plano", kind: "sea", priority: 3, title: `Guarde o ticket de ${r.name} para a próxima maré`, text: `Agora a maré é Águas Turvas e as exclusivas caem pela metade: ~${fmt(r.net)} moedas agora contra ~${fmt(later)} com a maré normal.`, why: `A maré vira ${turn} (muda a cada 6 horas) e o ticket continua com você. A Frota grátis continua valendo.`, link: "expedicoes" });
        continue;
      }
      decided.add(r.sea);
      (r.net > 0 ? now : actions).push({ tag: r.net > 0 ? "agora" : "plano", kind: "sea", priority: r.net > 0 ? 2 : 3, title: `Use o ticket que você já tem: ${r.name}`, text: `${r.casts} lançadas, ~${r.fish.toFixed(1)} peixes, ~${fmt(r.net)} moedas sem contar o ticket${r.insure ? " (leve o seguro)" : ""}.${turvas ? " A maré Águas Turvas corta as exclusivas pela metade, mas a viagem ainda compensa agora." : ""}`, why: "O ticket já está pago; a viagem só soma. Faça a primeira do dia para as encomendas valerem.", link: "expedicoes" });
    }
    const pool = rows.filter((r) => !guarded.has(r.sea));
    const best = [...pool].sort((a, b) => b.net - a.net)[0] || null;
    for (const room of open.rooms) {
      const row = rows.find((r) => r.sea === room.sea);
      if (room.joined || !row) continue;
      now.push({ tag: "agora", kind: "sea", priority: row.net > 0 ? 1 : 3, title: `Sala aberta: ${row.name} (${room.crew}/${room.max})`, text: `Viagem em grupo diminui o perigo (−10% por tripulante). Estimativa solo: ${row.net >= 0 ? "+" : ""}${fmt(row.net)} moedas.`, why: row.net > 0 ? "Compensa em moedas com a sua vara." : "Em moedas não compensa; vale pela missão Marujo, Tridente e peixes raros.", link: "expedicoes" });
    }
    if (!rows.length) return { verdict: "frota", label: "Só a Frota grátis", why: "Sua vara ainda não alcança nenhum mar pago.", actions, now, rows: ev.rows, breakEven: ev.breakEven, open };
    if (!best) return { verdict: "depois", label: "Na próxima maré", why: `Guarde o ticket: a maré vira ${turn} e, com a maré normal, a viagem rende mais.`, actions, now, rows: ev.rows, breakEven: ev.breakEven, open };

    // Melhor mar com Águas Turvas hoje: só compensa com a maré normal? Então um "não faça" só, com os números.
    const bestTurvas = tideOf(best) === "turvas" && !decided.has(best.sea);
    const bestLater = bestTurvas ? netOf(normal, best.sea) : null;
    const be =Object.entries(ev.breakEven).map(([sea, rod]) => `${(rows.find((r) => r.sea === sea) || {}).name || sea}: a partir da ${(acc.cat.rods.find((r) => r.id === rod) || {}).name || rod}`).join(" · ");
    if (best && best.net > 0) {
      const cost = best.ticket + (best.insure ? best.risk : 0);
      if ((acc.coins ?? 0) < cost) return { verdict: "depois", label: "Depois", why: `${best.name} compensa (+${fmt(best.net)}), mas faltam ${fmt(cost - (acc.coins ?? 0))} para o ticket${best.insure ? " e o seguro" : ""}.`, actions, now, rows: ev.rows, breakEven: ev.breakEven, open };
      // Com ticket, o "Use o ticket" já diz para ir: não repete o mesmo mar aqui.
      if (!best.ticketOwned) actions.push({ kind: "sea", priority: 3, tag: "plano", title: `Expedição solo: ${best.name}${best.insure ? " com seguro" : ""}`, text: `${best.casts} lançadas, ~${best.fish.toFixed(1)} peixes, líquido estimado +${fmt(best.net)} moedas${best.tideLabel ? ` (maré ${best.tideLabel})` : ""}.${bestTurvas ? " Mesmo com as exclusivas pela metade, compensa agora." : ""}`, why: "Faça a primeira viagem do dia: as 3 encomendas só pagam uma vez por dia.", link: "expedicoes" });
      return { verdict: "sim", label: `Vale a pena (${best.name})`, why: `Estimativa: +${fmt(best.net)} moedas por viagem.`, actions, now, rows: ev.rows, breakEven: ev.breakEven, open };
    }
    if (bestTurvas && bestLater != null && bestLater > 0) {
      const whyTide = `Agora a maré Águas Turvas deixa ${best.name} em ${fmt(best.net)} moedas; com a maré normal fica em +${fmt(bestLater)}.`;
      actions.push({ kind: "skip", tag: "evitar", priority: 3, title: `Não pague expedição para ${best.name} nesta maré`, text: `Águas Turvas cortam as exclusivas pela metade: ~${fmt(best.net)} moedas agora contra ~+${fmt(bestLater)} com a maré normal.`, why: `A maré vira ${turn} (muda a cada 6 horas). A Frota grátis continua valendo.` });
      return { verdict: "nao", label: "Agora não (maré)", why: whyTide, actions, now, rows: ev.rows, breakEven: ev.breakEven, open };
    }
    const why = `Em moedas, a melhor opção dá ${fmt(best.net)} por viagem (${best.name}). ${be ? `No seu nível, passa a compensar — ${be}.` : `No seu nível (${acc.level ?? "?"}), nenhuma vara deixa os mares pagos positivos sem maré boa; com nível mais alto a Baía vira lucro a partir da Njord.`}`;
    actions.push({ kind: "skip", tag: "evitar", priority: 3, title: "Não faça expedição paga solo agora", text: `${best.name}: ${best.casts} lançadas, ~${best.fish.toFixed(1)} peixes, ${fmt(best.net)} moedas estimadas por viagem.`, why: goal ? `${why} A meta é ${goal.name}.` : why });
    return { verdict: "nao", label: "Só a Frota (solo não compensa)", why, actions, now, rows: ev.rows, breakEven: ev.breakEven, open };
  }
  const opts_boat = (data) => data?.boat || root.TimoneiroBoat?.get?.() || null;

  // ---------- comparação ----------
  function benchmark(acc) {
    const b = BENCH();
    const band = (b.bands || []).find((x) => (acc.level ?? 0) >= x.min && (acc.level ?? 0) <= x.max);
    if (!band) return null;
    const typical = rodIndex(acc.cat.rods, band.rod);
    const status = acc.rodIdx > typical ? "à frente" : acc.rodIdx === typical ? "na média" : "atrás";
    return { ...band, status, sample: b.sample, sampledAt: b.sampledAt };
  }

  // ---------- plano completo ----------
  function plan(data, opts = {}) {
    const acc = normalize(data);
    const eco = economy(acc, data?.bestiary);
    const prog = progression(acc);
    const goal = prog.find((p) => !p.owned) || null;
    const phase = phaseOf(acc);
    const tides = tidesOf(data?.expeditions, acc.cat);
    const missionsReady = claimableMissions(data?.missions);
    const tourAll = root.TimoneiroAdvisors?.tournamentAdvice(data?.tournament, null) || null;
    const tour = tourAll?.active ? tourAll : null;
    const events = [data?.events?.grande_evento, data?.events?.event, data?.events?.shop_discount].filter((e) => e && e.name)
      .map((e) => ({ ...e, name: root.TimoneiroEvents?.ruleName(e) || e.name }))
      .filter((e, i, all) => all.findIndex((x) => x.name === e.name) === i);
    const discountActive = events.some((e) => e.name === "Desconto na Loja");
    // Taxa real do desconto: do evento, ou do /shop; sem desconto ativo, a última vista (padrão 20%).
    const liveRate = events.find((e) => e.name === "Desconto na Loja")?.rate ?? (num(data?.shop?.discount_rate) > 0 ? (num(data.shop.discount_rate) <= 1 ? num(data.shop.discount_rate) : num(data.shop.discount_rate) / 100) : null);
    const discountRate = liveRate || num(opts.lastDiscountRate) || 0.2;

    const goalInfo = goal && {
      id: goal.id, name: goal.name, price: goal.price, why: goal.why,
      have: acc.coins, missing: acc.coins == null ? null : Math.max(0, (goal.priceNow ?? goal.price) - acc.coins),
      // com desconto ativo, o preço é o da loja agora; sem desconto, uma estimativa de 20% off
      discounted: goal.priceNow != null && goal.priceNow < goal.price ? goal.priceNow : Math.ceil(goal.price * (1 - discountRate)),
      discountRate,
      discountNow: goal.priceNow != null && goal.priceNow < goal.price,
      hours: acc.coins == null ? null : Math.max(0, (goal.priceNow ?? goal.price) - acc.coins) / Math.max(1, eco.coinsPerHour),
    };

    const now = [];
    const avoid = [];
    const bestGroup = {};
    for (const f of Array.isArray(data?.bestiary?.fish) ? data.bestiary.fish : []) if (f?.id) bestGroup[f.id] = f.species_group ?? null;
    const groupOf = (f) => (f.group !== undefined && f.group !== null ? f.group : bestGroup[f.id] ?? CATALOG_GROUP[f.id] ?? null);
    for (const e of events) for (const a of eventActions(acc, eco, e, goal, { ...opts, tournamentActive: !!tour, groupOf, manual: data?.manual, discountRate })) (a.tag === "evitar" ? avoid : now).push(a);

    if (missionsReady > 0) now.push({ tag: "agora", kind: "claim", priority: 2, title: `Recolha ${missionsReady} missão(ões)`, text: "Inventário do site → aba Missões → Recolher.", why: "Iscas, incubadoras e moedas sem custo. Some se não recolher até o fim do período seguinte." });

    if (tour && !tour.settling) {
      const mmss = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, "0")}`;
      if (tour.joined) now.push({ tag: "agora", kind: "fish", priority: 1, title: "Torneio: pesque o maior peixe", text: `Raridade primeiro, peso desempata.${tour.leader ? ` Liderando: ${tour.leader}.` : ""}`, why: `Quem vence leva os peixes pescados no torneio e ${tour.bonus} moedas.`, command: "$pescar" });
      else if (tour.joinOpen) now.push({ tag: "agora", kind: "fish", priority: 1, title: `Entre no torneio${tour.joinLeft != null ? ` (fecha em ${mmss(tour.joinLeft)})` : ""}`, text: `Entrar zera o seu cooldown na hora. Prêmio: ${tour.bonus} moedas e os peixes da disputa.`, why: "Se perder, você entrega só o peixe pescado no torneio, não o inventário (patch de 03/11).", command: "$entrar" });
      else now.push({ tag: "agora", kind: "info", priority: 3, title: "Torneio em andamento", text: "As inscrições fecharam. $vender e duelos ficam bloqueados até acabar.", why: "Quando terminar, o cooldown de todo mundo zera: pesque logo em seguida.", command: "$rankingtorneio" });
    }

    // Plano em ordem (o que fazer depois)
    const planList = [];
    if (tourAll && !tourAll.active) {
      const h = tourAll.nextIn > 0 ? `${Math.floor(tourAll.nextIn / 3600)}h${String(Math.floor((tourAll.nextIn % 3600) / 60)).padStart(2, "0")}` : null;
      planList.push({ tag: "plano", kind: "info", priority: 5, title: "Torneio: entre assim que abrir", text: h ? `O próximo só pode começar daqui a ${h} (intervalo mínimo de 2 h).` : "Já pode começar a qualquer momento: quem abre é a streamer. O Timoneiro avisa na hora.", why: `As inscrições ficam abertas ${Math.round(tourAll.joinWindow / 60 * 10) / 10} min. Entrar zera o cooldown; quem vence leva ${tourAll.bonus} moedas e os peixes da disputa.`, command: "$entrar" });
    }
    const goalBuyNow = now.some((a) => a.kind === "buy" && a.command === `$comprar ${goal?.id}`);
    if (goalInfo && !goalBuyNow) {
      const canBuy = acc.coins != null && acc.coins >= (goal.priceNow ?? goal.price);
      const nearDiscount = acc.coins != null && !canBuy && acc.coins >= goalInfo.discounted;
      planList.push({
        tag: "plano", kind: canBuy || nearDiscount ? "buy" : "save", priority: 2,
        title: canBuy ? `Compre ${goal.name}` : nearDiscount ? `${goal.name}: espere o Desconto na Loja` : `Meta: ${goal.name}`,
        text: canBuy ? `Você já tem ${fmt(acc.coins)} de ${fmt(goal.priceNow ?? goal.price)}.${goal.price >= 3000 && !discountActive ? ` No Desconto na Loja sairia por ${fmt(goalInfo.discounted)}.` : ""}`
          : nearDiscount ? `Com ${pct(discountRate)} off sai por ${fmt(goalInfo.discounted)} e você já tem ${fmt(acc.coins)}.`
          : `Faltam ${fmt(goalInfo.missing)} de ${fmt(goal.priceNow ?? goal.price)} (~${goalInfo.hours < 1 ? "<1" : Math.round(goalInfo.hours)} h de pesca ativa).`,
        why: goal.why,
        command: canBuy || nearDiscount ? `$comprar ${goal.id}` : null,
      });
    }
    const after = prog.filter((p) => !p.owned).slice(1, 3);
    if (after.length) planList.push({ tag: "plano", kind: "info", priority: 3, title: "Depois", text: after.map((p) => `${p.name} (${fmt(p.price)})`).join(" → "), why: after[0].why });

    const milagrosa = num(acc.baits.isca_milagrosa) ?? 0;
    if (milagrosa > 0 && !events.length) planList.push({ tag: "plano", kind: "bait", priority: 3, title: `Guarde suas ${milagrosa} Milagrosa(s)`, text: "Use em Sorte Rara (Lendário+), peixe em destaque Raro+, Invasão Pirata de Raro, Julgamento de Njord ou XP em Dobro.", why: "Fora desses eventos ela vale só um Raro comum." });
    if (acc.baitEquipped === "isca_milagrosa" && !events.length) planList.push({ tag: "plano", kind: "bait", priority: 2, title: "Desequipe a Milagrosa", text: "Não há evento que multiplique o valor dela agora.", why: "Guarde para Sorte Rara, destaque Raro+ ou XP em Dobro.", command: "$desequiparisca" });

    const exp = expeditionVerdict(acc, eco, goal, tides, data, Number.isFinite(opts.now) ? opts.now : Date.now());
    now.push(...exp.now);
    planList.push(...exp.actions.filter((a) => a.tag === "plano"));


    planList.push({ tag: "plano", kind: "info", priority: 4, title: "Missões e jornada do mês", text: "Pesque em 12 dias diferentes no mês para o título da jornada e recolha as missões diárias.", why: "As missões são a fonte grátis de Milagrosas e Turbinadas." });

    const incubation = incubationPlan(acc, data, planList, avoid);
    const reserved = {};
    if (incubation?.incubators > 0 && incubation.ascend[0]) reserved[`${incubation.ascend[0].id}|${incubation.ascend[0].asc}`] = 2;
    const market = marketAdvice(acc, data, events, reserved);
    if (market.list.length) planList.push({ tag: "plano", kind: "market", priority: 3, title: `Anuncie ${market.list.length} peixe(s) no Mercado`, text: market.list.slice(0, 3).map((m) => `${m.name}${m.count > 1 ? ` ×${m.count}` : ""}: peça ~${fmt(m.ask)} cada${m.fast ? ` (rápido: ${fmt(m.fast)})` : ""}, líquido ~${fmt(m.net)} vs ${fmt(m.shop)} na loja`).join(" · "), why: "O Mercado é só no site. Use o preço sugerido; acima de ~2× o valor base o anúncio fica parado.", link: "market" });
    const changes = manualChanges(data?.manual);

    // Não faça agora
    if (market.lowValue > 0) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não anuncie comuns e raros no Mercado", text: `Ganho de poucas moedas por peixe e prende um dos ${market.slots} espaços por ${market.lockHours} h.`, why: acc.hasCurse ? "Com o Portador da Maldição a loja paga 1,25× (1,56× na Venda Turbinada) no que você pescou." : "Venda na loja, de preferência na Venda Turbinada." });
    avoid.push(...exp.actions.filter((a) => a.tag === "evitar"));
    if (acc.fish.length < acc.capacity * 0.7 && acc.bpIdx < acc.cat.backpacks.length - 1) avoid.push({ tag: "evitar", kind: "skip", priority: 3, title: "Não compre mochila", text: `Você usa ${acc.fish.length} de ${acc.capacity} espaços.`, why: "Mochila só vale para quem guarda estoque para eventos." });
    else if (acc.fish.length >= acc.capacity * 0.9) now.push({ tag: "agora", kind: "bag", priority: 2, title: `Mochila ${acc.fish.length}/${acc.capacity}`, text: "Cheia, o peixe novo vai direto para a loja.", why: "Venda o que não vai usar ou compre a próxima mochila.", command: "$vender todos" });
    if (!events.some((e) => e.name === "XP em Dobro")) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não compre Turbo nem Afiação", text: "Rendem XP, mas pouca moeda.", why: goal ? `As moedas vão para ${goal.name}.` : "Só valem com meta de XP." });
    if (!events.some((e) => ["Venda Turbinada", "Comprador do Porto"].includes(e.name)) && acc.fish.length && acc.fish.length < acc.capacity * 0.9) {
      const toMarket = new Set(market.list.map((m) => m.id));
      const stock = acc.fish.filter((f) => !toMarket.has(f.id) && !f.locked).reduce((s, f) => s + f.price, 0);
      if (stock > 0) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não venda agora", text: `Espere uma Venda Turbinada: +25% em ~${fmt(stock)} = +${fmt(stock * 0.25)}.`, why: "Venda fora de evento só se precisar completar uma compra." });
    }
    if (!acc.hook && acc.rodIdx < rodIndex(acc.cat.rods, "vara_njord")) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não pule para o Anzol Duplo", text: "Antes vêm as varas até a Lendária/Njord.", why: "No mar só a vara conta, e é lá que caem os peixes mais valiosos. Os jogadores fortes seguem essa ordem." });

    const nextLevelXp = acc.level != null && acc.level < 150 ? 10 * (acc.level + 1) ** 2 : null;
    const levelHours = nextLevelXp != null && acc.xp != null ? Math.max(0, nextLevelXp - acc.xp) / Math.max(1, eco.xpPerHour) : null;
    const sortP = (a, b) => a.priority - b.priority;
    // itens: só recomenda comprar quando o saldo (moedas + XP convertido) é positivo
    const items = itemsAdvice(acc, eco, data, events, tour);
    for (const r of items.rows) {
      if (r.id === "turbo_torneio" && r.net > 0 && tour?.joined) now.push({ tag: "agora", kind: "buy", priority: 2, title: "Turbo Torneio compensa agora", text: `${r.note}. Saldo esperado ~+${fmt(r.net)} (já contando os 250).`, why: "Com muita gente no torneio, o prêmio (70 + os peixes de todos) passa o custo.", command: "$comprar turbo_torneio" });
      if (r.id === "turbo" && r.net > 0) now.push({ tag: "agora", kind: "buy", priority: 3, title: "Turbo de Pesca compensa agora", text: `${r.note}: ~${fmt(r.coins)} moedas e ~${fmt(r.xp)} XP por ${fmt(r.cost)}.`, why: `Saldo ~+${fmt(r.net)} contando o XP (1 XP ≈ ${items.xpValue.toFixed(2)} moeda).`, command: "$comprar turbo" });
    }
    // "Faça agora"/"Plano" e "Não faça" conversam antes de aparecer (ver reconcile).
    const talk = reconcile(now, planList, avoid);
    now.splice(0, now.length, ...talk.now); planList.splice(0, planList.length, ...talk.plan); avoid.splice(0, avoid.length, ...talk.avoid);
    now.sort(sortP); planList.sort(sortP); avoid.sort(sortP);
    const top = now[0] || planList[0] || null;

    return {
      account: { coins: acc.coins, level: acc.level, xp: acc.xp, casts: acc.casts, nextLevelXp, levelHours, rod: acc.rod, hook: acc.hook, capacity: acc.capacity, fishCount: acc.fish.length, stockValue: Math.round(acc.fish.reduce((s, f) => s + f.price, 0) * (1 - (acc.saleTax || 0))), saleTax: acc.saleTax || 0, baits: acc.baits, titleBonus: acc.titleBonus, hasCurse: acc.hasCurse, handle: acc.handle, titles: acc.titleIds.length,
        best: acc.pub?.best_catch ? `${acc.pub.best_catch.name} (${TIER_LABEL[acc.pub.best_catch.tier] || acc.pub.best_catch.tier}, ${acc.pub.best_catch.weight} kg)` : null },
      economy: eco, phase, goal: goalInfo, now, plan: planList, avoid, expedition: { verdict: exp.verdict, label: exp.label, why: exp.why, tides, rows: exp.rows, breakEven: exp.breakEven, open: exp.open, observed: data?.voyageStats?.seas || null }, incubation,
      benchmark: benchmark(acc), top, missionsReady, tournament: tourAll, market, changes, PRIORITY, items,
    };
  }

  // ---------- conversa entre "faça" e "não faça" ----------
  // Cada parte do Guia decide sozinha; aqui as decisões se olham, para nunca mandar fazer e proibir a
  // mesma coisa ao mesmo tempo. Vale também para quem lê: um assunto, uma recomendação.
  function reconcile(now, plan, avoid) {
    let nowOut = [...now], planOut = [...plan], avoidOut = [...avoid];
    const doing = [...nowOut, ...planOut];
    const has = (re) => doing.some((x) => re.test(x.title) || re.test(x.command || ""));
    // Venda: "Não venda agora" já abre exceção para completar uma compra; quando o Guia manda vender
    // para comprar (ou vender agora), o "não venda" sai.
    if (has(/^Venda o estoque|^\$vender todos$/)) avoidOut = avoidOut.filter((x) => x.title !== "Não venda agora");
    // Mercado: quais anunciar e quais não, num item só.
    const sell = planOut.find((x) => /^Anuncie \d+ peixe/.test(x.title));
    const noLow = avoidOut.find((x) => x.title === "Não anuncie comuns e raros no Mercado");
    if (sell && noLow) {
      const low = String(noLow.text || "").replace(/\.$/, "");
      planOut = planOut.map((x) => (x === sell ? { ...x, why: `${x.why ? `${String(x.why).replace(/\.?$/, ".")} ` : ""}Comuns e raros ficam de fora: ${low.charAt(0).toLowerCase()}${low.slice(1)}.` } : x));
      avoidOut = avoidOut.filter((x) => x !== noLow);
    }
    // Turbo: se os itens dizem que compensa, saem os avisos contrários (Afiação continua não valendo).
    if (has(/^Turbo de Pesca compensa/)) {
      avoidOut = avoidOut.filter((x) => x.title !== "Turbo de Pesca: veja em Itens")
        .map((x) => (x.title === "Não compre Turbo nem Afiação" ? { ...x, title: "Não compre Afiação", text: "Rende XP, mas pouca moeda." } : x));
    }
    return { now: nowOut, plan: planOut, avoid: avoidOut };
  }

  // ---------- itens: vale a pena usar? (moedas E nível) ----------
  // Cada item vira lançadas, fisgadas ou bônus; o retorno é medido em moedas e em XP. O XP vira
  // moedas pelo que o próximo nível acrescenta à sua renda por hora (mais fisgada, mais raros,
  // mais preço de venda), somado por XP_HORIZON_H horas de pesca ativa.
  const XP_HORIZON_H = 150;
  const xpToLevel = (L) => 10 * L * L;
  function xpValue(acc, bestiary) {
    const L = acc.level ?? 0;
    const a = economy(acc, bestiary), b = economy({ ...acc, level: L + 1 }, bestiary);
    const need = Math.max(1, xpToLevel(L + 1) - xpToLevel(L));
    return Math.max(0, ((b.coinsPerHour - a.coinsPerHour) / need) * XP_HORIZON_H);
  }
  // valor e pontos médios por peixe, com um tier multiplicado (Sorte Rara) ou só Raro+ (Milagrosa)
  function fishStats(acc, eco, opts = {}) {
    const cap = TIERS.indexOf(reachTier(acc));
    const w = {}; let total = 0;
    for (const t of TIERS.slice(0, cap + 1)) {
      if (!TIER_WEIGHT[t]) continue;
      if (opts.minRare && TIERS.indexOf(t) < TIERS.indexOf("rare")) continue;
      w[t] = TIER_WEIGHT[t] * (t === "common" ? 1 : eco.tierBoost) * (opts.boostTier === t ? 3 : 1);
      total += w[t];
    }
    let pts = 0;
    for (const t in w) pts += (w[t] / total) * eco.avgPts[t];
    return { pts, value: pts * PRICE_PER_POINT * eco.sell, w, total };
  }

  function itemsAdvice(acc, eco, data, events, tour) {
    const cat = acc.cat;
    const find = (list, id) => (list || []).find((x) => x.id === id) || {};
    const xpv = xpValue(acc, data?.bestiary);
    const evName = events.map((e) => e.name);
    const xpMult = (evName.includes("XP em Dobro") ? 2 : 1) * (1 + (acc.titleBonus || 0) / 100);
    const sorte = events.find((e) => e.name === "Sorte Rara");
    const sorteTier = sorte ? (tierOfEvent(sorte) === "common" ? null : tierOfEvent(sorte) || null) : null;
    const cdSec = eco.cdMin * 60 * (evName.includes("Maré Turbo") ? 0.5 : 1);
    const base = fishStats(acc, eco, { boostTier: sorteTier });
    const rare = fishStats(acc, eco, { minRare: true, boostTier: sorteTier });
    const castWorth = (bite, st) => bite * (st.value + st.pts * xpMult * xpv); // moedas-equivalentes por lançada
    const ctxLabel = evName.length ? evName.join(" + ") : "sem evento";
    const rows = [];
    // xpBreakEven: quanto 1 XP teria de valer (em moedas) para o item empatar
    const be = (o) => (o.xp > 0 ? Math.max(0, (o.cost - o.coins) / o.xp) : null);
    const row = (o) => rows.push({ ...o, net: Math.round(o.coins + o.xp * xpv - o.cost), xpBreakEven: be(o), coins: Math.round(o.coins), xp: Math.round(o.xp), cost: Math.round(o.cost) });

    // Turbo de Pesca: 5 min com espera de 20 s
    const turbo = find(cat.boosters, "turbo");
    if (turbo.cost) {
      const dur = num(turbo.duration_seconds) ?? 300, cd = num(turbo.cooldown_seconds) ?? 20;
      const extra = Math.max(0, dur / cd - dur / cdSec);
      row({ id: "turbo", name: "Turbo de Pesca", cost: turbo.cost, coins: extra * eco.bite * base.value, xp: extra * eco.bite * base.pts * xpMult, note: `+${extra.toFixed(0)} lançadas em 5 min` });
    }
    // Afiação de Anzol: +5% pontos e XP por 30 min (preço depende da vara)
    const af = find(cat.upkeep, "afiacao_anzol");
    const afPrice = num(af.prices_by_rod?.[acc.rodId]) ?? num(af.cost);
    if (afPrice) {
      const casts = (num(af.seconds) ?? 1800) / cdSec;
      row({ id: "afiacao", name: "Afiação de Anzol", cost: afPrice, coins: 0, xp: casts * eco.bite * base.pts * xpMult * (num(af.bonus) ?? 0.05), note: `+5% de XP em ~${casts.toFixed(0)} lançadas` });
    }
    // Iscas, por lançada
    const tb = find(cat.baits, "isca_turbinada");
    if (tb.cost) {
      const g = (1 - eco.bite) * (base.value + base.pts * xpMult * xpv);
      const owned = num(acc.baits.isca_turbinada) ?? 0;
      const o = { coins: (1 - eco.bite) * base.value, xp: (1 - eco.bite) * base.pts * xpMult, cost: tb.cost };
      rows.push({ id: "turbinada", name: "Isca Turbinada (1 lançada)", cost: tb.cost, coins: Math.round(o.coins), xp: Math.round(o.xp * 10) / 10, net: Math.round(g - tb.cost), xpBreakEven: be(o), note: owned ? `garante a fisgada; você tem ${owned} (de missões): use nas lançadas que valem mais` : "garante a fisgada", owned });
    }
    const mg = find(cat.baits, "isca_milagrosa");
    if (mg.cost) {
      const g = castWorth(1, rare) - castWorth(eco.bite, base);
      const o = { coins: rare.value - eco.bite * base.value, xp: (rare.pts - eco.bite * base.pts) * xpMult, cost: mg.cost };
      rows.push({ id: "milagrosa", name: "Isca Milagrosa (1 lançada)", cost: mg.cost, coins: Math.round(o.coins), xp: Math.round(o.xp), net: Math.round(g - mg.cost), xpBreakEven: be(o), note: `garante Raro+ (~${Math.round(((rare.w.legendary || 0) + (rare.w.mythic || 0) + (rare.w.secret || 0)) / rare.total * 100)}% Lendário ou melhor)`, owned: num(acc.baits.isca_milagrosa) ?? 0 });
    }
    // Turbo Torneio: só com torneio aberto; compara chance de vencer com e sem
    let tourRow = null;
    if (tour?.active) {
      const tt = find(cat.boosters, "turbo_torneio");
      const others = Math.max(1, (tour.participants ?? 2) - (tour.joined ? 1 : 0));
      const left = Math.max(0, tour.left ?? 180);
      const win = (myCasts) => tourWinChance(acc, eco, myCasts, others);
      const myNo = 1 + Math.floor(left / cdSec), myYes = Math.max(myNo, Math.floor(Math.min(left, num(tt.duration_seconds) ?? 180) / (num(tt.cooldown_seconds) ?? 10)));
      const pot = (n) => (tour.bonus ?? 70) + others * eco.bite * base.value + n * eco.bite * base.value; // prêmio + peixes de todos
      const evNo = win(myNo) * pot(myNo), evYes = win(myYes) * pot(myYes);
      tourRow = { id: "turbo_torneio", name: "Turbo Torneio", cost: tt.cost ?? 250, coins: Math.round(evYes - evNo), xp: Math.round((myYes - myNo) * eco.bite * base.pts * xpMult), note: `chance de vencer ${Math.round(win(myNo) * 100)}% → ${Math.round(win(myYes) * 100)}% contra ${others}` };
      tourRow.net = Math.round(tourRow.coins + tourRow.xp * xpv - tourRow.cost);
      tourRow.xpBreakEven = be(tourRow);
      rows.push(tourRow);
    }
    const nextL = (acc.level ?? 0) + 1;
    const nextRod = cat.rods[acc.rodIdx + 1];
    let rod = null;
    if (nextRod) {
      const e2 = economy({ ...acc, rod: nextRod, rodIdx: acc.rodIdx + 1, rodId: nextRod.id }, data?.bestiary);
      const dCoins = e2.coinsPerHour - eco.coinsPerHour, dXp = e2.xpPerHour - eco.xpPerHour;
      rod = { name: nextRod.name, price: price(nextRod), xpPerHour: [eco.xpPerHour, e2.xpPerHour], coinsPerHour: [eco.coinsPerHour, e2.coinsPerHour], paybackH: dCoins > 0 ? price(nextRod) / dCoins : null, xpGain150: dXp * XP_HORIZON_H };
    }
    return { context: ctxLabel, rod, xpValue: xpv, horizon: XP_HORIZON_H, xpPerHour: eco.xpPerHour, rows,
      level: { now: acc.level, xp: acc.xp, next: nextL, needNext: acc.xp != null ? Math.max(0, xpToLevel(nextL) - acc.xp) : null } };
  }

  // Torneio: vence o melhor peixe (raridade, depois peso). Cada outro jogador faz 1 lançada.
  function tourWinChance(acc, eco, myCasts, others) {
    const st = fishStats(acc, eco);
    const order = TIERS.filter((t) => st.w[t]);
    const p = order.map((t) => st.w[t] / st.total);
    const cdf = (k) => p.slice(0, k + 1).reduce((a, b) => a + b, 0);
    const bestBelow = (casts, k) => Math.pow(1 - eco.bite + eco.bite * (k < 0 ? 0 : cdf(k)), casts); // melhor < ou = tier k (ou nada)
    let win = 0;
    for (let k = 0; k < order.length; k++) {
      const pMine = bestBelow(myCasts, k) - bestBelow(myCasts, k - 1);
      const lower = bestBelow(1, k - 1), same = bestBelow(1, k) - lower;
      // empate no mesmo tier decide no peso: metade das vezes
      win += pMine * Math.pow(lower + same / 2, others);
    }
    return Math.min(1, win);
  }

  // ---------- incubação ----------
  function incubationPlan(acc, data, planList, avoid) {
    const A = root.TimoneiroAdvisors;
    if (!A) return null;
    const inc = A.incubationAdvice(acc, data?.bestiary, acc.owned);
    const tierL = (t) => TIER_LABEL[t] || t;
    const pctF = (x) => `${Math.round(x * 100)}%`;
    if (inc.incubators > 0 && inc.ascend.length) {
      const a = inc.ascend[0];
      planList.push({ tag: "plano", kind: "info", priority: 2, title: `Ascenda ${a.name}${a.asc ? ` (grau ${a.asc} → ${a.asc + 1})` : ""}`, text: `Você tem um par com 95%+ do peso máximo (${a.weights.join(" e ")} kg de ${a.max}). Na incubação, escolha "ascender".${a.fail ? ` Risco de falha ${pctF(a.fail)}: use Fertilizante.` : " Comum e incomum nunca falham."}`, why: "Ascendido entra no ranking de ascensão e vende +10% por grau. Os dois pais são consumidos.", link: "incubation" });
    } else if (inc.incubators > 0 && inc.grow.some((g) => g.fail === 0)) {
      const g = inc.grow.find((x) => x.fail === 0);
      planList.push({ tag: "plano", kind: "info", priority: 4, title: `Incubadora parada: cresça ${g.name}`, text: `Par ${g.weights.join(" e ")} kg${g.pctMax ? ` (${pctF(g.pctMax)} do máximo)` : ""}. O filhote nasce mais pesado; com 95%+ em dois exemplares dá para ascender.`, why: `${tierL(g.tier)} nunca falha. Prefira o peixe-mandarim: peso quase fixo, chega a 95% fácil e é o mais ascendido do jogo.`, link: "incubation" });
    }
    if (inc.incubators === 0) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não compre Incubadora para lucrar", text: "Custa 300 e os dois pais se perdem; o filhote não paga isso na venda.", why: "Use as incubadoras grátis (missões, Garrafa ao Mar, Peso Pesado, Kraken) para ascender peixe-mandarim ou comuns." });
    if (inc.grow.some((g) => g.fail > 0) && !inc.ascend.length) avoid.push({ tag: "evitar", kind: "skip", priority: 4, title: "Não incube Raro+ sem motivo", text: "Raro falha 10%, Lendário 20%, Mítico 35%: você perde os dois peixes.", why: "Só vale para ascender um par com 95%+, e com Fertilizante." });
    return inc;
  }

  // ---------- mercado ----------
  // Compara o que a loja paga agora com o líquido esperado no Mercado (mediana de vendas − 8% de taxa).
  function marketAdvice(acc, data, events, reserved = {}) {
    const left = { ...reserved };
    const ref = root.TimoneiroMarket || { tiers: {}, fish: {}, fee: 0.08, slots: 4, slotLockHours: 8 };
    const live = data?.marketStats;
    const tierRatio = (t) => live?.tiers?.[t]?.n >= 5 ? live.tiers[t].ratio : ref.tiers?.[t]?.ratio ?? 1.2;
    const fishMedian = (id) => live?.fish?.[id]?.n >= 3 ? live.fish[id].median : ref.fish?.[id]?.median ?? null;
    const pts = {};
    for (const f of data?.bestiary?.fish || []) pts[f.id] = f;
    const sellBonus = 1 + 0.3 * ((acc.level ?? 0) / 150);
    const turbo = events.some((e) => e.name === "Venda Turbinada");
    const fee = ref.fee ?? 0.08;
    const rows = [];
    let lowValue = 0;
    for (const f of acc.fish) {
      if (f.locked || f.listed) continue;
      const rk = `${f.id}|${f.asc || 0}`;
      if (left[rk] > 0) { left[rk]--; continue; }
      const curse = f.self && acc.hasCurse ? 1.25 : 1;
      const base = pts[f.id]?.points ? pts[f.id].points * 2 * (1 + 0.1 * (f.asc || 0)) : f.price / sellBonus || 0;
      const shopBase = (f.price || base * sellBonus) * (1 - (acc.saleTax || 0)); // o Mercado não paga o imposto do barco
      const shop = shopBase * curse * (turbo ? 1.25 : 1);
      const shopBest = shopBase * curse * 1.25; // na próxima Venda Turbinada
      const species = data?.marketBySpecies?.[`${f.id}|${f.asc || 0}`];
      const pr = root.TimoneiroAdvisors?.priceFor({ base }, species, tierRatio(f.tier));
      const hasSpecies = pr?.sales >= 3 || pr?.suggested != null;
      const ask = Math.round(hasSpecies ? pr.good : fishMedian(f.id) ?? tierRatio(f.tier) * base);
      const net = ask * (1 - fee);
      const gain = net - Math.max(shop, turbo ? shop : 0);
      const row = { id: f.id, name: f.name || f.id, tier: f.tier, asc: f.asc || 0, ask, fast: hasSpecies ? pr.fast : null, suggested: pr?.suggested ?? null, cheapest: pr?.cheapest ?? null, saleMed: pr?.saleMed ?? null, salesN: pr?.sales ?? 0, listings: pr?.listings ?? 0, net: Math.round(net), shop: Math.round(shop), shopBest: Math.round(shopBest), gain: Math.round(gain), source: pr?.sales >= 3 ? "espécie" : pr?.suggested != null ? "sugerido" : "raridade" };
      if (net >= shop * 1.2 && gain >= 15 && net > shopBest) rows.push(row);
      else if (["common", "uncommon", "rare"].includes(f.tier)) lowValue++;
    }
    // agrupa exemplares iguais (mesma espécie e grau) numa linha
    const grouped = [];
    for (const r of rows) {
      const g = grouped.find((x) => x.id === r.id && x.asc === r.asc);
      if (g) { g.count++; g.gain += r.gain; g.net += r.net; g.shop += r.shop; } else grouped.push({ ...r, count: 1 });
    }
    rows.length = 0; rows.push(...grouped);
    rows.sort((a, b) => b.gain - a.gain);
    return { list: rows.slice(0, ref.slots ?? 4), extra: Math.max(0, rows.length - (ref.slots ?? 4)), lowValue, slots: ref.slots ?? 4, lockHours: ref.slotLockHours ?? 8, source: live?.at ? "ao vivo" : `referência de ${ref.sampledAt}` };
  }

  // ---------- mudanças no manual ----------
  // Compara o manual ao vivo com o catálogo de reserva e lista o que mudou.
  function manualChanges(manual) {
    const c = CAT();
    if (!manual || !c.shop) return [];
    const out = [];
    const cmp = (label, a, b) => { if (a != null && b != null && Number(a) !== Number(b)) out.push(`${label}: ${b} → ${a}`); };
    for (const group of ["rods", "hooks", "backpacks", "baits", "boosters", "incubators", "fertilizers"]) {
      const liveList = manual.shop?.[group] || [];
      const old = Object.fromEntries((c.shop[group] || []).map((x) => [x.id, x]));
      for (const it of liveList) {
        if (!old[it.id]) out.push(`Item novo na loja: ${it.name || it.id}${it.cost != null ? ` (${it.cost})` : ""}`);
        else {
          cmp(`Preço de ${it.name}`, it.cost, old[it.id].cost);
          if (group === "rods") cmp(`Cooldown da ${it.name}`, it.cooldown_multiplier, old[it.id].cooldown_multiplier);
          if (group === "hooks") cmp(`Peixes por lançada do ${it.name}`, it.num_fish, old[it.id].num_fish);
        }
      }
    }
    const liveEvents = manual.events?.catalog || [];
    for (const e of liveEvents) {
      if (!(e.name in (c.events || {}))) out.push(`Evento novo: ${e.name}`);
      else cmp(`Valor do evento ${e.name}`, e.value, c.events[e.name]);
    }
    for (const name of Object.keys(c.events || {})) if (liveEvents.length && !liveEvents.some((e) => e.name === name)) out.push(`Evento removido: ${name}`);
    for (const sea of manual.expeditions?.seas || []) {
      const old = (c.seas || []).find((x) => x.sea === sea.sea);
      if (!old) out.push(`Mar novo: ${sea.entry_item_name || sea.sea}`);
      else { cmp(`Ticket de ${old.name}`, sea.entry_price, old.ticket); cmp(`Reembolso de ${old.name}`, sea.refund, old.refund); }
    }
    if (manual.fishing?.fish_count && manual.fishing.fish_count !== 101) out.push(`Espécies no jogo: 101 → ${manual.fishing.fish_count}`);
    return out;
  }

  // Remove identificadores antes de exportar.
  const SENSITIVE = /(token|secret|session|cookie|auth|email|password|senha|user_?id|account|^uid$|ip_?addr|pix|cpf|phone|avatar)/i;
  const LOOKS_LIKE_ID = /^([0-9a-f]{8}-[0-9a-f-]{27,}|\d{5,})$/i;
  function sanitize(v, depth = 0) {
    if (depth > 8) return "…";
    if (Array.isArray(v)) return v.slice(0, 400).map((x) => sanitize(x, depth + 1));
    if (v && typeof v === "object") {
      const o = {};
      for (const [k, x] of Object.entries(v)) {
        const scalar = typeof x !== "object" || x === null;
        const id = /^(id|_id|capture_id)$/i.test(k) && LOOKS_LIKE_ID.test(String(x));
        o[k] = scalar && (SENSITIVE.test(k) || id) ? "[removido]" : sanitize(x, depth + 1);
      }
      return o;
    }
    return v;
  }

  // Resumo de um perfil público para comparação.
  function profileSummary(p, cat = catalog({})) {
    if (!p || typeof p !== "object") return null;
    const inv = Array.isArray(p.inventory) ? p.inventory : [];
    const byTier = inv.reduce((m, i) => ((m[i.tier] = (m[i.tier] || 0) + 1), m), {});
    const rod = cat.rods.find((r) => r.id === p.rod_id);
    return {
      handle: p.handle, level: num(p.level), casts: num(p.casts), coins: num(p.twishcoins), points: num(p.points),
      rod: rod?.name || p.rod_id || "Vara de Bambu", hook: cat.hooks.find((h) => h.id === p.hook_id)?.name || "nenhum",
      backpack: cat.backpacks.find((b) => b.id === p.backpack_id)?.name || "nenhuma",
      baits: p.baits || {}, titles: (p.title_ids || []).length, invCount: inv.length, invValue: inv.reduce((s, i) => s + (num(i.price) ?? 0), 0), byTier,
      best: p.best_catch ? `${p.best_catch.name} (${TIER_LABEL[p.best_catch.tier] || p.best_catch.tier}, ${p.best_catch.weight} kg)` : "—",
      ranks: p.rank || {},
    };
  }

  return { plan, tideTurn, reconcile, normalize, economy, progression, sanitize, profileSummary, marketAdvice, manualChanges, PRIORITY, TIER_LABEL, fmt };
});
