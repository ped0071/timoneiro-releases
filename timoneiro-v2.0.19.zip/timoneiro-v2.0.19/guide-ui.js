// Timoneiro — interface do Guia (aba 🧭 e dica acima dos atalhos).
// Usa os dados que o PescaSkills e o guide-sync já leem do Twish. Ao clicar numa ação,
// o comando é preenchido no chat, como nos atalhos do Timoneiro: você confere e aperta Enter.
(() => {
  "use strict";
  if (window.__pescaSkillsGuideLoaded) return;
  window.__pescaSkillsGuideLoaded = true;

  const P = globalThis.TimoneiroPlanner;
  const Boat = globalThis.TimoneiroBoat;
  const K = {
    prefs: "timoneiro.guide.v2",
    syncStatus: "timoneiro.syncStatus.v1",
    syncReq: "timoneiro.syncRequest.v1",
    guideData: "timoneiro.guideData.v1",
    handle: "timoneiro.handle.v1",
    compareReq: "timoneiro.compareRequest.v1",
    compareRes: "timoneiro.compareResult.v1",
    benchReq: "timoneiro.boatBenchRequest.v1",
    benchRes: "timoneiro.boatBench.v1",
    seen: "timoneiro.guideSeen.v1",
    events: "timoneiro.events.v2",
    bg: "timoneiro.bgSync.v1",
    history: "timoneiro.history.v1",
    lastRate: "timoneiro.lastDiscountRate.v1",
    notif: "timoneiro.notifications.v1",
    discord: "timoneiro.discord.v1",
    fishing: "timoneiro.fishingStatus.v1",
    realtime: "timoneiro.realtime.v1",
    eventLog: "timoneiro.eventLog.v1",
    marketWatch: "timoneiro.marketWatch.v1",
    marketHits: "timoneiro.marketHits.v1",
  };
  const STALE_MS = 3 * 60 * 1000;
  const ICONS = { buy: "🛒", save: "💰", sell: "🏷", fish: "🎣", bait: "🪱", sea: "⚓", skip: "✋", warn: "⚠", info: "ℹ", claim: "🎁", bag: "🎒" };
  const PRIO_CLASS = { 1: "p1", 2: "p2", 3: "p3", 4: "p4" };

  const store = { syncStatus: null, guideData: null, handle: null, compare: null, bench: null, seen: [], events: null, bg: null, history: null, lastRate: null, notif: null, discord: null, fishing: null, realtime: null, eventLog: null, marketWatch: null, marketHits: null };

  // Selo do ≡: conta só ações "agora" que você ainda não viu. Abrir o Guia marca todas como vistas
  // (vale para todas as abas). Quando uma ação some (a Frota zarpou, o torneio acabou) a marca
  // é esquecida, então se ela voltar a acontecer o selo aparece de novo.
  const seenKey = (a) => `${a.kind || ""}|${a.command || ""}|${String(a.title || "").replace(/[\d:,.]+/g, "#")}`;
  const badgeItems = (res) => (res?.plan?.now || []).filter((a) => a.priority <= 2);
  function syncSeen(res, markAll) {
    const cur = badgeItems(res).map(seenKey);
    const keep = (store.seen || []).filter((k) => cur.includes(k));
    const next = markAll ? [...new Set([...keep, ...cur])] : keep;
    if (next.length !== (store.seen || []).length || next.some((k, i) => k !== store.seen[i])) {
      store.seen = next;
      try { chrome.storage.local.set({ [K.seen]: next }); } catch (_) {}
    }
    return cur.filter((k) => !next.includes(k)).length;
  }
  let tabList = null, tabCtx = null, lastTabRender = 0, hintSignature = "";
  let compareInput = "", compareBoatInput = "";

  function prefs() {
    const def = { hint: true, expeditions: true, readable: true, open: { now: true, plan: true, avoid: true, market: false, sea: false, incubation: false, items: false, news: false, compare: false }, seenNote: null };
    try { const p = globalThis.TimoneiroStore?.get(K.prefs, {}) || {}; return { ...def, ...p, open: { ...def.open, ...(p.open || {}) } }; }
    catch (_) { return def; }
  }
  function savePrefs(p) { globalThis.TimoneiroStore?.set(K.prefs, p); }
  function applyReadable() { document.documentElement.dataset.tmnReadable = String(prefs().readable); }

  const ctx = () => tabCtx || globalThis.TimoneiroGuideContext?.();
  const fmt = n => (n == null ? "?" : Math.round(n).toLocaleString("pt-BR"));
  const ago = t => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 60 ? `${s}s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.round(s / 3600)} h`; };
  const hours = h => h == null ? "?" : h < 1 ? `${Math.max(1, Math.round(h * 60))} min` : `${Math.round(h)} h`;
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const btn = (text, cls = "") => { const b = el("button", `tmn-theme-option tmn-guide-btn ${cls}`.trim(), text); b.type = "button"; return b; };

  // Junta tudo o que já foi lido e devolve o plano.
  function analysis(c) {
    const smart = c?.getSmartData?.();
    const gd = store.guideData;
    const boat = Boat?.get();
    const smartOk = smart?.data && (!smart.boat || smart.boat === boat);
    const extra = gd?.boat === boat ? gd.data || {} : {};
    if (!smartOk && !extra.profile) return null;
    const ev = c.getEventState?.();
    let events = {};
    const E = globalThis.TimoneiroEvents;
    const list = store.events;
    if (E && list?.boat === boat && Array.isArray(list.list) && Date.now() - (list.at || 0) < 120000) events = E.toPlannerEvents(list.list);
    else if (ev?.active && typeof ev.name === "string") {
      const secs = Number.isFinite(ev.endsAt) ? Math.max(0, (ev.endsAt - Date.now()) / 1000) : null;
      const raw = { name: ev.name, seconds_remaining: secs, message: ev.description || "", progress_count: ev.progressCount, progress_target: ev.progressTarget };
      if (ev.apiKind) raw.kind = ev.apiKind;
      if (ev.kind === "grand") events.grande_evento = raw; else events.event = raw;
    }
    const data = { ...(smartOk ? smart.data : {}), ...extra, events, boat };
    const plan = P.plan(data, { hideExpeditions: !prefs().expeditions, lastDiscountRate: store.lastRate?.rate });
    return { plan, updatedAt: Math.max(smartOk ? smart.updatedAt || 0 : 0, gd?.updatedAt || 0), data };
  }

  // Saúde da leitura: de onde vieram os dados e há quanto tempo (aba do Twish ou segundo plano).
  function syncHealth() {
    return globalThis.TimoneiroHealth.compute({
      bg: store.bg,
      fishingAt: store.fishing?.updatedAt || 0,
      smartAt: tabCtx?.getSmartData?.()?.updatedAt || 0,
      realtime: store.realtime,
      boat: Boat?.get() || null,
    });
  }

  function statusMessage(c) {
    const boat = Boat?.get() || "?";
    const st = store.syncStatus;
    if (st?.state === "login") return `Entre com a Twitch no twish.com.br (barco ${boat}) para o Guia ler sua conta. Até lá ele usa seu perfil público, se você informar o nick em Ajustes.`;
    if (st?.state === "boat") return `O Twish não reconheceu o barco "${boat}". Confira o nome em Ajustes.`;
    if (st?.state === "rate") return "O Twish pediu para ir mais devagar. Nova leitura em 2 minutos.";
    if (!c?.getSmartData?.()?.data) return store.bg?.me === "login" ? `Entre no twish.com.br (barco ${boat}) neste navegador para o Timoneiro ler sua conta.` : `Lendo sua conta no barco ${boat}... Se demorar, entre no twish.com.br neste navegador.`;
    return null;
  }

  function fillAndClose(c, command) { if (!command) return; c.fill(command); c.closePanel(); }

  function actionCard(c, a) {
    const card = el("button", `tmn-card tmn-guide-card tmn-guide-${PRIO_CLASS[a.priority] || "p3"}`);
    card.type = "button";
    card.dataset.hasCommand = String(!!a.command);
    card.dataset.tag = a.tag || "";
    card.append(el("span", "tmn-card-icon", ICONS[a.kind] || "•"));
    const main = el("span", "tmn-card-main");
    const head = el("span", "tmn-guide-card-head");
    head.append(el("span", `tmn-guide-prio tmn-guide-${PRIO_CLASS[a.priority] || "p3"}`, a.tag === "evitar" ? "Evitar" : P.PRIORITY[a.priority] || "Média"), el("span", "tmn-card-name", a.title));
    main.append(head, el("span", "tmn-card-desc", a.text));
    if (a.why) main.append(el("span", "tmn-guide-why", `Por quê: ${a.why}`));
    card.append(main);
    if (a.command) card.append(el("span", "tmn-card-command", a.command));
    else if (a.link) card.append(el("span", "tmn-card-command", "ABRIR ↗"));
    card.dataset.hasCommand = String(!!(a.command || a.link));
    card.title = a.command ? `Preenche ${a.command} no chat. Confira e aperte Enter.` : a.link ? "Abre a página no site do Twish." : "";
    if (a.command) card.onclick = () => fillAndClose(c, a.command);
    else if (a.link) card.onclick = () => c.openUrl(a.link);
    else card.disabled = true;
    return card;
  }

  // ---------- evento agora: o que é, quanto falta e o que fazer (topo do Guia e faixa da barra) ----------
  function activeEvent(c) {
    const st = c?.getEventState?.();
    const ui = st ? globalThis.TimoneiroStatus?.eventUi(st, Date.now()) : null;
    return ui?.active ? { ...ui, apiKind: st.apiKind || null } : null;
  }
  // Dicas do plano ligadas a este evento (o plano usa o nome da regra; o Twish às vezes muda o nome exibido).
  function eventTips(plan, ev) {
    const rule = globalThis.TimoneiroEvents?.ruleName?.({ name: ev.name, kind: ev.apiKind });
    const same = (n) => !!n && (n === ev.name || n === rule || ev.name.includes(n) || n.includes(ev.name));
    return (plan?.now || []).filter((x) => same(x.event));
  }
  function eventBlock(c, ev, tips, { full = false } = {}) {
    const box = el("div", "tmn-event-block");
    const head = el("div", "tmn-event-head");
    head.append(el("span", "tmn-event-emoji", ev.kind === "grand" ? "🌟" : "🎪"), el("b", "tmn-event-name", ev.name));
    if (ev.kind === "grand") head.append(el("span", "tmn-event-tag", "Grande evento"));
    const time = el("span", "tmn-event-time", `acaba em ${ev.remaining}`);
    time.dataset.tmnEvTime = "";
    head.append(time);
    box.append(head);
    if (ev.description) box.append(el("p", "tmn-event-desc", ev.description));
    if (Number.isFinite(ev.progressCount) && ev.progressTarget > 0) {
      const prog = el("div", "tmn-event-progress");
      const bar = el("div", "tmn-guide-bar"); const fill = el("span");
      fill.style.width = `${Math.min(100, Math.round((ev.progressCount / ev.progressTarget) * 100))}%`;
      bar.append(fill);
      prog.append(el("span", null, `${ev.progressCount} de ${ev.progressTarget} embarcaram`), bar);
      box.append(prog);
    }
    if (tips.length) {
      box.append(el("div", "tmn-event-sub", "O que fazer"));
      if (full) tips.forEach((t) => box.append(actionCard(c, t)));
      else tips.slice(0, 3).forEach((t) => {
        const tip = el("div", "tmn-event-tip");
        tip.append(el("b", null, t.title), el("span", null, t.text));
        if (t.why) tip.append(el("span", "tmn-event-why", `Por quê: ${t.why}`));
        box.append(tip);
      });
    } else if (!ev.description) box.append(el("p", "tmn-event-desc", "O Twish não mandou a descrição deste evento."));
    return box;
  }
  // Para a faixa da barra: preenche o balão do evento. false = nenhum evento agora.
  function fillEvent(node) {
    const c = ctx();
    const ev = activeEvent(c);
    node.replaceChildren();
    if (!ev) return false;
    node.append(eventBlock(c, ev, eventTips(analysis(c)?.plan, ev)));
    return true;
  }

  function section(id, title, count, build, forceOpen = false) {
    const p = prefs();
    const d = el("details", "tmn-guide-section");
    d.open = forceOpen || !!p.open[id];
    const sum = el("summary", null, count != null ? `${title} (${count})` : title);
    d.append(sum);
    d.addEventListener("toggle", () => { const q = prefs(); q.open[id] = d.open; savePrefs(q); });
    const body = el("div", "tmn-guide-section-body");
    build(body);
    d.append(body);
    return d;
  }

  function renderTab(list, c) {
    tabList = list; tabCtx = c; lastTabRender = Date.now();
    globalThis.TimoneiroWake?.();
    list.replaceChildren();
    const res = analysis(c);
    const msg = statusMessage(c);
    if (res) { syncSeen(res, true); updateBadge(res); }

    const top = el("section", "tmn-guide");
    const head = el("div", "tmn-guide-head");
    head.append(el("strong", null, `🧭 Guia · ${Boat?.get() || "?"}`));
    const tools = el("span", "tmn-guide-tools");
    const sync = btn("Sincronizar");
    sync.onclick = () => { chrome.storage.local.set({ [K.syncReq]: Date.now() }); sync.textContent = "Pedido enviado"; };
    const open = btn("Abrir Twish ↗");
    open.onclick = () => c.openUrl("inventory");
    tools.append(sync, open);
    head.append(tools);
    top.append(head);
    const health = syncHealth();
    const hl = el("div", `tmn-guide-health tmn-guide-health-${health.level}`, `${health.level === "ok" ? "🟢" : health.level === "warn" ? "🟡" : "🔴"} ${health.text}`);
    if (health.hint) hl.title = health.hint;
    top.append(hl);
    if (health.hint && health.level !== "ok") top.append(el("p", "tmn-guide-warn", health.hint));

    // Versão nova do Timoneiro: primeiro de tudo, até atualizar.
    const up = globalThis.TimoneiroUpdateNotice?.pending();
    if (up) {
      const card = el("section", "tmn-update-card");
      card.setAttribute("role", "alert");
      const head = el("div", "tmn-update-card-head");
      head.append(el("span", "tmn-guide-prio tmn-guide-p1", "Urgente"), el("b", null, `Atualize o Timoneiro: versão ${up.version}`));
      card.append(head, el("p", "tmn-update-card-sub", `Você está na ${up.installed}.${up.important ? " Esta atualização é importante." : ""} Leva menos de 1 minuto e seus ajustes continuam.`));
      if (up.notes) card.append(el("div", "tmn-update-card-notes", up.notes));
      const go = btn("Ver como atualizar");
      go.classList.add("tmn-update-card-go");
      go.onclick = () => globalThis.TimoneiroUpdateNotice.open();
      card.append(go);
      top.querySelector(".tmn-guide-head").after(card); // logo abaixo do título, antes de qualquer aviso
    }

    // Evento agora, no topo: o que é, quanto falta e as ações dele (que saem da lista "Agora").
    // Aparece mesmo antes de a conta ser lida: o evento vem do barco, não da conta.
    const evNow = activeEvent(c);
    const evTips = evNow && res ? eventTips(res.plan, evNow) : [];
    if (evNow) {
      const card = el("section", "tmn-event-card");
      card.setAttribute("aria-label", `Evento agora: ${evNow.name}`);
      card.append(el("div", "tmn-event-kicker", "Evento agora"), eventBlock(c, evNow, evTips, { full: true }));
      top.append(card);
    }

    if (!res) {
      top.append(el("p", "tmn-guide-warn", msg || "Aguardando dados do Twish."));
      list.append(top);
      return;
    }
    const { plan } = res;
    const a = plan.account;

    // Fase e meta
    const phase = el("div", "tmn-guide-phase");
    phase.append(el("b", null, `Fase ${plan.phase.n} de 8 · ${plan.phase.name}`), el("span", null, plan.phase.text));
    top.append(phase);
    if (plan.goal) {
      const g = plan.goal;
      const goal = el("div", "tmn-guide-goal");
      const target = g.discountNow ? g.discounted : g.price;
      const pctDone = target ? Math.min(100, Math.round(((a.coins ?? 0) / target) * 100)) : 0;
      goal.append(el("div", "tmn-guide-goal-line", `Meta: ${g.name} · ${fmt(a.coins)} / ${fmt(g.discountNow ? g.discounted : g.price)} moedas${g.discountNow ? ` (com desconto; preço normal ${fmt(g.price)})` : ""}`));
      const bar = el("div", "tmn-guide-bar"); const fill = el("span"); fill.style.width = `${pctDone}%`; bar.append(fill);
      goal.append(bar, el("div", "tmn-guide-goal-sub", g.missing ? (g.discountNow ? `Desconto na Loja ativo · faltam ${fmt(g.missing)} · ~${hours(g.hours)} de pesca ativa` : `Faltam ${fmt(g.missing)} · ~${hours(g.hours)} de pesca ativa · no Desconto na Loja: ${fmt(g.discounted)}`) : "Você já pode comprar."));
      const r7 = globalThis.TimoneiroHistory?.rates(store.history?.boat === Boat?.get() ? store.history : null, Date.now(), 7 * 24 * 3600e3);
      const etaH = g.missing ? globalThis.TimoneiroHistory?.eta(r7, g.missing) : null;
      if (etaH != null && etaH > 0) goal.append(el("div", "tmn-guide-goal-sub", `No seu ritmo real (últimos ${r7.hours >= 48 ? `${Math.round(r7.hours / 24)} dias` : `${Math.round(r7.hours)} h`}): ~${etaH < 48 ? `${Math.round(etaH)} h` : `${Math.round(etaH / 24)} dias`} de relógio, ganhando ~${fmt(r7.coinsPerHour * 24)} moedas por dia.`));
      top.append(goal);
    }

    const stats = el("div", "tmn-guide-stats");
    const stat = (label, value, hint) => { const d = el("div"); if (hint) d.title = hint; d.append(el("span", null, label), el("b", null, value)); stats.append(d); };
    stat("Moedas", fmt(a.coins));
    stat("Nível", a.level == null ? "?" : `${a.level}`, a.levelHours != null ? `Próximo nível em ~${hours(a.levelHours)}` : "");
    stat("Próx. nível", a.nextLevelXp != null && a.xp != null ? `${fmt(a.nextLevelXp - a.xp)} XP` : "—");
    stat("Vara", (a.rod?.name || "Vara de Bambu").replace(/^Vara (de |do )?/, ""));
    stat("Anzol", a.hook ? a.hook.name.replace("Anzol ", "") : "Simples");
    stat("Mochila", `${a.fishCount}/${a.capacity}`);
    stat("Estoque", `~${fmt(a.stockValue)}`);
    stat("Moedas/h", `~${fmt(plan.economy.coinsPerHour)}`, `${plan.economy.fishPerHour.toFixed(1)} peixes/h × ~${plan.economy.fishValue.toFixed(1)} por peixe (estimativa, pescando sem parar)`);
    const real = globalThis.TimoneiroHistory?.rates(store.history?.boat === Boat?.get() ? store.history : null, Date.now(), 24 * 3600e3);
    if (real) {
      stat("Ritmo real 24 h", `${fmt(real.coinsPerHour * 24)}/dia`, `Medido na sua conta: ~${fmt(real.coinsPerHour)} moedas/h e ~${fmt(real.xpPerHour)} XP/h de relógio, ${real.castsPerHour.toFixed(1)} lançadas/h${real.coinsPerCast != null ? `, ~${real.coinsPerCast.toFixed(1)} moedas por lançada` : ""}.`);
      stat("XP real 24 h", `${fmt(real.xpPerHour * 24)}/dia`, real.xpPerCast != null ? `~${real.xpPerCast.toFixed(1)} XP por lançada` : "");
    }
    top.append(stats);

    if (Date.now() - res.updatedAt > STALE_MS && !health.hint) top.append(el("p", "tmn-guide-warn", "Dados da conta com mais de 3 minutos. Confira se você está logado no twish.com.br neste navegador."));
    else if (msg) top.append(el("p", "tmn-guide-warn", msg));
    list.append(top);

    const nowItems = plan.now.filter((x) => !evTips.includes(x));
    list.append(section("now", "⚡ Agora", nowItems.length, body => {
      if (!nowItems.length) body.append(el("p", "tmn-guide-empty", evTips.length ? "As ações do evento estão no cartão acima." : "Nenhum evento pedindo ação. Siga o plano abaixo."));
      nowItems.forEach(x => body.append(actionCard(c, x)));
    }));
    list.append(section("plan", "🗺 Plano", plan.plan.length, body => plan.plan.forEach(x => body.append(actionCard(c, x)))));
    list.append(section("avoid", "✋ Não faça agora", plan.avoid.length, body => {
      if (!plan.avoid.length) body.append(el("p", "tmn-guide-empty", "Nada a evitar no momento."));
      plan.avoid.forEach(x => body.append(actionCard(c, x)));
    }));
    list.append(section("market", `🏛 Mercado: ${plan.market.list.length ? `anunciar ${plan.market.list.length}` : "venda na loja"}`, null, body => renderMarket(body, plan, c)));
    list.append(section("sea", `⚓ Expedições: ${plan.expedition.label}`, null, body => renderSea(body, plan, c), !!(plan.expedition.open?.fleet && !plan.expedition.open.fleet.joined)));
    if (plan.items?.rows?.length) {
      const good = plan.items.rows.filter((r) => r.net > 0);
      list.append(section("items", `🧪 Itens${good.length ? `: ${good.map((r) => r.name).join(", ")} compensa agora` : ": nenhum compensa agora"}`, null, body => renderItems(body, plan)));
    }
    if (plan.incubation) list.append(section("incubation", `🥚 Incubação${plan.incubation.ascend.length && plan.incubation.incubators ? ": par pronto para ascender" : plan.incubation.incubators ? `: ${plan.incubation.incubators} incubadora(s)` : ""}`, null, body => renderIncubation(body, plan, c)));
    const news = newsInfo(plan);
    list.append(section("news", `📜 Novidades${news.unseen ? ` (${news.unseen} nova${news.unseen > 1 ? "s" : ""})` : ""}${plan.changes.length ? ` · ${plan.changes.length} mudança(s) no manual` : ""}`, null, body => renderNews(body, plan, news), news.unseen > 0 && news.relevant > 0));
    const fc = globalThis.TimoneiroForecast?.forecast(store.eventLog?.boat === Boat?.get() ? store.eventLog : null);
    const best = fc?.enough ? fc.rows.filter((r) => !r.grand && !r.shop).sort((a, b) => b.pNext - a.pNext)[0] : null;
    list.append(section("forecast", `📅 Previsão de eventos${best ? `: ${best.rule} ${Math.round(best.pNext * 100)}% às ${String(fc.nextHour).padStart(2, "0")}h` : ""}`, null, body => renderForecast(body, fc)));
    list.append(section("compare", "📊 Comparação", null, body => renderCompare(body, plan, c)));
    list.append(section("diag", "🩺 Diagnóstico", null, body => renderDiagnostics(body)));

    const foot = el("div", "tmn-guide-foot");
    foot.append(el("span", null, `Atualizado há ${ago(res.updatedAt)}${a.handle ? ` · ${a.handle}` : ""}`));
    const exp = btn("Exportar meus dados (sem ids)");
    exp.onclick = () => { exp.textContent = download(`timoneiro-${Boat?.get()}.json`, { exportedAt: new Date().toISOString(), boat: Boat?.get(), data: P.sanitize(res.data) }) ? "Exportado" : "Sem dados"; };
    foot.append(exp);
    list.append(foot);
  }

  function download(name, obj) {
    try {
      const url = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" }));
      const link = document.createElement("a"); link.href = url; link.download = name;
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      return true;
    } catch (_) { return false; }
  }

  function renderMarket(body, plan, c) {
    const m = plan.market;
    if (m.list.length) {
      body.append(el("p", "tmn-guide-text", `Vale anunciar (até ${m.slots} anúncios ao mesmo tempo, cada um preso por ${m.lockHours} h):`));
      const table = el("table", "tmn-guide-table");
      const tr = el("tr"); ["Peixe", "Pedir", "Rápido", "Vendas", "+ barato", "Loja", "Ganho"].forEach(h => tr.append(el("th", null, h))); table.append(tr);
      for (const r of m.list) {
        const row = el("tr");
        [`${r.name}${r.asc ? ` (grau ${r.asc})` : ""}${r.count > 1 ? ` ×${r.count}` : ""}`, fmt(r.ask), r.fast ? fmt(r.fast) : "—", r.salesN ? `${r.salesN} · med ${fmt(r.saleMed)}${r.suggested != null ? ` · site ${fmt(r.suggested)}` : ""}` : r.suggested != null ? `site ${fmt(r.suggested)}` : "ref.", r.cheapest != null ? fmt(r.cheapest) : "—", fmt(r.shop / (r.count || 1)), `+${fmt(r.gain)}`].forEach(v => row.append(el("td", null, v)));
        row.title = "Abre o Mercado no site"; row.onclick = () => c.openUrl("market");
        table.append(row);
      }
      body.append(table);
      if (m.extra) body.append(el("p", "tmn-guide-note", `Mais ${m.extra} peixe(s) valeriam o Mercado, mas os espaços são ${m.slots}.`));
      const open = btn("Abrir o Mercado ↗"); open.onclick = () => c.openUrl("market"); body.append(open);
    } else body.append(el("p", "tmn-guide-text", "Nenhum peixe seu rende mais no Mercado do que na loja agora. Venda na loja, de preferência na Venda Turbinada."));
    body.append(el("p", "tmn-guide-note", `Regra: comum, incomum e raro rendem pouco a mais no Mercado e prendem um espaço por ${m.lockHours} h; lendário+ e o peixe-mandarim (usado para ascender, ~6× a loja) valem anunciar. Com o Portador da Maldição a loja paga 1,25× no que você pescou. Anúncios acima de ~2× o valor base ficam parados por semanas. Preços: ${m.source}.`));
    renderMarketWatch(body, c);
  }

  // Alertas de preço: avisa quando alguém anunciar uma espécie da sua lista até o preço que você quer.
  function renderMarketWatch(body, c) {
    const boat = Boat?.get();
    const watch = Array.isArray(store.marketWatch) ? store.marketWatch : [];
    const hits = store.marketHits?.boat === boat ? store.marketHits.hits || [] : [];
    const wrap = el("div", "tmn-guide-note-card");
    wrap.append(el("b", null, "🔔 Alertas de preço"));
    wrap.append(el("span", "tmn-guide-note", "O Timoneiro olha o Mercado a cada 10 min e avisa quando aparece um anúncio até o preço que você definir (até 5 espécies)."));
    const save = (next) => chrome.storage.local.set({ [K.marketWatch]: next.slice(0, 5) });
    for (const w of watch) {
      const row = el("div", "tmn-guide-row");
      const found = hits.filter((h) => h.id === w.id);
      row.append(el("span", null, `${w.name} até ${fmt(w.max)}${found.length ? ` · ${found.length} anúncio(s), o mais barato por ${fmt(found[0].price)}` : ""}`));
      const rm = btn("Remover"); rm.onclick = () => save(watch.filter((x) => x.id !== w.id));
      row.append(rm);
      wrap.append(row);
    }
    if (watch.length < 5) {
      const fish = (store.guideData?.boat === boat ? store.guideData?.data?.bestiary?.fish : null) || [];
      const row = el("div", "tmn-guide-row");
      const sel = el("select", "tmn-theme-option tmn-theme-select tmn-guide-input");
      sel.setAttribute("aria-label", "Espécie");
      const opt0 = el("option", null, fish.length ? "Escolha a espécie" : "Abra o Twish para carregar o bestiário"); opt0.value = ""; sel.append(opt0);
      [...fish].sort((a, b) => String(a.name).localeCompare(String(b.name), "pt-BR")).forEach((f) => { const o = el("option", null, f.name); o.value = f.id; sel.append(o); });
      const max = el("input", "tmn-theme-option tmn-guide-input tmn-guide-input-sm"); max.type = "number"; max.min = "1"; max.placeholder = "Preço máx."; max.setAttribute("aria-label", "Preço máximo");
      const add = btn("Adicionar");
      add.onclick = () => {
        const f = fish.find((x) => x.id === sel.value); const v = Math.floor(Number(max.value));
        if (!f || !(v > 0)) { add.textContent = "Escolha espécie e preço"; return; }
        save([...watch.filter((x) => x.id !== f.id), { id: f.id, name: f.name, max: v }]);
      };
      row.append(sel, max, add);
      wrap.append(row);
    }
    if (hits.length) {
      const open = btn("Abrir o Mercado ↗"); open.onclick = () => c.openUrl("market"); wrap.append(open);
    }
    body.append(wrap);
  }

  function renderForecast(body, fc) {
    if (!fc?.observed) { body.append(el("p", "tmn-guide-empty", "Ainda sem histórico. O Timoneiro anota cada evento que vê; a previsão aparece depois de algumas horas.")); return; }
    if (!fc.enough) body.append(el("p", "tmn-guide-note", `Só ${fc.observed} hora(s) observadas até agora: as porcentagens ficam confiáveis a partir de ~12 h (melhor com alguns dias).`));
    const table = el("table", "tmn-guide-table");
    const tr = el("tr"); ["Evento", "Por dia", `Às ${String(fc.nextHour).padStart(2, "0")}h`, "Horários mais comuns", "Último"].forEach((h) => tr.append(el("th", null, h))); table.append(tr);
    for (const r of fc.rows) {
      const row = el("tr");
      [r.rule + (r.grand ? " (grande)" : r.shop ? " (oferta)" : ""), fc.enough ? r.perDay.toFixed(1) : "—", fc.enough ? `${Math.round(r.pNext * 100)}%` : "—", r.top.map((t) => `${String(t.h).padStart(2, "0")}h`).join(", "), `há ${ago(r.last)}`].forEach((v) => row.append(el("td", null, v)));
      table.append(row);
    }
    body.append(table);
    body.append(el("p", "tmn-guide-note", `Base: ${fc.observed} hora(s) em que o Timoneiro estava lendo, nos últimos 14 dias. Os eventos comuns são sorteados a cada hora cheia, então é probabilidade, não horário marcado: use para decidir se vale esperar (ex.: o Desconto na Loja para a sua meta).`));
  }

  // Diagnóstico: tudo o que ajuda a descobrir por que algo não chegou. Sem login, ids ou tokens.
  async function diagnostics() {
    let worker = null;
    try { worker = await chrome.runtime.sendMessage({ type: "timoneiro-diagnostics" }); } catch (_) {}
    const got = await chrome.storage.local.get(["timoneiro.sounds.v1", "timoneiro.soundLog.v1"]);
    const sound = got["timoneiro.sounds.v1"] || {};
    const hhmm = (t) => new Date(t).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const sounds = (got["timoneiro.soundLog.v1"] || []).slice(0, 8).map((e) => `${hhmm(e.at)} ${e.kind === "fishing" ? "pesca" : "evento"} (${e.who}): ${e.result}${e.why ? ` — ${e.why}` : ""}`);
    const age = (t) => (t ? `há ${ago(t)}` : "nunca");
    const n = store.notif || {};
    return {
      "Versão": worker?.version || "?",
      "Navegador": /Edg\//.test(navigator.userAgent) ? "Edge" : /Firefox\//.test(navigator.userAgent) ? "Firefox" : /Chrome\//.test(navigator.userAgent) ? "Chrome" : "?",
      "Notificações do sistema": worker ? (worker.notifications === "granted" ? "permitidas" : "BLOQUEADAS no navegador ou no Windows") : "service worker não respondeu",
      "Aviso de pesca": n.fishing === false ? "desligado em Ajustes" : "ligado",
      "Aviso de eventos": n.event === false ? "desligado em Ajustes" : `ligado (${n.eventLevel || "todos"})`,
      "Som em outra aba": sound.fishingAlert?.enabled === false ? "som de pesca desligado" : worker?.offscreen || worker?.audio ? "sim" : "não suportado",
      "Tempo real": store.realtime ? `${store.realtime.state} ${age(store.realtime.at)}` : "sem aba do Twish",
      "Leitura em segundo plano": store.bg ? `conta: ${store.bg.me}, eventos: ${store.bg.events}, ${age(store.bg.at)}` : "ainda não rodou",
      "Cooldown": store.fishing ? `${store.fishing.status} via ${store.fishing.via || "?"}/${store.fishing.source || "?"} ${age(store.fishing.updatedAt)}` : "sem dado",
      "Alarmes": (worker?.alarms || []).map((a) => `${a.name}${a.period ? ` (${a.period * 60} s)` : ""}`).join(", ") || "nenhum",
      "Barco": Boat?.get(),
      "Últimos sons": sounds.length ? sounds.join("\n") : "nenhum ainda",
    };
  }
  function renderDiagnostics(body) {
    const table = el("table", "tmn-guide-table");
    body.append(table);
    const msg = el("p", "tmn-guide-note", "");
    const test = btn("Testar aviso (notificação + som)");
    test.onclick = async () => {
      msg.textContent = "Mude para outra aba agora: o aviso sai em 3 s.";
      setTimeout(async () => {
        try { const r = await chrome.runtime.sendMessage({ type: "timoneiro-test-alert" }); msg.textContent = r?.played ? "Enviado. Se não apareceu nada, veja 'Notificações do sistema' acima e as notificações do Windows." : "Notificação enviada, mas o som não tocou."; }
        catch (_) { msg.textContent = "O service worker não respondeu: recarregue o Timoneiro em chrome://extensions."; }
      }, 3000);
    };
    const copy = btn("Copiar diagnóstico");
    const tools = el("div", "tmn-guide-row"); tools.append(test, copy);
    body.append(tools, msg);
    diagnostics().then((d) => {
      for (const [k, v] of Object.entries(d)) { const row = el("tr"); row.append(el("td", null, k), el("td", null, String(v))); table.append(row); }
      copy.onclick = () => { navigator.clipboard?.writeText(JSON.stringify(d, null, 2)).then(() => { copy.textContent = "Copiado"; }, () => { copy.textContent = "Não foi possível copiar"; }); };
    });
  }

  function renderSea(body, plan, c) {
    const e = plan.expedition;
    body.append(el("p", "tmn-guide-text", e.why));
    const o = e.open || {};
    if (o.fleet) body.append(el("p", "tmn-guide-warn", o.fleet.joined ? `Você está na Frota (${o.fleet.crew}/${o.fleet.max}).` : `Frota aberta agora (${o.fleet.crew}/${o.fleet.max}): digite $embarcar.`));
    for (const r of o.rooms || []) body.append(el("p", "tmn-guide-text", `Sala aberta no barco: ${r.sea} (${r.crew}/${r.max})${r.joined ? " — você está nela" : ""}.`));
    const fi = o.fleetInfo;
    if (fi && !o.fleet) {
      const bits = [];
      if (fi.goal) bits.push(`meta da Frota: R$ ${((fi.progress || 0) / 100).toFixed(2).replace(".", ",")} de R$ ${(fi.goal / 100).toFixed(2).replace(".", ",")}`);
      if (fi.minCasts != null) bits.push(fi.castsHere != null && fi.castsHere < fi.minCasts ? `você precisa de ${fi.minCasts} pescas no barco para embarcar (tem ${fi.castsHere})` : `você já pode embarcar (${fi.minCasts}+ pescas no barco)`);
      if (bits.length) body.append(el("p", "tmn-guide-text", `Nenhuma Frota aberta agora — ${bits.join("; ")}. O Timoneiro avisa quando abrir.`));
    }
    const rows = e.rows || [];
    if (rows.length) {
      const table = el("table", "tmn-guide-table");
      const tr = el("tr"); ["Mar", "Lanç.", "Peixes", "Peixes R$", "Encom.", "Reemb.", "Risco", "Líquido"].forEach(h => tr.append(el("th", null, h))); table.append(tr);
      for (const r of rows) {
        const row = el("tr");
        if (r.locked) [r.name, "—", "—", "—", "—", "—", "—", `precisa ${(r.minRod || "").replace("vara_", "vara ")}`].forEach(v => row.append(el("td", null, v)));
        else [`${r.name}${r.tideLabel ? ` (${r.tideLabel})` : ""}${r.ticketOwned ? " · ticket na mochila" : ""}`, r.casts, r.fish.toFixed(1), fmt(r.fishValue), fmt(r.orders), fmt(r.refund), `${fmt(r.risk)}${r.insure ? " (seguro)" : ""}`, `${r.net >= 0 ? "+" : ""}${fmt(r.net)}`].forEach(v => row.append(el("td", null, String(v))));
        table.append(row);
      }
      body.append(table);
      body.append(el("p", "tmn-guide-note", "Estimativa em moedas por viagem solo (ticket incluído, exceto quando você já tem o ticket), com a sua vara, nível e a maré de agora (ela vira a cada 6 horas: 0h, 6h, 12h e 18h). Encomendas contam só na primeira viagem do dia. Não entram: Escamas, Fragmentos, títulos de viagem, missão Marujo, pontos do Tridente e prêmios de ranking."));
    }
    const obs = Object.entries(e.observed || {}).filter(([, s]) => s.people > 0);
    if (obs.length) {
      const SEA = { baia: "Baía", sereias: "Sereias", abismo: "Abismo", fenda: "Fenda" };
      const ticket = (sea) => (e.rows || []).find((r) => r.sea === sea)?.ticket ?? (e.rows || []).find((r) => r.sea === sea)?.paidTicket ?? null;
      const ul = el("ul", "tmn-guide-list");
      obs.sort((a, b) => b[1].people - a[1].people).forEach(([k, s]) => {
        const [sea, kind] = k.split("|");
        const v = s.value / s.people, cat = s.catches / s.people, ref = s.refunded / s.people;
        const t = kind === "fleet" ? 0 : ticket(sea);
        const net = t != null ? v + ref - t : null;
        ul.append(el("li", null, `${SEA[sea] || sea} ${kind === "fleet" ? "(Frota, grátis)" : "(paga)"}: ${cat.toFixed(1)} peixes e ${fmt(v)} moedas por pessoa${ref ? ` + ${fmt(ref)} de reembolso` : ""}${net != null && kind !== "fleet" ? ` → ${net >= 0 ? "+" : ""}${fmt(net)} depois do ticket` : ""} · ${s.trips} viagem(ns), ${s.people} pessoa(s)`));
      });
      body.append(el("p", "tmn-guide-text", "O que outros jogadores tiraram de verdade (viagens terminadas lidas no cais):"));
      body.append(ul);
    }
    const tides = Object.entries(e.tides || {}).filter(([k]) => k !== "_any");
    body.append(el("p", "tmn-guide-text", tides.length ? `Maré agora (vira ${P.tideTurn().label}): ${tides.map(([s, t]) => `${s} ${t}`).join(" · ")}` : "Maré: aparece quando o Guia lê o cais (logado no site). Ela vira a cada 6 horas."));
    const go = btn("Abrir o cais ↗"); go.onclick = () => c.openUrl("expedicoes"); body.append(go);
  }

  // Itens: retorno em moedas e em XP no momento atual (sem evento, XP em Dobro, Sorte Rara, torneio...).
  function renderItems(body, plan) {
    const it = plan.items;
    const xv = it.xpValue.toFixed(2).replace(".", ",");
    body.append(el("p", "tmn-guide-text", `Agora: ${it.context}. Seu ritmo: ~${fmt(plan.economy.coinsPerHour)} moedas e ~${fmt(plan.economy.xpPerHour)} XP por hora. 1 XP vale ~${xv} moeda (o quanto o próximo nível aumenta sua renda, somado por ${it.horizon} h de pesca).`));
    const table = el("table", "tmn-guide-table");
    const tr = el("tr"); ["Item", "Custo", "Volta", "XP", "Saldo", "Empata se 1 XP ="].forEach(h => tr.append(el("th", null, h))); table.append(tr);
    for (const r of it.rows) {
      const row = el("tr");
      row.title = r.note || "";
      [r.name, fmt(r.cost), fmt(r.coins), String(r.xp).replace(".", ","), `${r.net >= 0 ? "+" : ""}${fmt(r.net)}`, r.xpBreakEven == null ? "—" : `${r.xpBreakEven.toFixed(2).replace(".", ",")} moeda`].forEach((v, i) => {
        const td = el("td", i === 4 ? (r.net >= 0 ? "tmn-guide-pos" : "tmn-guide-neg") : null, v); row.append(td);
      });
      table.append(row);
    }
    body.append(table);
    const notes = it.rows.filter((r) => r.note).map((r) => `${r.name}: ${r.note}`);
    if (notes.length) { const ul = el("ul", "tmn-guide-list"); notes.forEach(n => ul.append(el("li", null, n))); body.append(ul); }
    if (it.rod) {
      const r = it.rod;
      body.append(el("p", "tmn-guide-text", `Para subir de nível, a vara rende mais que qualquer item: com a ${r.name} (${fmt(r.price)}) você passa de ~${fmt(r.xpPerHour[0])} para ~${fmt(r.xpPerHour[1])} XP/h e de ~${fmt(r.coinsPerHour[0])} para ~${fmt(r.coinsPerHour[1])} moedas/h, para sempre: ~${fmt(r.xpGain150)} XP a mais a cada ${it.horizon} h${r.paybackH ? `, e ela se paga sozinha em ~${fmt(r.paybackH)} h de pesca` : ""}.`));
    }
    if (it.level?.needNext != null) body.append(el("p", "tmn-guide-note", `Nível ${it.level.now}: faltam ${fmt(it.level.needNext)} XP para o ${it.level.next}. Cada nível dá +0,13% de fisgada, +0,33% de chance de raros e +0,2% no preço de venda; o Guia soma isso no valor do XP.`));
    body.append(el("p", "tmn-guide-note", "Não calculado: Comprador do Porto, Peso Pesado e Menor Peixe (aí o que importa é o primeiro peixe ou uma espécie certa: use as Iscas Turbinadas que você já tem)."));
  }

  function renderIncubation(body, plan, c) {
    const inc = plan.incubation;
    body.append(el("p", "tmn-guide-text", `Você tem ${inc.incubators} incubadora(s), ${inc.fertB} Fertilizante Básico e ${inc.fertP} Premium.`));
    if (inc.ascend.length) {
      body.append(el("p", "tmn-guide-text", "Pares prontos para ascender (os dois com 95%+ do peso máximo, mesmo grau):"));
      const ul = el("ul", "tmn-guide-list");
      inc.ascend.forEach(a => ul.append(el("li", null, `${a.name}${a.asc ? ` grau ${a.asc}` : ""}: ${a.weights.join(" e ")} kg (máx. ${a.max})${a.fail ? ` · falha ${Math.round(a.fail * 100)}%` : " · nunca falha"}`)));
      body.append(ul);
    }
    if (inc.grow.length) {
      body.append(el("p", "tmn-guide-text", "Pares que podem crescer (o mais leve tem 50%+ do mais pesado):"));
      const ul = el("ul", "tmn-guide-list");
      inc.grow.slice(0, 6).forEach(g => ul.append(el("li", null, `${g.name}: ${g.weights.join(" e ")} kg${g.pctMax ? ` (${Math.round(g.pctMax * 100)}% do máx.)` : ""}${g.fail ? ` · falha ${Math.round(g.fail * 100)}%` : ""}`)));
      body.append(ul);
    }
    if (!inc.ascend.length && !inc.grow.length) body.append(el("p", "tmn-guide-text", "Nenhum par incubável no inventário (precisa de dois da mesma espécie e grau, o mais leve com 50%+ do peso do outro)."));
    body.append(el("p", "tmn-guide-note", "Regras: os dois pais sempre se perdem; Comum e Incomum nunca falham, Raro 10%, Lendário 20%, Mítico 35%, Secreto 50%. Incubar para vender não paga a incubadora (300). O valor está em ascender: ranking próprio e +10% de venda por grau. O peixe-mandarim é o favorito porque o peso quase não varia; todos os 10 mais ascendidos do jogo são mandarins."));
    const go = btn("Abrir a incubação ↗"); go.onclick = () => c.openUrl("incubation"); body.append(go);
  }

  function newsInfo(plan) {
    const notes = store.guideData?.data?.patchNotes?.notes || [];
    const seen = prefs().seenNote;
    const idx = seen ? notes.findIndex(n => `${n.postedAt}|${n.version}` === seen) : -1;
    const fresh = seen ? (idx < 0 ? notes : notes.slice(0, idx)) : notes.slice(0, 3);
    const AFFECTS = /(evento|expedi|mercado|vara|anzol|isca|mochila|pre[cç]o|moedas|twishcoins|peixe|miss[aã]o|torneio|duelo|chance|ticket|maré|encomenda|incuba|ascen|loja|venda|vender)/i;
    const relevant = fresh.filter(n => AFFECTS.test(JSON.stringify(n))).length;
    return { notes, fresh, unseen: fresh.length, relevant, AFFECTS };
  }

  function renderNews(body, plan, news) {
    if (plan.changes.length) {
      body.append(el("p", "tmn-guide-warn", "Mudanças no manual em relação ao que o Guia conhece (o Guia já usa os valores novos da loja; regras de evento podem precisar de ajuste):"));
      const ul = el("ul", "tmn-guide-list"); plan.changes.slice(0, 12).forEach(x => ul.append(el("li", null, x))); body.append(ul);
    } else body.append(el("p", "tmn-guide-text", "Manual sem mudanças em preços, eventos e mares desde o catálogo do Guia."));
    if (!news.notes.length) { body.append(el("p", "tmn-guide-note", "Patch notes: lidos da aba do Twish a cada 6 h. Deixe a aba aberta.")); return; }
    for (const n of news.fresh.length ? news.fresh : news.notes.slice(0, 2)) {
      const box = el("div", "tmn-guide-note-card");
      const affects = news.AFFECTS.test(JSON.stringify(n));
      box.append(el("b", null, `${n.postedAt.split("-").reverse().join("/")} · ${n.version}${affects ? "  ⚠ pode afetar o Guia" : ""}`));
      if (n.tagline) box.append(el("span", null, n.tagline));
      const det = el("details"); det.append(el("summary", null, "detalhes"));
      const ul = el("ul", "tmn-guide-list");
      for (const sct of n.sections || []) for (const it of sct.items || []) ul.append(el("li", null, `${sct.title}: ${it}`));
      det.append(ul); box.append(det);
      body.append(box);
    }
    if (news.unseen) {
      const ok = btn("Marcar como lidas");
      ok.onclick = () => { const p = prefs(); p.seenNote = `${news.notes[0].postedAt}|${news.notes[0].version}`; savePrefs(p); refresh(); };
      body.append(ok);
    }
  }

  function renderCompare(body, plan, c) {
    const b = plan.benchmark;
    if (b) body.append(el("p", "tmn-guide-text", `Jogadores fortes no ${b.label} costumam ter: ${b.rodRange}, anzol ${b.hook}, mochila ${b.backpack}, ${b.casts} lançadas. Você está ${b.status} na vara. ${b.note}`));
    body.append(el("p", "tmn-guide-note", "Perfis públicos mostram o que a pessoa tem hoje, não a ordem em que comprou. Servem de referência, não de receita."));

    // Top 10 do barco
    const bench = store.bench;
    const row = el("div", "tmn-guide-row");
    const load = btn(bench?.loading ? "Carregando…" : "Ver top 10 do barco");
    load.disabled = !!bench?.loading;
    load.onclick = () => chrome.storage.local.set({ [K.benchReq]: { boat: Boat?.get(), force: !!bench && !bench.loading, at: Date.now() } });
    row.append(load);
    if (bench?.at) row.append(el("span", "tmn-guide-note", `${bench.boat} · ${bench.players?.length || 0} perfis · há ${ago(bench.at)}${bench.error ? ` · ${bench.error}` : ""}`));
    body.append(row);
    if (bench?.players?.length && bench.boat === Boat?.get()) {
      const table = el("table", "tmn-guide-table");
      const tr = el("tr"); ["Jogador", "Nív.", "Lanç.", "Vara", "Anzol", "Moedas"].forEach(h => tr.append(el("th", null, h))); table.append(tr);
      const rows = bench.players.map(p => P.profileSummary(p)).filter(Boolean);
      const me = plan.account.handle;
      for (const s of rows) {
        const r = el("tr"); if (me && s.handle === me) r.className = "tmn-guide-me";
        [s.handle, s.level, fmt(s.casts), s.rod.replace(/^Vara (de |do )?/, ""), s.hook === "nenhum" ? "—" : s.hook.replace("Anzol ", ""), fmt(s.coins)].forEach(v => r.append(el("td", null, String(v ?? "—"))));
        r.onclick = () => { compareInput = s.handle; chrome.storage.local.set({ [K.compareReq]: { boat: bench.boat, handle: s.handle, at: Date.now() } }); };
        r.title = "Clique para comparar com você";
        table.append(r);
      }
      body.append(table);
    }

    // Jogador específico
    const form = el("div", "tmn-guide-row");
    const inp = el("input", "tmn-theme-option tmn-guide-input"); inp.placeholder = "nick do jogador"; inp.value = compareInput; inp.oninput = () => (compareInput = inp.value);
    const boatInp = el("input", "tmn-theme-option tmn-guide-input tmn-guide-input-sm"); boatInp.placeholder = Boat?.get() || "barco"; boatInp.value = compareBoatInput; boatInp.oninput = () => (compareBoatInput = boatInp.value);
    boatInp.title = "Barco onde o jogador pesca (vazio = o seu)";
    const go = btn("Comparar");
    go.onclick = () => { if (!inp.value.trim()) return; chrome.storage.local.set({ [K.compareReq]: { boat: boatInp.value.trim() || Boat?.get(), handle: inp.value.trim(), at: Date.now() } }); go.textContent = "Buscando…"; };
    inp.onkeydown = e => { if (e.key === "Enter") go.click(); };
    form.append(inp, boatInp, go);
    body.append(form);

    const cmp = store.compare;
    if (cmp) {
      if (!cmp.ok) body.append(el("p", "tmn-guide-warn", `${cmp.handle}: ${cmp.error}`));
      else {
        const other = P.profileSummary(cmp.profile);
        const mine = plan.account;
        const table = el("table", "tmn-guide-table");
        const tr = el("tr"); ["", "Você", other.handle].forEach(h => tr.append(el("th", null, h))); table.append(tr);
        const line = (label, x, y) => { const r = el("tr"); [label, x, y].forEach(v => r.append(el("td", null, String(v ?? "—")))); table.append(r); };
        line("Nível", mine.level, other.level);
        line("Lançadas", fmt(mine.casts), fmt(other.casts));
        line("Moedas", fmt(mine.coins), fmt(other.coins));
        line("Vara", mine.rod?.name, other.rod);
        line("Anzol", mine.hook?.name || "nenhum", other.hook);
        line("Iscas", Object.entries(mine.baits || {}).map(([k, v]) => `${k.replace("isca_", "")} ${v}`).join(", ") || "—", Object.entries(other.baits).map(([k, v]) => `${k.replace("isca_", "")} ${v}`).join(", ") || "—");
        line("Títulos", mine.titles, other.titles);
        line("Inventário", `${mine.fishCount} (~${fmt(mine.stockValue)})`, `${other.invCount} (~${fmt(other.invValue)})`);
        line("Melhor captura", mine.best || "—", other.best);
        body.append(table);
        const exp = btn("Exportar perfil (JSON)");
        exp.onclick = () => download(`perfil-${cmp.handle}-${cmp.boat}.json`, { exportedAt: new Date().toISOString(), boat: cmp.boat, profile: P.sanitize(cmp.profile) });
        body.append(exp);
      }
    }
  }

  function updateBadge(res, root = document.getElementById(ctx()?.rootId || "tmn-root")) {
    const menu = root?.querySelector(".tmn-menu");
    if (!menu) return;
    const panelOpen = document.getElementById(ctx()?.panelId)?.dataset.open === "true" && document.getElementById(ctx()?.panelId)?.dataset.activeGroup === "guia";
    const n = res ? syncSeen(res, panelOpen) : 0;
    const badge = n ? String(n) : "";
    if (menu.dataset.badge !== badge) { menu.dataset.badge = badge; menu.title = n ? `${n} novidade(s) para fazer agora no Guia` : ""; }
  }

  function renderHint() {
    const c = ctx();
    const root = document.getElementById(c?.rootId || "tmn-root");
    const host = root?.querySelector(".tmn-guide-hint");
    if (!host) return;
    const res = analysis(c);
    // selo no ≡: quantas ações para fazer agora (prioridade crítica/alta)
    updateBadge(res, root);
    const top = prefs().hint ? res?.plan?.top : null;
    // $pescar em cooldown: mostra o tempo no lugar do comando (não adianta preencher agora)
    const fishCd = top?.command === "$pescar" ? c.getFishing?.()?.cooldown || null : null;
    const sig = top ? `${top.priority}|${top.title}|${top.command}|${fishCd}` : "none";
    if (sig === hintSignature && host.childElementCount === (top ? 1 : 0)) return;
    hintSignature = sig;
    host.replaceChildren();
    host.dataset.active = String(!!top);
    if (!top) return;
    const box = el("div", "tmn-guide-hint-box");
    // Um clique: se a ação tem comando, preenche o chat; senão abre o Guia. O "i" sempre abre o Guia.
    const text = el("button", "tmn-guide-hint-text");
    text.type = "button";
    const canFill = top.command && !fishCd;
    text.title = `${top.text}${top.why ? `\nPor quê: ${top.why}` : ""}\n\n${canFill ? `Clique para preencher ${top.command} no chat.` : fishCd ? `Pesca libera em ${fishCd}.` : "Clique para abrir o Guia."}`;
    text.append(el("span", `tmn-guide-prio tmn-guide-${PRIO_CLASS[top.priority] || "p3"}`, P.PRIORITY[top.priority] || ""), el("span", "tmn-guide-hint-msg", top.title));
    if (top.command) text.append(el("span", "tmn-guide-hint-cmd", fishCd ? `⏳ ${fishCd}` : top.command));
    text.onclick = () => (canFill ? c.fill(top.command) : c.openGroup("guia"));
    box.append(text);
    const info = el("button", "tmn-guide-hint-go", "🧭");
    info.type = "button";
    info.title = "Abrir o Guia";
    info.setAttribute("aria-label", "Abrir o Guia");
    info.onclick = e => { e.stopPropagation(); c.openGroup("guia"); };
    box.append(info);
    host.append(box);
  }

  function renderSettings(wrap, rerender) {
    const p = prefs();
    const section = el("section", "tmn-sound-section tmn-guide-settings");


    section.append(el("div", "tmn-settings-title", "Seu nick (opcional)"));
    const hrow = el("div", "tmn-guide-boat-row");
    const hin = el("input", "tmn-theme-option tmn-guide-input"); hin.value = store.handle || ""; hin.placeholder = "seu nick no Twish (opcional)"; hin.autocomplete = "off";
    const hsave = el("button", "tmn-theme-option tmn-sound-button", "Salvar"); hsave.type = "button";
    hsave.onclick = async () => { await chrome.storage.local.set({ [K.handle]: (Boat?.slug(hin.value) || "") }); hsave.textContent = "Salvo!"; setTimeout(rerender, 900); };
    hrow.append(hin, hsave);
    section.append(hrow, el("span", "tmn-auto-description", "Usado para ler seu perfil público (nível, vara, lançadas) e destacar você na comparação."));

    const toggle = (key, label, on, off) => {
      section.append(el("div", "tmn-settings-title", label));
      const r = el("div", "tmn-auto-row");
      const b = el("button", "tmn-theme-option tmn-sound-button", p[key] ? "Ligado" : "Desligado");
      b.type = "button"; b.setAttribute("role", "switch"); b.setAttribute("aria-checked", String(!!p[key])); b.dataset.selected = String(!!p[key]);
      b.onclick = () => { savePrefs({ ...prefs(), [key]: !p[key] }); applyReadable(); hintSignature = ""; renderHint(); rerender(); };
      r.append(b, el("span", "tmn-auto-description", p[key] ? on : off));
      section.append(r);
    };
    toggle("readable", "Fonte legível", "Letra sem serifa, maior e com mais contraste em todo o Timoneiro.", "Visual original (fonte pixelada).");
    toggle("hint", "Dica do Guia acima dos atalhos", "Mostra a ação mais importante do momento.", "A dica fica só na aba Guia.");
    toggle("expeditions", "Dicas de expedição", "O Guia avalia os mares que sua vara alcança.", "Sem dicas de expedição.");

    // Notificações de evento: relevância mínima e aviso de fim (v1.9.0).
    const n = store.notif || {};
    const saveNotif = async (patch) => { const cur = (await chrome.storage.local.get(K.notif))[K.notif] || {}; await chrome.storage.local.set({ [K.notif]: { ...cur, ...patch } }); };
    section.append(el("div", "tmn-settings-title", "Quais eventos notificar"));
    const lvl = el("select", "tmn-theme-option tmn-theme-select");
    lvl.setAttribute("aria-label", "Quais eventos notificar");
    [["todos", "Todos os eventos"], ["media", "Relevância Média ou Alta"], ["alta", "Só relevância Alta"]].forEach(([v, t]) => { const o = el("option", null, t); o.value = v; o.selected = (n.eventLevel || "todos") === v; lvl.append(o); });
    lvl.onchange = () => saveNotif({ eventLevel: lvl.value });
    section.append(lvl, el("span", "tmn-auto-description", "Alta: XP em Dobro, Venda Turbinada, Desconto, Sorte Rara de Lendário+ e grandes eventos. Baixa: Coins em Dobro e Sorte Rara de raridade baixa."));
    const endRow = el("div", "tmn-auto-row");
    const endBtn = el("button", "tmn-theme-option tmn-sound-button", n.eventEnd ? "Ligado" : "Desligado"); endBtn.type = "button"; endBtn.setAttribute("role", "switch"); endBtn.setAttribute("aria-checked", String(!!n.eventEnd)); endBtn.dataset.selected = String(!!n.eventEnd);
    endBtn.onclick = async () => { await saveNotif({ eventEnd: !n.eventEnd }); setTimeout(rerender, 100); };
    endRow.append(endBtn, el("span", "tmn-auto-description", "Avisar também quando um evento terminar."));
    section.append(el("div", "tmn-settings-title", "Fim de evento"), endRow);

    // Discord (opcional): configurado em Opções, onde o navegador pede a permissão.
    const d = store.discord || {};
    section.append(el("div", "tmn-settings-title", "Avisos no Discord (opcional)"));
    const drow = el("div", "tmn-auto-row");
    const dopen = el("button", "tmn-theme-option tmn-sound-button tmn-wide-button", "Configurar o Discord"); dopen.type = "button";
    dopen.onclick = () => chrome.runtime.sendMessage({ type: "timoneiro-open-options" }).catch(() => {});
    drow.append(dopen, el("span", "tmn-auto-description", d.url ? "Webhook salvo. Teste e escolha os avisos em Opções." : "Os avisos também vão para um canal seu no Discord e chegam no celular."));
    section.append(drow);
    wrap.append(section);
  }

  function refresh() {
    hintSignature = "";
    renderHint();
    if (tabList?.isConnected && document.getElementById(ctx()?.panelId)?.dataset.activeGroup === "guia" && !typing()) renderTab(tabList, tabCtx);
  }
  const typing = () => tabList?.contains(document.activeElement) && document.activeElement.tagName === "INPUT";

  function tick() {
    renderHint();
    if (tabList?.isConnected && Date.now() - lastTabRender > 10000 && document.getElementById(ctx()?.panelId)?.dataset.activeGroup === "guia" && !typing()) renderTab(tabList, tabCtx);
  }

  applyReadable();

  chrome.storage.local.get([K.syncStatus, K.guideData, K.handle, K.compareRes, K.benchRes, K.seen, K.events, K.bg, K.history, K.lastRate, K.notif, K.discord, K.fishing, K.realtime, K.eventLog, K.marketWatch, K.marketHits], r => {
    for (const k of ["events", "bg", "history", "lastRate", "notif", "discord", "fishing", "realtime", "eventLog", "marketWatch", "marketHits"]) store[k] = r?.[K[k]] || null;
    store.seen = Array.isArray(r?.[K.seen]) ? r[K.seen] : [];
    store.syncStatus = r?.[K.syncStatus] || null;
    store.guideData = r?.[K.guideData] || null;
    store.handle = r?.[K.handle] || null;
    store.compare = r?.[K.compareRes] || null;
    store.bench = r?.[K.benchRes] || null;
    refresh();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    let dirty = false;
    if (changes[K.syncStatus]) { store.syncStatus = changes[K.syncStatus].newValue || null; dirty = true; }
    if (changes[K.guideData]) { store.guideData = changes[K.guideData].newValue || null; dirty = true; }
    if (changes[K.handle]) { store.handle = changes[K.handle].newValue || null; dirty = true; }
    if (changes[K.compareRes]) { store.compare = changes[K.compareRes].newValue || null; dirty = true; }
    if (changes[K.benchRes]) { store.bench = changes[K.benchRes].newValue || null; dirty = true; }
    if (changes[K.seen]) { store.seen = Array.isArray(changes[K.seen].newValue) ? changes[K.seen].newValue : []; updateBadge(analysis(ctx())); }
    for (const k of ["events", "bg", "history", "lastRate", "notif", "discord", "fishing", "realtime", "eventLog", "marketWatch", "marketHits"]) if (changes[K[k]]) { store[k] = changes[K[k]].newValue || null; if (["events", "history", "lastRate", "marketWatch", "marketHits"].includes(k)) dirty = true; }
    if (changes[Boat?.KEY]) dirty = true;
    if (changes["timoneiro.update.v1"]) dirty = true; // versão nova: o cartão Urgente aparece na hora
    if (dirty) refresh();
  });

  globalThis.TimoneiroGuide = { renderTab, renderSettings, refresh, tick, fillEvent };
  refresh();
})();
