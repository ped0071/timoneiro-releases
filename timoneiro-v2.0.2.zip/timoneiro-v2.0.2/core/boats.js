// Timoneiro — qual barco do Twish vale no canal da Twitch aberto.
// Função pura: recebe o canal, a lista pública de barcos (/api/channels) e as preferências,
// e decide se a barra aparece e qual é o barco. Sem chrome.*, para rodar nos testes.
(function (root) {
  "use strict";
  const DAY = 24 * 3600e3, HOUR = 3600e3;
  // Caminhos da Twitch que não são canal.
  const RESERVED = new Set(["directory", "settings", "videos", "search", "subscriptions", "inventory", "wallet", "drops", "friends", "messages", "downloads", "turbo", "jobs", "p", "u", "prime", "store", "following", "login", "signup", "logout", "payments", "broadcast", "dashboard"]);

  const slug = (v) => String(v ?? "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_]/g, "");

  function channelFromPath(pathname) {
    const seg = String(pathname || "").split("/").filter(Boolean).map((s) => { try { return decodeURIComponent(s).toLowerCase(); } catch (_) { return s.toLowerCase(); } });
    if (["popout", "embed", "moderator"].includes(seg[0])) return slug(seg[1]) || null;
    if (!seg.length || RESERVED.has(seg[0])) return null;
    return slug(seg[0]) || null;
  }

  function channelFromUrl(url) {
    try { const u = new URL(url); return u.protocol === "https:" && u.hostname === "www.twitch.tv" ? channelFromPath(u.pathname) : null; } catch (_) { return null; }
  }

  // "fulano, @ciclano beltrano" -> ["fulano", "ciclano", "beltrano"]
  function parseList(text) { return [...new Set(String(text || "").split(/[,;\s]+/).map(slug).filter(Boolean))]; }

  function parseChannels(json) {
    if (!json || !Array.isArray(json.channels)) return null;
    return json.channels.filter((c) => typeof c === "string").map(slug).filter(Boolean);
  }

  function needsRefresh(cache, now, channel) {
    if (!cache || !Array.isArray(cache.list) || !Number.isFinite(cache.fetchedAt)) return true;
    const age = now - cache.fetchedAt;
    if (age >= DAY) return true;
    return !!channel && !cache.list.includes(channel) && age > HOUR;
  }

  function decide({ channel, cache, prefs, seen }) {
    const p = prefs || {};
    const hidden = Array.isArray(p.hidden) ? p.hidden : [];
    const pinned = slug(p.pinned) || null;
    const list = cache && Array.isArray(cache.list) ? cache.list : null;
    const no = (reason) => ({ show: false, boat: null, reason });
    if (!channel) return no("no-channel");
    if (hidden.includes(channel)) return no("hidden");
    const isBoat = list ? list.includes(channel) : (Array.isArray(seen) && seen.includes(channel));
    // Fixado: só na live desse barco. Os comandos do Twish valem para o barco do chat onde são
    // digitados, então mostrar o barco fixado no chat de outro canal levaria a pescar no barco errado.
    if (pinned) return channel === pinned ? { show: true, boat: pinned, reason: "pinned" } : no("pinned-elsewhere");
    // "Mostrar só nestes canais": a lista que você escreveu manda (vale mesmo fora da lista pública).
    const only = Array.isArray(p.only) ? p.only.map(slug).filter(Boolean) : [];
    if (only.length) return only.includes(channel) ? { show: true, boat: channel, reason: "only" } : no("not-listed");
    if (isBoat) return { show: true, boat: channel, reason: "boat" };
    return no(list ? "not-boat" : "no-list");
  }

  // Quem vem da 1.x: o barco que estava fixado (locked) continua fixado.
  function migrate(oldChannels, oldBoat) {
    const pinned = oldBoat && oldBoat.locked !== false ? slug(oldBoat.boat) || null : null;
    return { pinned, hidden: [], migrated: true };
  }

  const api = { slug, channelFromPath, channelFromUrl, parseList, parseChannels, needsRefresh, decide, migrate };
  root.TimoneiroBoats = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
