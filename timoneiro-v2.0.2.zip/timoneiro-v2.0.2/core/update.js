// Timoneiro — versão nova publicada? Lê o latest.json público (uma vez por dia, só GET, sem cookies),
// confere a assinatura de cada pacote com a chave pública do Timoneiro e compara com a instalada.
(function (root) {
  "use strict";
  const BASE = "https://ped0071.github.io/timoneiro-releases/";
  const LATEST_URL = BASE + "latest.json";
  // Chave pública de assinatura das versões (ECDSA P-256, SPKI em base64). A privada fica no CI.
  const PUBLIC_KEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEyz2Qjs7IPI+YvN/2p6Eb4fiDG2n9IQiwAcEOHe3eDefqJz6cMegiXaYo/K/4g7uGAkrtDGppZxhHBzAaqIYhiw==";

  const parts = (v) => String(v).split(".").map((n) => Number(n) || 0);
  function compare(a, b) {
    const x = parts(a), y = parts(b);
    for (let i = 0; i < Math.max(x.length, y.length, 3); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; }
    return 0;
  }

  const HEX64 = /^[0-9a-f]{64}$/, B64 = /^[A-Za-z0-9+/]+={0,2}$/;
  function parse(json) {
    if (!json || typeof json !== "object" || !/^\d+\.\d+\.\d+$/.test(json.version)) return null;
    const files = {};
    for (const name of ["chrome", "firefox"]) {
      const f = json.files && json.files[name];
      let href = "";
      try { href = new URL(f && f.url).href; } catch (_) { return null; }
      if (href !== f.url || !href.startsWith(BASE) || !HEX64.test(f.sha256) || !B64.test(f.sig || "")) return null;
      files[name] = { url: f.url, sha256: f.sha256, sig: f.sig };
    }
    if (!B64.test(json.sig || "")) return null;
    const notes = typeof json.notes === "string" ? json.notes : "";
    if (notes.length > 4000) return null; // não corta: as notas fazem parte do que é assinado
    return { version: json.version, published_at: String(json.published_at || ""), notes, important: json.important === true, sig: json.sig, files };
  }

  const bytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const enc = (s) => new TextEncoder().encode(s);
  async function sha256hex(s) {
    const d = await (root.crypto || globalThis.crypto).subtle.digest("SHA-256", enc(s));
    return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  // Mesmo texto que scripts/sign-release.cjs assina.
  const canonical = (name, version, sha) => `timoneiro|${name}|${version}|${sha}`;
  const metaCanonical = async (version, important, notes) => `timoneiro|meta|${version}|${important ? 1 : 0}|${await sha256hex(notes || "")}`;
  async function verify(latest, publicKeyB64 = PUBLIC_KEY) {
    try {
      const subtle = (root.crypto || globalThis.crypto).subtle;
      const key = await subtle.importKey("spki", bytes(publicKeyB64), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      const check = (sig, text) => subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, bytes(sig), enc(text));
      if (!(await check(latest.sig, await metaCanonical(latest.version, latest.important, latest.notes)))) return false;
      for (const [name, f] of Object.entries(latest.files)) if (!(await check(f.sig, canonical(name, latest.version, f.sha256)))) return false;
      return true;
    } catch (_) { return false; }
  }

  const newer = (latest, installed) => !!latest && compare(latest.version, installed) > 0;

  const api = { BASE, LATEST_URL, PUBLIC_KEY, compare, parse, verify, newer };
  root.TimoneiroUpdate = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
