// Timoneiro — escrever um comando na caixa do chat da Twitch.
// Escreve e deixa o cursor no fim: quem envia é você (Enter). A única exceção é o Arremesso
// automático, opcional e desligado por padrão: ligado, um clique no 🎣 da barra envia esse $pescar.
(function (root) {
  "use strict";
  if (root.TimoneiroChat) return;
  const Store = root.TimoneiroStore;

  // A Twitch já usou textarea, input e editor contenteditable (Slate). Pega o que estiver visível.
  const CHAT = '[data-a-target="chat-input"]', EDITABLE = '[contenteditable="true"]';
  const EDITOR_SELECTORS = [CHAT + EDITABLE, `${CHAT} ${EDITABLE}`, `${CHAT} textarea`, `${CHAT} input`, "textarea" + CHAT, '[data-slate-editor="true"]' + EDITABLE];
  const visible = (el) => !!el && el.isConnected && el.getBoundingClientRect().width > 0;
  function findEditor() {
    for (const sel of EDITOR_SELECTORS) {
      const hit = [...document.querySelectorAll(sel)].find(visible);
      if (hit) return hit;
    }
    return null;
  }
  const isField = (el) => el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement;
  // Texto do campo sem o texto-guia ("Enviar uma mensagem") e sem as partes não editáveis do editor.
  function text(el) {
    if (!el) return "";
    if (isField(el)) return el.value || "";
    const copy = el.cloneNode(true);
    copy.querySelectorAll('[data-slate-placeholder], [contenteditable="false"]').forEach((x) => x.remove());
    return copy.textContent || "";
  }

  const plain = (t) => String(t || "").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\u00A0/g, " ").trim();

  function placeCaret(el, all) {
    if (isField(el)) { const n = el.value.length; el.setSelectionRange(all ? 0 : n, n); return; }
    const r = document.createRange();
    r.selectNodeContents(el);
    if (!all) r.collapse(false);
    const s = getSelection();
    s.removeAllRanges(); s.addRange(r);
  }

  // Substitui o que estiver escrito pelo comando. Primeiro pelo caminho do próprio navegador
  // (o editor da Twitch acompanha), senão definindo o valor e avisando o React com "input".
  function fill(cmd) {
    const ed = findEditor();
    if (!ed || typeof cmd !== "string") return false;
    ed.focus();
    placeCaret(ed, true);
    let wrote = false;
    const ok = ed.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: cmd }));
    // Cancelado: o editor da Twitch (Slate) pegou o texto e redesenha o campo logo depois.
    if (!ok) return true;
    try { wrote = document.execCommand("insertText", false, cmd); } catch (_) { wrote = false; }
    if (!wrote && isField(ed)) {
      const setValue = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(ed), "value")?.set;
      setValue ? setValue.call(ed, cmd) : (ed.value = cmd);
      ed.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: cmd }));
    }
    placeCaret(ed, false);
    return wrote || isField(ed) || plain(text(ed)) === cmd.trim();
  }

  // ---------- Arremesso automático (opcional) ----------
  const CLICK_SEND = "timoneiro.clickSend.v1";
  let sending = false, sentAt = 0;
  const LOCK_MS = 10e3; // depois de enviar, espera o Twish confirmar a pescaria antes de outro envio
  const sendButton = () => [...document.querySelectorAll('[data-a-target="chat-send-button"]')].find(visible) || null;

  // O editor da Twitch (Slate) põe caracteres invisíveis e recria o elemento a cada digitação.
  const LABELS = {
    sent: "enviado", off: "Arremesso desligado", busy: "já estava enviando",
    recent: "esperando o Twish confirmar a pescaria anterior (10 s)", "no-editor": "campo do chat não encontrado",
    changed: "o texto do chat mudou antes de enviar", "no-send": "a Twitch não aceitou o envio",
    cooldown: "a pesca ainda não liberou", unknown: "tempo da pesca desconhecido (abra o Twish neste navegador)",
  };
  let last = null;
  const note = (result) => { last = { result, at: Date.now() }; return result; };

  // Chamado depois de fill("$pescar") quando a pesca está liberada. Envia uma vez, só se o texto
  // do chat ainda for exatamente "$pescar": pelo botão de enviar da Twitch ou, sem ele, pelo Enter.
  function sendFishingOnce() {
    if (Store?.get(CLICK_SEND, false) !== true) return Promise.resolve(note("off"));
    if (sending) return Promise.resolve(note("busy"));
    if (Date.now() - sentAt < LOCK_MS) return Promise.resolve(note("recent"));
    if (!findEditor()) return Promise.resolve(note("no-editor"));
    sending = true;
    const finish = (r) => { sending = false; if (r === "sent") sentAt = Date.now(); return note(r); };
    return new Promise((done) => {
      let tries = 0, waits = 0;
      const attempt = () => {
        const ed = findEditor(); // procura de novo: o elemento pode ter sido recriado
        if (!ed || Store.get(CLICK_SEND, false) !== true) return done(finish(ed ? "off" : "no-editor"));
        const now = plain(text(ed));
        if (now !== "$pescar") {
          // O editor pode ainda estar redesenhando: espera até ~1 s pelo texto; outro texto é sua digitação.
          if ((now === "" || "$pescar".startsWith(now)) && ++waits < 12) return setTimeout(attempt, 80);
          return done(finish("changed"));
        }
        const btn = sendButton();
        if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") { btn.click(); return done(finish("sent")); }
        if (++tries < 6) return setTimeout(attempt, 60);
        // Sem botão visível: o Enter no campo, como a pessoa faria.
        ed.focus();
        const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
        ed.dispatchEvent(new KeyboardEvent("keydown", opts));
        ed.dispatchEvent(new KeyboardEvent("keyup", opts));
        setTimeout(() => done(finish(plain(text(findEditor())) === "$pescar" ? "no-send" : "sent")), 200);
      };
      setTimeout(attempt, 250); // o editor da Twitch atualiza o estado interno depois de escrever
    });
  }

  root.TimoneiroChat = {
    findEditor, fill, text: () => text(findEditor()), sendFishingOnce,
    lastSend: () => (last ? { ...last, label: LABELS[last.result] || last.result } : null),
    noteSend: (result) => note(result),
    clickSend: () => Store?.get(CLICK_SEND, false) === true,
    setClickSend: (on) => Store?.set(CLICK_SEND, !!on),
  };
})(globalThis);
