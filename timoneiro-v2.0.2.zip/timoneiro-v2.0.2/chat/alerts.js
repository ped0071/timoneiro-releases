// Timoneiro — avisos na aba da Twitch: som quando a pesca libera e quando começa um evento,
// volume de cada som, e as preferências de notificação (usadas pelo fundo da extensão).
// O som toca uma vez por acontecimento em todo o navegador (trava no storage) e só na aba visível;
// com a Twitch em outra aba, quem toca é o fundo (notification-worker.js).
(function (root) {
  "use strict";
  if (root.TimoneiroAlerts) return;
  const Store = root.TimoneiroStore;
  const SOUNDS = "timoneiro.sounds.v1", NOTIF = "timoneiro.notifications.v1", LOCK = "timoneiro.soundLock.v1";
  const FILES = { fishingAlert: "sounds/pesca.wav", eventAlert: "sounds/evento.wav" };
  const DEFAULT = { fishingAlert: { enabled: true, volume: 7 }, eventAlert: { enabled: true, volume: 7 } };

  // ---------- sons ----------
  const vol = (v) => Math.round(Math.min(10, Math.max(1, Number(v) || 7)));
  function sounds() {
    const saved = Store?.get(SOUNDS, {}) || {};
    const out = {};
    for (const g of Object.keys(DEFAULT)) {
      const s = saved[g] || {};
      out[g] = { enabled: s.volume === 0 ? false : typeof s.enabled === "boolean" ? s.enabled : true, volume: s.volume === 0 ? DEFAULT[g].volume : vol(s.volume ?? DEFAULT[g].volume) };
    }
    return out;
  }
  function setSound(group, patch) {
    const all = sounds();
    if (!all[group]) return;
    if (typeof patch.enabled === "boolean") all[group].enabled = patch.enabled;
    if (patch.volume != null) all[group].volume = vol(patch.volume);
    return Store.set(SOUNDS, all);
  }
  const players = new Map();
  function play(group) {
    const s = sounds()[group];
    if (!s || !s.enabled) return;
    try {
      if (!players.has(group)) players.set(group, new Audio(chrome.runtime.getURL(`assets/${FILES[group]}`)));
      const a = players.get(group);
      a.volume = s.volume / 10; a.currentTime = 0;
      const p = a.play(); if (p) p.catch(() => {});
    } catch (_) {}
  }

  // ---------- notificações (padrão: ligadas) ----------
  const notifications = () => { const n = Store?.get(NOTIF, {}) || {}; return { fishing: n.fishing !== false, event: n.event !== false }; };
  function toggleNotification(group) {
    const cur = Store?.get(NOTIF, {}) || {};
    return Store.set(NOTIF, { ...cur, [group]: !notifications()[group] });
  }

  // ---------- quando tocar ----------
  async function once(kind, key, group) {
    if (document.visibilityState !== "visible") return;
    if (root.TimoneiroChannel && !root.TimoneiroChannel.allowed()) return;
    try {
      const lock = (await chrome.storage.local.get(LOCK))[LOCK] || {};
      const quiet = kind === "fishing" ? 60e3 : 12 * 60e3;
      if (lock[kind] === key || Date.now() - (lock[`${kind}At`] || 0) < quiet) return;
      await chrome.storage.local.set({ [LOCK]: { ...lock, [kind]: key, [`${kind}At`]: Date.now() } });
    } catch (_) { return; }
    play(group);
  }

  let armedFor = null, timer = null, lastEvent = null, eventSeen = false;
  // Pesca: agenda o som para a hora exata em que libera (readyAt), sem esperar outra leitura.
  // Evento: toca quando aparece um evento com nome novo.
  function observe(fishing, event, now = Date.now()) {
    const c = root.TimoneiroStatus?.countdown(fishing, now);
    if (c && c.mode === "cooldown" && Number.isFinite(fishing.readyAt) && armedFor !== fishing.readyAt) {
      clearTimeout(timer);
      const at = (armedFor = fishing.readyAt), boat = fishing.boat;
      timer = setTimeout(() => { if (armedFor === at) once("fishing", `${boat}|${Math.round(at / 10000)}`, "fishingAlert"); }, Math.max(0, at - Date.now()) + 300);
    }
    const recent = event && Number.isFinite(event.updatedAt) && now - event.updatedAt <= 30e3;
    if (!recent) return;
    const name = event.active ? event.name : null;
    if (eventSeen && name && name !== lastEvent) {
      const end = Number.isFinite(event.endsAt) ? Math.round(event.endsAt / 60000) : "x";
      once("event", `${event.boat}|${name}|${end}`, "eventAlert");
    }
    if (name) lastEvent = name; else if (!event.active) lastEvent = null;
    eventSeen = true;
  }

  root.TimoneiroAlerts = { observe, sounds, setSound, play, notifications, toggleNotification };
})(globalThis);
